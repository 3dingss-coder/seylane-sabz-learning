
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);

var __defProp = Object.defineProperty;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __esm = (fn, res, err) => function __init() {
  if (err) throw err[0];
  try {
    return fn && (res = (0, fn[__getOwnPropNames(fn)[0]])(fn = 0)), res;
  } catch (e) {
    throw err = [e], e;
  }
};
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};

// ../../functions/src/http/errors.ts
function toErrorBody(err) {
  const body = { error: { code: err.code, message: err.message } };
  if (err.details !== void 0) body.error.details = err.details;
  return body;
}
var HTTP_STATUS, DEFAULT_MESSAGES, ApiError;
var init_errors = __esm({
  "../../functions/src/http/errors.ts"() {
    "use strict";
    HTTP_STATUS = {
      VALIDATION: 400,
      UNAUTHENTICATED: 401,
      FORBIDDEN: 403,
      NOT_FOUND: 404,
      CONFLICT: 409,
      RATE_LIMIT: 429,
      INTERNAL: 500
    };
    DEFAULT_MESSAGES = {
      VALIDATION: "\u0627\u0637\u0644\u0627\u0639\u0627\u062A \u0648\u0627\u0631\u062F\u0634\u062F\u0647 \u062F\u0631\u0633\u062A \u0646\u06CC\u0633\u062A. \u0644\u0637\u0641\u0627\u064B \u0628\u0631\u0631\u0633\u06CC \u06A9\u0646\u06CC\u062F.",
      UNAUTHENTICATED: "\u0644\u0637\u0641\u0627\u064B \u062F\u0648\u0628\u0627\u0631\u0647 \u0648\u0627\u0631\u062F \u062D\u0633\u0627\u0628 \u062E\u0648\u062F \u0634\u0648\u06CC\u062F.",
      FORBIDDEN: "\u0634\u0645\u0627 \u0627\u062C\u0627\u0632\u0647 \u062F\u0633\u062A\u0631\u0633\u06CC \u0628\u0647 \u0627\u06CC\u0646 \u0628\u062E\u0634 \u0631\u0627 \u0646\u062F\u0627\u0631\u06CC\u062F.",
      NOT_FOUND: "\u0645\u0648\u0631\u062F\u06CC \u06A9\u0647 \u062F\u0646\u0628\u0627\u0644\u0634 \u0647\u0633\u062A\u06CC\u062F \u067E\u06CC\u062F\u0627 \u0646\u0634\u062F.",
      CONFLICT: "\u0627\u06CC\u0646 \u062F\u0631\u062E\u0648\u0627\u0633\u062A \u0628\u0627 \u0648\u0636\u0639\u06CC\u062A \u0641\u0639\u0644\u06CC \u0633\u0627\u0632\u06AF\u0627\u0631 \u0646\u06CC\u0633\u062A.",
      RATE_LIMIT: "\u062F\u0631\u062E\u0648\u0627\u0633\u062A\u200C\u0647\u0627 \u0632\u06CC\u0627\u062F \u0628\u0648\u062F. \u06A9\u0645\u06CC \u0635\u0628\u0631 \u06A9\u0646\u06CC\u062F \u0648 \u062F\u0648\u0628\u0627\u0631\u0647 \u062A\u0644\u0627\u0634 \u06A9\u0646\u06CC\u062F.",
      INTERNAL: "\u0645\u0634\u06A9\u0644\u06CC \u067E\u06CC\u0634 \u0622\u0645\u062F. \u0644\u0637\u0641\u0627\u064B \u06A9\u0645\u06CC \u0628\u0639\u062F \u062F\u0648\u0628\u0627\u0631\u0647 \u062A\u0644\u0627\u0634 \u06A9\u0646\u06CC\u062F."
    };
    ApiError = class extends Error {
      code;
      status;
      details;
      constructor(code, message, details) {
        super(message ?? DEFAULT_MESSAGES[code]);
        this.code = code;
        this.status = HTTP_STATUS[code];
        this.details = details;
      }
    };
  }
});

// ../../functions/src/http/validate.ts
import { z } from "zod";
function parse(schema, input) {
  const r = schema.safeParse(input ?? {});
  if (!r.success) {
    const details = r.error.issues.map((i) => ({ field: i.path.join("."), message: i.message }));
    const first = details[0];
    throw new ApiError(
      "VALIDATION",
      first?.message && /[\u0600-\u06FF]/.test(first.message) ? first.message : void 0,
      details
    );
  }
  return r.data;
}
var text, isoDate, listQuery;
var init_validate = __esm({
  "../../functions/src/http/validate.ts"() {
    "use strict";
    init_errors();
    text = (min, max, label) => z.string({
      required_error: `${label} \u0631\u0627 \u0648\u0627\u0631\u062F \u06A9\u0646\u06CC\u062F.`,
      invalid_type_error: `${label} \u0645\u0639\u062A\u0628\u0631 \u0646\u06CC\u0633\u062A.`
    }).transform(
      (s) => s.replace(/ي/g, "\u06CC").replace(/ك/g, "\u06A9").replace(/[ \t]+/g, " ").trim()
    ).refine((s) => s.length >= min, `${label} \u0628\u0627\u06CC\u062F \u062D\u062F\u0627\u0642\u0644 ${min} \u0646\u0648\u06CC\u0633\u0647 \u0628\u0627\u0634\u062F.`).refine((s) => s.length <= max, `${label} \u062D\u062F\u0627\u06A9\u062B\u0631 ${max} \u0646\u0648\u06CC\u0633\u0647 \u0627\u0633\u062A.`);
    isoDate = (label) => z.string().refine((s) => !Number.isNaN(Date.parse(s)), `${label} \u0645\u0639\u062A\u0628\u0631 \u0646\u06CC\u0633\u062A.`).transform((s) => new Date(s).toISOString());
    listQuery = z.object({
      limit: z.coerce.number().int().min(1).max(50).default(20),
      cursor: z.string().max(200).optional()
    });
  }
});

// ../../functions/src/lib/time.ts
function addMs(d, ms) {
  return new Date(d.getTime() + ms);
}
function zonedParts(d, timeZone) {
  const fmt = new Intl.DateTimeFormat("en-US", {
    timeZone,
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
    hour: "2-digit",
    minute: "2-digit",
    hourCycle: "h23",
    weekday: "short"
  });
  const parts = Object.fromEntries(fmt.formatToParts(d).map((p) => [p.type, p.value]));
  const weekdays = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
  return {
    year: Number(parts.year),
    month: Number(parts.month),
    day: Number(parts.day),
    hour: Number(parts.hour),
    minute: Number(parts.minute),
    weekday: weekdays.indexOf(String(parts.weekday))
  };
}
function dayKey(d, timeZone) {
  const p = zonedParts(d, timeZone);
  return `${p.year}-${String(p.month).padStart(2, "0")}-${String(p.day).padStart(2, "0")}`;
}
function toMinutes(hhmm2) {
  const [h2, m] = hhmm2.split(":").map(Number);
  return (h2 ?? 0) * 60 + (m ?? 0);
}
function inQuietHours(d, quiet, timeZone) {
  const p = zonedParts(d, timeZone);
  const now = p.hour * 60 + p.minute;
  const s = toMinutes(quiet.start);
  const e = toMinutes(quiet.end);
  if (s === e) return false;
  return s < e ? now >= s && now < e : now >= s || now < e;
}
function quietHoursEnd(d, quiet, timeZone) {
  let t = new Date(Math.ceil(d.getTime() / 6e4) * 6e4);
  for (let i = 0; i < 1500 && inQuietHours(t, quiet, timeZone); i++) t = addMs(t, 6e4);
  return t;
}
var systemClock, HOUR, DAY;
var init_time = __esm({
  "../../functions/src/lib/time.ts"() {
    "use strict";
    systemClock = () => /* @__PURE__ */ new Date();
    HOUR = 36e5;
    DAY = 24 * HOUR;
  }
});

// ../../functions/src/domain/policy.ts
var DEFAULT_POLICY;
var init_policy = __esm({
  "../../functions/src/domain/policy.ts"() {
    "use strict";
    DEFAULT_POLICY = {
      passScore: 80,
      maxAttempts: 3,
      completionThreshold: 85,
      pointsTable: { first_pass_quiz: 20, package_completion: 30, on_time_completion: 50 },
      penaltyEnabled: false,
      latePenalty: 0,
      warningHours: [72, 24],
      quietHours: { start: "22:00", end: "07:00" },
      timezone: "Asia/Tehran",
      weeklyDigestDay: 6,
      weeklyDigestHour: 9,
      reminderInactiveDays: 3,
      mentorChatEnabled: true,
      mentorDailyLimitPerUser: 20,
      mentorDailyLimitGlobal: 2e3
    };
  }
});

// ../../functions/src/services/context.ts
async function getPolicy(d) {
  const cached = policyCache.get(d);
  const now = d.clock().getTime();
  if (cached && now - cached.at < 3e4) return cached.value;
  const doc = await d.store.get("policies/global");
  const value = { ...DEFAULT_POLICY, updatedAt: "", updatedBy: null, ...doc ?? {} };
  policyCache.set(d, { at: now, value });
  return value;
}
function invalidatePolicy(d) {
  policyCache.delete(d);
}
function mask(v) {
  if (Array.isArray(v)) return v.map(mask);
  if (v && typeof v === "object" && !(v instanceof Date)) {
    return Object.fromEntries(
      Object.entries(v).map(([k, x]) => [k, SENSITIVE.test(k) ? "***" : mask(x)])
    );
  }
  return v;
}
async function audit(d, actor, action, entity, entityId, before = null, after = null) {
  const now = d.clock();
  await d.store.set(`audit_logs/${d.store.newId()}`, {
    actorId: actor.id,
    actorRole: actor.role,
    action,
    entity,
    entityId,
    before: mask(before) ?? null,
    after: mask(after) ?? null,
    ip: actor.ip ?? null,
    userAgent: actor.userAgent ?? null,
    createdAt: now.toISOString(),
    expireAt: new Date(now.getTime() + 365 * DAY)
  });
}
async function track(d, name, userId, props = {}) {
  const now = d.clock();
  await d.store.set(`analytics_events/${d.store.newId()}`, {
    name,
    userId,
    props,
    ts: now.toISOString(),
    expireAt: new Date(now.getTime() + 180 * DAY)
  });
}
var nowIso, policyCache, SENSITIVE;
var init_context = __esm({
  "../../functions/src/services/context.ts"() {
    "use strict";
    init_time();
    init_policy();
    nowIso = (d) => d.clock().toISOString();
    policyCache = /* @__PURE__ */ new WeakMap();
    SENSITIVE = /password|token|secret|apikey/i;
  }
});

// ../../functions/src/services/catalog-cache.ts
async function allBrands(d) {
  const c = brandCache.get(d);
  const now = d.clock().getTime();
  if (c && now - c.at < 6e4) return c.brands;
  const brands = await d.store.query({ collection: "brands" });
  brands.sort((a, b) => a.sortOrder - b.sortOrder || a.name.localeCompare(b.name, "fa"));
  brandCache.set(d, { at: now, brands });
  return brands;
}
function invalidateBrands(d) {
  brandCache.delete(d);
}
async function productsById(d, idsList) {
  const uniq = [...new Set(idsList.filter(Boolean))];
  const docs = await d.store.getMany(uniq.map((id2) => `products/${id2}`));
  const m = /* @__PURE__ */ new Map();
  for (const p of docs) if (p) m.set(p.id, p);
  return m;
}
var brandCache;
var init_catalog_cache = __esm({
  "../../functions/src/services/catalog-cache.ts"() {
    "use strict";
    brandCache = /* @__PURE__ */ new WeakMap();
  }
});

// ../../functions/src/services/learning-state.ts
var learning_state_exports = {};
__export(learning_state_exports, {
  assignedPackageIds: () => assignedPackageIds,
  assignmentApplies: () => assignmentApplies,
  computeNextItem: () => computeNextItem,
  computePackageView: () => computePackageView,
  computeUserPackages: () => computeUserPackages,
  loadShared: () => loadShared,
  loadUserLearning: () => loadUserLearning,
  sectionScore: () => sectionScore,
  sortPackages: () => sortPackages
});
function assignmentApplies(a, user) {
  if (a.revokedAt) return false;
  switch (a.type) {
    case "global":
      return true;
    case "user":
      return a.targetId === user.id;
    case "team":
      return !!user.teamId && a.targetId === user.teamId;
    case "brand":
      return !!a.targetId && user.brandIds.includes(a.targetId);
  }
}
function assignedPackageIds(assignments, user) {
  const out = /* @__PURE__ */ new Set();
  for (const a of assignments)
    if (assignmentApplies(a, user)) for (const p of a.packageIds) out.add(p);
  return out;
}
function sectionScore(s) {
  if (s.mediaCompleted && s.quizPassed) return 100;
  return Math.min(90, Math.round(s.percent * 0.9));
}
function computePackageView(shared, pkg, progress, completion) {
  const nowIso2 = shared.now.toISOString();
  const sections = [];
  let prevDone = true;
  const ordered = [...pkg.sections].sort((a, b) => a.order - b.order);
  for (const s of ordered) {
    const p = progress.get(s.id);
    if (s.archived && !p) continue;
    const mediaCompleted = !!p?.completed;
    const quizPassed = !!p?.quizPassed;
    const done = mediaCompleted && quizPassed;
    let state;
    let lockReason = null;
    if (done) state = "completed";
    else if (!prevDone) {
      state = "locked";
      lockReason = "\u0627\u0628\u062A\u062F\u0627 \u0642\u0633\u0645\u062A \u0642\u0628\u0644 \u0631\u0627 \u06A9\u0627\u0645\u0644 \u06A9\u0646\u06CC\u062F \u0648 \u062F\u0631 \u0622\u0632\u0645\u0648\u0646 \u0622\u0646 \u0642\u0628\u0648\u0644 \u0634\u0648\u06CC\u062F.";
    } else if (mediaCompleted) state = "quiz";
    else if ((p?.playedSeconds ?? 0) > 0) state = "in_progress";
    else state = "open";
    sections.push({
      id: s.id,
      order: s.order,
      title: s.title,
      mediaType: s.mediaType,
      durationSec: s.durationSec,
      quizId: s.quizId,
      percent: p?.percent ?? 0,
      mediaCompleted,
      quizPassed,
      lastPositionSec: p?.lastPositionSec ?? 0,
      state,
      lockReason,
      archived: s.archived
    });
    if (!s.archived) prevDone = prevDone && done;
  }
  const active = sections.filter((s) => !s.archived);
  const totalDur = active.reduce((a, s) => a + Math.max(1, s.durationSec), 0);
  const percent = totalDur > 0 ? Math.round(
    active.reduce((a, s) => a + sectionScore(s) * Math.max(1, s.durationSec), 0) / totalDur
  ) : 0;
  const allDone = active.length > 0 && active.every((s) => s.state === "completed");
  const anyProgress = sections.some((s) => s.percent > 0 || s.quizPassed);
  const lastActivity = [...progress.values()].map((p) => p.updatedAt).sort().pop() ?? null;
  const brand = pkg.brandId ? shared.brands.get(pkg.brandId) : void 0;
  const product = pkg.productId ? shared.products.get(pkg.productId) : void 0;
  const status = allDone || completion ? "completed" : anyProgress ? "in_progress" : "new";
  return {
    id: pkg.id,
    title: pkg.title,
    description: pkg.description,
    brand: brand ? { id: brand.id, name: brand.name, logoUrl: brand.logoUrl } : null,
    product: product ? { id: product.id, name: product.name, imageUrl: product.imageUrl } : null,
    deadlineAt: pkg.deadlineAt,
    estimatedMinutes: pkg.estimatedMinutes,
    status,
    packageStatus: pkg.status,
    percent: status === "completed" ? 100 : percent,
    overdue: status !== "completed" && !!pkg.deadlineAt && pkg.deadlineAt < nowIso2,
    completedAt: completion?.completedAt ?? null,
    onTime: completion ? completion.onTime : null,
    lastActivityAt: lastActivity,
    pathOrder: shared.pathOrder.get(pkg.id) ?? 9999,
    sections,
    totalDurationSec: active.reduce((a, s) => a + s.durationSec, 0)
  };
}
function sortPackages(list) {
  return [...list].sort((a, b) => {
    const ad = a.deadlineAt ?? "9999";
    const bd = b.deadlineAt ?? "9999";
    if (ad !== bd) return ad < bd ? -1 : 1;
    if (a.pathOrder !== b.pathOrder) return a.pathOrder - b.pathOrder;
    return a.title.localeCompare(b.title, "fa");
  });
}
function computeNextItem(list) {
  for (const p of sortPackages(list)) {
    if (p.status === "completed" || p.packageStatus === "archived") continue;
    const s = p.sections.find(
      (x) => !x.archived && x.state !== "completed" && x.state !== "locked"
    );
    if (!s) continue;
    return {
      packageId: p.id,
      packageTitle: p.title,
      sectionId: s.id,
      sectionTitle: s.title,
      action: s.state === "quiz" ? "quiz" : s.state === "in_progress" ? "resume" : "start",
      deadlineAt: p.deadlineAt,
      percent: s.percent,
      mediaType: s.mediaType,
      durationSec: s.durationSec,
      imageUrl: p.product?.imageUrl ?? p.brand?.logoUrl ?? null
    };
  }
  return null;
}
async function loadShared(d, extraPackageIds = []) {
  const [assignments, published, brands, paths] = await Promise.all([
    d.store.query({ collection: "assignments", where: [["revokedAt", "==", null]] }),
    d.store.query({ collection: "packages", where: [["status", "==", "published"]] }),
    allBrands(d),
    d.store.query({
      collection: "learning_paths",
      where: [["archived", "==", false]]
    })
  ]);
  const packages = new Map(published.map((p) => [p.id, p]));
  const missing = extraPackageIds.filter((id2) => !packages.has(id2));
  if (missing.length) {
    for (const p of await d.store.getMany(
      [...new Set(missing)].map((id2) => `packages/${id2}`)
    )) {
      if (p && p.status !== "draft") packages.set(p.id, p);
    }
  }
  const products = await productsById(
    d,
    [...packages.values()].map((p) => p.productId ?? "").filter(Boolean)
  );
  const pathOrder = /* @__PURE__ */ new Map();
  for (const path3 of paths)
    for (const it of path3.items)
      if (!pathOrder.has(it.packageId)) pathOrder.set(it.packageId, it.order);
  return {
    now: d.clock(),
    assignments,
    packages,
    brands: new Map(brands.map((b) => [b.id, b])),
    products,
    pathOrder
  };
}
async function loadUserLearning(d, user, shared) {
  const [progressRows, completions] = await Promise.all([
    d.store.query({
      collection: "section_progress",
      where: [["userId", "==", user.id]]
    }),
    d.store.query({
      collection: "package_completions",
      where: [["userId", "==", user.id]]
    })
  ]);
  const startedIds = [...new Set(progressRows.map((p) => p.packageId))];
  const sh = shared ?? await loadShared(d, startedIds);
  if (shared) {
    const missing = startedIds.filter((id2) => !sh.packages.has(id2));
    if (missing.length) {
      for (const p of await d.store.getMany(missing.map((id2) => `packages/${id2}`)))
        if (p && p.status !== "draft") sh.packages.set(p.id, p);
    }
  }
  return { packages: computeUserPackages(sh, user, progressRows, completions), progressRows };
}
function computeUserPackages(sh, user, progressRows, completions) {
  const assigned = assignedPackageIds(sh.assignments, user);
  const started = new Set(progressRows.map((p) => p.packageId));
  const byPkg = /* @__PURE__ */ new Map();
  for (const r of progressRows) {
    let m = byPkg.get(r.packageId);
    if (!m) byPkg.set(r.packageId, m = /* @__PURE__ */ new Map());
    m.set(r.sectionId, r);
  }
  const compByPkg = new Map(completions.map((c) => [c.packageId, c]));
  const out = [];
  for (const pkg of sh.packages.values()) {
    const visible = pkg.status === "published" && assigned.has(pkg.id) || started.has(pkg.id) && pkg.status !== "draft";
    if (!visible) continue;
    out.push(computePackageView(sh, pkg, byPkg.get(pkg.id) ?? /* @__PURE__ */ new Map(), compByPkg.get(pkg.id)));
  }
  return sortPackages(out);
}
var init_learning_state = __esm({
  "../../functions/src/services/learning-state.ts"() {
    "use strict";
    init_catalog_cache();
  }
});

// ../../functions/src/lib/ids.ts
import { createHash } from "node:crypto";
function normalizePhone(input) {
  const latin = input.replace(/[۰-۹]/g, (d) => String("\u06F0\u06F1\u06F2\u06F3\u06F4\u06F5\u06F6\u06F7\u06F8\u06F9".indexOf(d))).replace(/[٠-٩]/g, (d) => String("\u0660\u0661\u0662\u0663\u0664\u0665\u0666\u0667\u0668\u0669".indexOf(d))).replace(/[\s\-()]/g, "");
  let p = latin;
  if (p.startsWith("+98")) p = `0${p.slice(3)}`;
  else if (p.startsWith("0098")) p = `0${p.slice(4)}`;
  else if (p.startsWith("98") && p.length === 12) p = `0${p.slice(2)}`;
  else if (p.startsWith("9") && p.length === 10) p = `0${p}`;
  return /^09\d{9}$/.test(p) ? p : null;
}
function phoneToAuthEmail(phone) {
  return `${phone}@${PHONE_EMAIL_DOMAIN}`;
}
function extractYoutubeId(url) {
  const s = url.trim();
  if (/^[\w-]{11}$/.test(s)) return s;
  let u;
  try {
    u = new URL(s);
  } catch {
    return null;
  }
  const host = u.hostname.replace(/^www\.|^m\./, "");
  let id2 = null;
  if (host === "youtu.be") id2 = u.pathname.slice(1).split("/")[0] ?? null;
  else if (host === "youtube.com" || host === "youtube-nocookie.com") {
    if (u.pathname === "/watch") id2 = u.searchParams.get("v");
    else {
      const m = /^\/(?:embed|shorts|live|v)\/([\w-]{11})/.exec(u.pathname);
      id2 = m?.[1] ?? null;
    }
  }
  return id2 && /^[\w-]{11}$/.test(id2) ? id2 : null;
}
var ids, PHONE_EMAIL_DOMAIN;
var init_ids = __esm({
  "../../functions/src/lib/ids.ts"() {
    "use strict";
    ids = {
      attempt: (userId, quizId, n) => `${userId}_${quizId}_${n}`,
      progress: (userId, sectionId) => `${userId}_${sectionId}`,
      points: (userId, reason, refId) => `${userId}_${reason}_${refId}`,
      userBadge: (userId, badgeId) => `${userId}_${badgeId}`,
      escalation: (userId, packageId, type) => `${userId}_${packageId}_${type}`,
      uniqueKey: (kind, value) => `${kind}_${createHash("sha256").update(value.toLowerCase()).digest("hex").slice(0, 40)}`,
      hash: (s) => createHash("sha256").update(s).digest("hex").slice(0, 40)
    };
    PHONE_EMAIL_DOMAIN = "phone.seylane-sabz.app";
  }
});

// ../../functions/src/services/notify.ts
var notify_exports = {};
__export(notify_exports, {
  DEFAULT_TEMPLATES: () => DEFAULT_TEMPLATES,
  deviceSchema: () => deviceSchema,
  flushDeferredPush: () => flushDeferredPush,
  getTemplates: () => getTemplates,
  manualSend: () => manualSend,
  manualSendSchema: () => manualSendSchema,
  markAllRead: () => markAllRead,
  markNotificationRead: () => markNotificationRead,
  myNotifications: () => myNotifications,
  notifyTemplate: () => notifyTemplate,
  notifyUsers: () => notifyUsers,
  registerDevice: () => registerDevice,
  render: () => render,
  templateSchema: () => templateSchema,
  unregisterDevice: () => unregisterDevice,
  updateTemplate: () => updateTemplate
});
import { z as z2 } from "zod";
function render(tpl, vars) {
  return tpl.replace(
    /\{(\w+)\}/g,
    (_m, k) => vars[k] !== void 0 ? String(vars[k]) : ""
  );
}
async function getTemplates(d) {
  const stored = await d.store.query({
    collection: "notification_templates"
  });
  const byKey = new Map(stored.map((s) => [s.id, s]));
  return Object.keys(DEFAULT_TEMPLATES).map((key) => {
    const def = DEFAULT_TEMPLATES[key];
    const s = byKey.get(key);
    return {
      key,
      title: s?.title ?? def.title,
      body: s?.body ?? def.body,
      variables: def.vars,
      push: def.push,
      customized: !!s,
      updatedAt: s?.updatedAt ?? null
    };
  });
}
async function updateTemplate(d, actor, key, input) {
  const def = DEFAULT_TEMPLATES[key];
  if (!def) throw new ApiError("NOT_FOUND", "\u0642\u0627\u0644\u0628 \u067E\u06CC\u062F\u0627 \u0646\u0634\u062F.");
  const used = [...`${input.title} ${input.body}`.matchAll(/\{(\w+)\}/g)].map((m) => m[1] ?? "");
  const unknown = used.filter((v) => !def.vars.includes(v));
  if (unknown.length)
    throw new ApiError(
      "VALIDATION",
      `\u0645\u062A\u063A\u06CC\u0631 \u0646\u0627\u0645\u0639\u062A\u0628\u0631: ${unknown.join("\u060C ")}. \u0645\u062A\u063A\u06CC\u0631\u0647\u0627\u06CC \u0645\u062C\u0627\u0632: ${def.vars.join("\u060C ")}`
    );
  const before = await d.store.get(`notification_templates/${key}`);
  await d.store.set(`notification_templates/${key}`, {
    ...input,
    updatedAt: d.clock().toISOString()
  });
  await audit(
    d,
    actor,
    "notification_template.updated",
    "notification_templates",
    key,
    before,
    input
  );
  return { key, ...input };
}
async function throttled(d, userId, key, windowMs) {
  const path3 = `notification_log/${ids.hash(`${userId}|${key}`)}`;
  const now = d.clock();
  return d.store.runTransaction(async (tx) => {
    const log = await tx.get(path3);
    if (log && now.getTime() - Date.parse(log.sentAt) < windowMs) return true;
    tx.set(path3, {
      userId,
      key,
      channel: "in_app",
      sentAt: now.toISOString(),
      expireAt: new Date(now.getTime() + 180 * DAY)
    });
    return false;
  });
}
async function sendPush(d, n, type) {
  const tokens = await d.store.query({
    collection: "device_tokens",
    where: [["userId", "==", n.userId]]
  });
  if (!tokens.length) return "skipped";
  const g = GENERIC_PUSH[type];
  try {
    const res = await d.push.send(
      tokens.map((t) => t.token),
      {
        title: g?.title ?? n.title,
        body: g?.body ?? n.body,
        data: { notificationId: n.id, link: n.actionRef ?? "/notifications", type }
      }
    );
    for (const bad of res.invalidTokens) await d.store.delete(`device_tokens/${ids.hash(bad)}`);
    return res.sent > 0 ? "sent" : "failed";
  } catch (e) {
    console.warn("push failed", e.message);
    return "failed";
  }
}
async function notifyUsers(d, userIds, type, content, opts = {}) {
  const policy = await getPolicy(d);
  const def = DEFAULT_TEMPLATES[type];
  const wantPush = opts.push ?? def.push;
  const now = d.clock();
  const quiet = inQuietHours(now, policy.quietHours, policy.timezone);
  const bypassQuiet = opts.priority === "high" && !!opts.urgent;
  let created = 0;
  const uniq = [...new Set(userIds)];
  for (let i = 0; i < uniq.length; i += 50) {
    await Promise.all(
      uniq.slice(i, i + 50).map(async (userId) => {
        if (opts.throttleKey && await throttled(d, userId, opts.throttleKey, opts.throttleMs ?? DAY))
          return;
        const id2 = d.store.newId();
        const deferred = wantPush && quiet && !bypassQuiet;
        const n = {
          userId,
          type,
          title: content.title,
          body: content.body,
          actionRef: opts.actionRef ?? null,
          readAt: null,
          pushStatus: wantPush ? deferred ? "deferred" : "none" : "none",
          deliverAfter: deferred ? quietHoursEnd(now, policy.quietHours, policy.timezone).toISOString() : null,
          createdAt: now.toISOString()
        };
        await d.store.set(`notifications/${id2}`, n);
        created++;
        if (wantPush && !deferred) {
          const status = await sendPush(d, { ...n, id: id2 }, type);
          await d.store.update(`notifications/${id2}`, { pushStatus: status });
        }
      })
    );
  }
  return created;
}
async function notifyTemplate(d, userIds, type, vars, opts = {}) {
  if (!userIds.length) return 0;
  const stored = await d.store.get(`notification_templates/${type}`);
  const def = DEFAULT_TEMPLATES[type];
  return notifyUsers(
    d,
    userIds,
    type,
    {
      title: render(stored?.title ?? def.title, vars),
      body: render(stored?.body ?? def.body, vars)
    },
    opts
  );
}
async function flushDeferredPush(d) {
  const due = await d.store.query({
    collection: "notifications",
    where: [
      ["pushStatus", "==", "deferred"],
      ["deliverAfter", "<=", d.clock().toISOString()]
    ],
    limit: 500
  });
  for (const n of due) {
    const status = await sendPush(d, n, n.type);
    await d.store.update(`notifications/${n.id}`, { pushStatus: status });
  }
  return due.length;
}
async function myNotifications(d, userId) {
  const list = await d.store.query({
    collection: "notifications",
    where: [["userId", "==", userId]],
    orderBy: [["createdAt", "desc"]],
    limit: 50
  });
  return {
    unread: list.filter((n) => !n.readAt).length,
    items: list.map((n) => ({
      id: n.id,
      type: n.type,
      title: n.title,
      body: n.body,
      actionRef: n.actionRef,
      readAt: n.readAt,
      createdAt: n.createdAt
    }))
  };
}
async function markNotificationRead(d, userId, id2) {
  const n = await d.store.get(`notifications/${id2}`);
  if (!n || n.userId !== userId) throw new ApiError("NOT_FOUND");
  if (!n.readAt) {
    await d.store.update(`notifications/${id2}`, { readAt: d.clock().toISOString() });
    await track(d, "notification_opened", userId, { type: n.type });
  }
  return { id: id2, readAt: n.readAt ?? d.clock().toISOString() };
}
async function markAllRead(d, userId) {
  const list = await d.store.query({
    collection: "notifications",
    where: [
      ["userId", "==", userId],
      ["readAt", "==", null]
    ]
  });
  const at = d.clock().toISOString();
  await d.store.batchSet(
    list.map((n) => ({ path: `notifications/${n.id}`, data: { readAt: at }, merge: true }))
  );
  return { count: list.length };
}
async function registerDevice(d, userId, input) {
  await d.store.set(`device_tokens/${ids.hash(input.token)}`, {
    userId,
    token: input.token,
    platform: input.platform,
    lastSeenAt: d.clock().toISOString()
  });
  return { ok: true };
}
async function unregisterDevice(d, userId, token) {
  const path3 = `device_tokens/${ids.hash(token)}`;
  const t = await d.store.get(path3);
  if (t && t.userId === userId) await d.store.delete(path3);
}
async function manualSend(d, actor, input) {
  const where = [["status", "==", "active"]];
  if (input.audience === "team") where.push(["teamId", "==", input.targetId]);
  if (input.audience === "role") where.push(["role", "==", input.targetId]);
  let users = await d.store.query({ collection: "users", where });
  if (input.audience === "user") users = users.filter((u) => u.id === input.targetId);
  if (!users.length) throw new ApiError("VALIDATION", "\u0647\u06CC\u0686 \u06A9\u0627\u0631\u0628\u0631\u06CC \u062F\u0631 \u0627\u06CC\u0646 \u0645\u062E\u0627\u0637\u0628 \u0646\u06CC\u0633\u062A.");
  const count = await notifyUsers(
    d,
    users.map((u) => u.id),
    "manual",
    { title: input.title, body: input.body },
    { priority: "normal" }
  );
  await audit(d, actor, "notification.manual_sent", "notifications", input.audience, null, {
    ...input,
    count
  });
  await track(d, "admin_notification_sent", actor.id, { audience: input.audience, count });
  return { count };
}
var DEFAULT_TEMPLATES, GENERIC_PUSH, templateSchema, deviceSchema, manualSendSchema;
var init_notify = __esm({
  "../../functions/src/services/notify.ts"() {
    "use strict";
    init_errors();
    init_validate();
    init_ids();
    init_time();
    init_context();
    DEFAULT_TEMPLATES = {
      welcome: {
        title: "\u0628\u0647 \u0633\u06CC\u0644\u0627\u0646\u0647\u200C\u0633\u0628\u0632 \u0644\u0631\u0646\u06CC\u0646\u06AF \u062E\u0648\u0634 \u0622\u0645\u062F\u06CC!",
        body: "\u0633\u0644\u0627\u0645 {name}! \u0622\u0645\u0648\u0632\u0634\u200C\u0647\u0627\u06CC\u062A \u062F\u0631 \u0635\u0641\u062D\u0647 \u062E\u0627\u0646\u0647 \u0645\u0646\u062A\u0638\u0631\u062A \u0647\u0633\u062A\u0646\u062F. \u0627\u0632 \xAB\u06A9\u0627\u0631 \u0628\u0639\u062F\u06CC\xBB \u0634\u0631\u0648\u0639 \u06A9\u0646.",
        push: false,
        vars: ["name"]
      },
      new_assignment: {
        title: "\u0622\u0645\u0648\u0632\u0634 \u062C\u062F\u06CC\u062F: {title}",
        body: "\u06CC\u06A9 \u0622\u0645\u0648\u0632\u0634 \u062C\u062F\u06CC\u062F \u0628\u0631\u0627\u06CC\u062A \u0641\u0639\u0627\u0644 \u0634\u062F. \u0645\u0647\u0644\u062A: {deadline}",
        push: true,
        vars: ["title", "deadline"]
      },
      reminder: {
        title: "\u0627\u062F\u0627\u0645\u0647 \u0628\u062F\u0647!",
        body: "{percent}\u066A \u0627\u0632 \xAB{title}\xBB \u0631\u0627 \u0631\u0641\u062A\u06CC \u2014 \u0627\u062F\u0627\u0645\u0647 \u0628\u062F\u0647.",
        push: true,
        vars: ["title", "percent"]
      },
      deadline_warning: {
        title: "{hours} \u0633\u0627\u0639\u062A \u062A\u0627 \u067E\u0627\u06CC\u0627\u0646 \u0645\u0647\u0644\u062A",
        body: "\u0645\u0647\u0644\u062A \xAB{title}\xBB \u0646\u0632\u062F\u06CC\u06A9 \u0627\u0633\u062A. \u0647\u0645\u06CC\u0646 \u062D\u0627\u0644\u0627 \u0627\u062F\u0627\u0645\u0647 \u0628\u062F\u0647.",
        push: true,
        vars: ["title", "hours"]
      },
      deadline_passed: {
        title: "\u0645\u0647\u0644\u062A \u062A\u0645\u0627\u0645 \u0634\u062F",
        body: "\u0645\u0647\u0644\u062A \xAB{title}\xBB \u062A\u0645\u0627\u0645 \u0634\u062F \u0648 \u0628\u0647 \u0645\u062F\u06CC\u0631\u062A \u0627\u0637\u0644\u0627\u0639 \u062F\u0627\u062F\u0647 \u0634\u062F. \u0647\u0646\u0648\u0632 \u0645\u06CC\u200C\u062A\u0648\u0627\u0646\u06CC \u0622\u0646 \u0631\u0627 \u06A9\u0627\u0645\u0644 \u06A9\u0646\u06CC.",
        push: true,
        vars: ["title"]
      },
      quiz_failed: {
        title: "\u0646\u062A\u06CC\u062C\u0647 \u0622\u0632\u0645\u0648\u0646",
        body: "\u062F\u0631 \u0622\u0632\u0645\u0648\u0646 \xAB{title}\xBB \u0642\u0628\u0648\u0644 \u0646\u0634\u062F\u06CC. \u0642\u0633\u0645\u062A \u0631\u0627 \u0645\u0631\u0648\u0631 \u06A9\u0646 \u0648 \u062F\u0648\u0628\u0627\u0631\u0647 \u062A\u0644\u0627\u0634 \u06A9\u0646.",
        push: false,
        vars: ["title"]
      },
      quiz_passed: {
        title: "\u0642\u0628\u0648\u0644 \u0634\u062F\u06CC \u{1F389}",
        body: "\u0622\u0632\u0645\u0648\u0646 \xAB{title}\xBB \u0631\u0627 \u0628\u0627 \u0646\u0645\u0631\u0647 {score}\u066A \u0642\u0628\u0648\u0644 \u0634\u062F\u06CC.",
        push: false,
        vars: ["title", "score"]
      },
      retake_request: {
        title: "\u062F\u0631\u062E\u0648\u0627\u0633\u062A \u062A\u0644\u0627\u0634 \u0645\u062C\u062F\u062F",
        body: "{name} \u0628\u0631\u0627\u06CC \u0622\u0632\u0645\u0648\u0646 \xAB{title}\xBB \u062F\u0631\u062E\u0648\u0627\u0633\u062A \u062A\u0644\u0627\u0634 \u0645\u062C\u062F\u062F \u062F\u0627\u0631\u062F.",
        push: true,
        vars: ["name", "title"]
      },
      retake_reviewed: {
        title: "\u0646\u062A\u06CC\u062C\u0647 \u062F\u0631\u062E\u0648\u0627\u0633\u062A \u062A\u0644\u0627\u0634 \u0645\u062C\u062F\u062F",
        body: "\u062F\u0631\u062E\u0648\u0627\u0633\u062A \u062A\u0644\u0627\u0634 \u0645\u062C\u062F\u062F \u0634\u0645\u0627 \u0628\u0631\u0627\u06CC \xAB{title}\xBB {result} \u0634\u062F.",
        push: false,
        vars: ["title", "result"]
      },
      manager_message: {
        title: "\u067E\u06CC\u0627\u0645 \u0627\u0632 {manager}",
        body: "{snippet}",
        push: true,
        vars: ["manager", "snippet"]
      },
      mentor_nudge: { title: "\u0645\u0646\u062A\u0648\u0631", body: "{message}", push: false, vars: ["message"] },
      weekly_digest: {
        title: "\u06AF\u0632\u0627\u0631\u0634 \u0647\u0641\u062A\u06AF\u06CC \u062A\u06CC\u0645",
        body: "{count} \u0646\u0641\u0631 \u0627\u0632 \u062A\u06CC\u0645 \u0634\u0645\u0627 \u0639\u0642\u0628\u200C\u0627\u0646\u062F. \u0628\u0631\u0627\u06CC \u067E\u06CC\u06AF\u06CC\u0631\u06CC \u0648\u0627\u0631\u062F \u067E\u0646\u0644 \u0634\u0648\u06CC\u062F.",
        push: true,
        vars: ["count"]
      },
      badge_earned: {
        title: "\u0646\u0634\u0627\u0646 \u062C\u062F\u06CC\u062F!",
        body: "\u0646\u0634\u0627\u0646 \xAB{title}\xBB \u0631\u0627 \u06AF\u0631\u0641\u062A\u06CC!",
        push: false,
        vars: ["title"]
      },
      escalation: { title: "\u0646\u06CC\u0627\u0632 \u0628\u0647 \u0628\u0631\u0631\u0633\u06CC", body: "{body}", push: true, vars: ["body"] },
      manual: { title: "{title}", body: "{body}", push: true, vars: ["title", "body"] }
    };
    GENERIC_PUSH = {
      manager_message: { title: "\u067E\u06CC\u0627\u0645 \u062C\u062F\u06CC\u062F", body: "\u0645\u062F\u06CC\u0631\u062A \u0628\u0631\u0627\u06CC\u062A \u067E\u06CC\u0627\u0645 \u0641\u0631\u0633\u062A\u0627\u062F." },
      retake_request: { title: "\u062F\u0631\u062E\u0648\u0627\u0633\u062A \u062A\u0644\u0627\u0634 \u0645\u062C\u062F\u062F", body: "\u06CC\u06A9 \u062F\u0631\u062E\u0648\u0627\u0633\u062A \u062A\u0644\u0627\u0634 \u0645\u062C\u062F\u062F \u0645\u0646\u062A\u0638\u0631 \u0628\u0631\u0631\u0633\u06CC \u0627\u0633\u062A." }
    };
    templateSchema = z2.object({ title: text(2, 80, "\u0639\u0646\u0648\u0627\u0646"), body: text(2, 300, "\u0645\u062A\u0646") });
    deviceSchema = z2.object({
      token: z2.string().min(10).max(4096),
      platform: z2.enum(["web", "android"])
    });
    manualSendSchema = z2.object({
      audience: z2.enum(["all", "team", "user", "role"]),
      targetId: z2.string().max(80).nullable().optional(),
      title: text(2, 80, "\u0639\u0646\u0648\u0627\u0646"),
      body: text(2, 300, "\u0645\u062A\u0646")
    }).refine((v) => v.audience === "all" || !!v.targetId, {
      message: "\u0645\u062E\u0627\u0637\u0628 \u0631\u0627 \u0627\u0646\u062A\u062E\u0627\u0628 \u06A9\u0646\u06CC\u062F.",
      path: ["targetId"]
    });
  }
});

// ../../functions/src/services/assignments.ts
var assignments_exports = {};
__export(assignments_exports, {
  applyPathDeadlines: () => applyPathDeadlines,
  archivePath: () => archivePath,
  assignmentSchema: () => assignmentSchema,
  createAssignment: () => createAssignment,
  createPath: () => createPath,
  formatFaDate: () => formatFaDate,
  listAssignments: () => listAssignments,
  listPaths: () => listPaths,
  notifyAssignedUsers: () => notifyAssignedUsers,
  pathSchema: () => pathSchema,
  revokeAssignment: () => revokeAssignment,
  updatePath: () => updatePath
});
import { z as z3 } from "zod";
function formatFaDate(iso) {
  if (!iso) return "\u0628\u062F\u0648\u0646 \u0645\u0647\u0644\u062A";
  return new Intl.DateTimeFormat("fa-IR", {
    timeZone: "Asia/Tehran",
    month: "long",
    day: "numeric"
  }).format(new Date(iso));
}
async function validateTarget(d, type, targetId) {
  if (type === "global") return;
  const col = type === "team" ? "teams" : type === "user" ? "users" : "brands";
  const t = await d.store.get(`${col}/${targetId}`);
  if (!t) throw new ApiError("VALIDATION", "\u0645\u062E\u0627\u0637\u0628 \u0627\u0646\u062A\u0633\u0627\u0628 \u0645\u0639\u062A\u0628\u0631 \u0646\u06CC\u0633\u062A.");
  if (type === "user" && t.status !== "active")
    throw new ApiError("VALIDATION", "\u06A9\u0627\u0631\u0628\u0631 \u0627\u0646\u062A\u062E\u0627\u0628\u200C\u0634\u062F\u0647 \u063A\u06CC\u0631\u0641\u0639\u0627\u0644 \u0627\u0633\u062A.");
}
async function usersForAssignment(d, a) {
  const where = [
    ["status", "==", "active"],
    ["role", "==", "marketer"]
  ];
  if (a.type === "team") where.push(["teamId", "==", a.targetId]);
  if (a.type === "brand") where.push(["brandIds", "array-contains", a.targetId]);
  let users = await d.store.query({ collection: "users", where });
  if (a.type === "user") users = users.filter((u) => u.id === a.targetId);
  return users.filter((u) => assignmentApplies(a, u));
}
async function listAssignments(d, includeRevoked = false) {
  const list = await d.store.query({
    collection: "assignments",
    where: includeRevoked ? [] : [["revokedAt", "==", null]]
  });
  return list.sort((a, b) => a.createdAt < b.createdAt ? 1 : -1);
}
async function createAssignment(d, actor, input, opts = {}) {
  const targetId = input.type === "global" ? null : input.targetId ?? null;
  await validateTarget(d, input.type, targetId);
  const pkgIds = [...new Set(input.packageIds)].sort();
  const pkgs = await d.store.getMany(pkgIds.map((id3) => `packages/${id3}`));
  if (pkgs.some((p) => !p)) throw new ApiError("VALIDATION", "\u06CC\u06A9\u06CC \u0627\u0632 \u0628\u0633\u062A\u0647\u200C\u0647\u0627 \u067E\u06CC\u062F\u0627 \u0646\u0634\u062F.");
  if (pkgs.some((p) => p?.status === "archived"))
    throw new ApiError("VALIDATION", "\u0628\u0633\u062A\u0647 \u0628\u0627\u06CC\u06AF\u0627\u0646\u06CC\u200C\u0634\u062F\u0647 \u0631\u0627 \u0646\u0645\u06CC\u200C\u062A\u0648\u0627\u0646 \u0627\u0646\u062A\u0633\u0627\u0628 \u062F\u0627\u062F.");
  const existing = await d.store.query({
    collection: "assignments",
    where: [
      ["type", "==", input.type],
      ["targetId", "==", targetId],
      ["revokedAt", "==", null]
    ]
  });
  const same = existing.find(
    (a2) => (a2.pathId ?? null) === (opts.pathId ?? null) && [...a2.packageIds].sort().join(",") === pkgIds.join(",")
  );
  const now = d.clock();
  const warnings = [];
  for (const p of pkgs) {
    if (!p) continue;
    if (p.status === "draft")
      warnings.push(`\xAB${p.title}\xBB \u0647\u0646\u0648\u0632 \u0645\u0646\u062A\u0634\u0631 \u0646\u0634\u062F\u0647 \u0648 \u067E\u0633 \u0627\u0632 \u0627\u0646\u062A\u0634\u0627\u0631 \u062F\u06CC\u062F\u0647 \u0645\u06CC\u200C\u0634\u0648\u062F.`);
    if (p.deadlineAt && p.deadlineAt < now.toISOString())
      warnings.push(`\u0645\u0647\u0644\u062A \xAB${p.title}\xBB \u06AF\u0630\u0634\u062A\u0647 \u0627\u0633\u062A.`);
    else if (p.deadlineAt && Date.parse(p.deadlineAt) - now.getTime() < 72 * HOUR)
      warnings.push(`\u0645\u0647\u0644\u062A \xAB${p.title}\xBB \u06A9\u0645\u062A\u0631 \u0627\u0632 \u06F7\u06F2 \u0633\u0627\u0639\u062A \u062F\u06CC\u06AF\u0631 \u0627\u0633\u062A.`);
  }
  if (same) return { assignment: same, created: false, warnings, notified: 0 };
  const id2 = d.store.newId();
  const a = {
    type: input.type,
    targetId,
    packageIds: pkgIds,
    createdBy: actor.id,
    createdAt: now.toISOString(),
    revokedAt: null,
    revokedBy: null,
    pathId: opts.pathId ?? null
  };
  await d.store.set(`assignments/${id2}`, a);
  await audit(d, actor, "assignment.created", "assignments", id2, null, a);
  const users = await usersForAssignment(d, a);
  let notified = 0;
  for (const p of pkgs) {
    if (!p || p.status !== "published") continue;
    notified += await notifyTemplate(
      d,
      users.map((u) => u.id),
      "new_assignment",
      { title: p.title, deadline: formatFaDate(p.deadlineAt) },
      {
        actionRef: `/packages/${p.id}`,
        priority: "high",
        throttleKey: `assign_${p.id}`,
        throttleMs: 3650 * DAY
      }
    );
  }
  await track(d, "admin_assignment_created", actor.id, { type: input.type, count: users.length });
  return { assignment: { id: id2, ...a }, created: true, warnings, notified };
}
async function revokeAssignment(d, actor, id2) {
  const a = await d.store.get(`assignments/${id2}`);
  if (!a) throw new ApiError("NOT_FOUND", "\u0627\u0646\u062A\u0633\u0627\u0628 \u067E\u06CC\u062F\u0627 \u0646\u0634\u062F.");
  if (a.revokedAt) return a;
  const patch = { revokedAt: nowIso(d), revokedBy: actor.id };
  await d.store.update(`assignments/${id2}`, patch);
  await audit(d, actor, "assignment.revoked", "assignments", id2, a, patch);
  await track(d, "admin_assignment_cancelled", actor.id, { type: a.type });
  return { ...a, ...patch, id: id2 };
}
async function notifyAssignedUsers(d, packageIds) {
  const assignments = await d.store.query({
    collection: "assignments",
    where: [["revokedAt", "==", null]]
  });
  for (const pid of packageIds) {
    const pkg = await d.store.get(`packages/${pid}`);
    if (!pkg || pkg.status !== "published") continue;
    const userIds = /* @__PURE__ */ new Set();
    for (const a of assignments.filter((x) => x.packageIds.includes(pid)))
      for (const u of await usersForAssignment(d, a)) userIds.add(u.id);
    await notifyTemplate(
      d,
      [...userIds],
      "new_assignment",
      { title: pkg.title, deadline: formatFaDate(pkg.deadlineAt) },
      {
        actionRef: `/packages/${pid}`,
        priority: "high",
        throttleKey: `assign_${pid}`,
        throttleMs: 3650 * DAY
      }
    );
  }
}
async function listPaths(d) {
  const list = await d.store.query({
    collection: "learning_paths",
    where: [["archived", "==", false]]
  });
  return list.sort((a, b) => a.name.localeCompare(b.name, "fa"));
}
async function normalizePath(d, input) {
  const targetId = input.scope === "global" ? null : input.targetId ?? null;
  if (input.scope !== "global" && !targetId)
    throw new ApiError("VALIDATION", "\u0645\u062E\u0627\u0637\u0628 \u0645\u0633\u06CC\u0631 \u0631\u0627 \u0627\u0646\u062A\u062E\u0627\u0628 \u06A9\u0646\u06CC\u062F.");
  await validateTarget(d, input.scope, targetId);
  const pkgs = await d.store.getMany(input.items.map((i) => `packages/${i.packageId}`));
  if (pkgs.some((p) => !p)) throw new ApiError("VALIDATION", "\u06CC\u06A9\u06CC \u0627\u0632 \u0628\u0633\u062A\u0647\u200C\u0647\u0627\u06CC \u0645\u0633\u06CC\u0631 \u067E\u06CC\u062F\u0627 \u0646\u0634\u062F.");
  const seen = /* @__PURE__ */ new Set();
  for (const i of input.items) {
    if (seen.has(i.packageId)) throw new ApiError("VALIDATION", "\u06CC\u06A9 \u0628\u0633\u062A\u0647 \u062F\u0648 \u0628\u0627\u0631 \u062F\u0631 \u0645\u0633\u06CC\u0631 \u0622\u0645\u062F\u0647 \u0627\u0633\u062A.");
    seen.add(i.packageId);
  }
  return {
    name: input.name,
    description: input.description ?? "",
    scope: input.scope,
    targetId,
    startAt: input.startAt ?? null,
    items: input.items.map((i, idx) => ({
      packageId: i.packageId,
      order: idx + 1,
      deadlineOffsetDays: i.deadlineOffsetDays ?? null
    }))
  };
}
async function syncPath(d, actor, id2, path3) {
  const active = await d.store.query({
    collection: "assignments",
    where: [
      ["pathId", "==", id2],
      ["revokedAt", "==", null]
    ]
  });
  const pkgIds = path3.items.map((i) => i.packageId);
  let notified = 0;
  let warnings = [];
  let keepId = null;
  if (!path3.archived && pkgIds.length) {
    const r = await createAssignment(
      d,
      actor,
      { type: path3.scope, targetId: path3.targetId, packageIds: pkgIds },
      { pathId: id2 }
    );
    keepId = r.assignment.id;
    notified = r.notified;
    warnings = r.warnings;
  }
  for (const a of active) if (a.id !== keepId) await revokeAssignment(d, actor, a.id);
  let deadlinesUpdated = 0;
  if (!path3.archived && path3.startAt && path3.items.some((i) => i.deadlineOffsetDays !== null))
    deadlinesUpdated = (await applyPathDeadlines(d, actor, id2)).updated.length;
  return { notified, warnings, deadlinesUpdated };
}
async function createPath(d, actor, input) {
  const data = await normalizePath(d, input);
  const id2 = d.store.newId();
  const now = nowIso(d);
  const path3 = { ...data, archived: false, createdAt: now, updatedAt: now };
  await d.store.set(`learning_paths/${id2}`, path3);
  await audit(d, actor, "path.created", "learning_paths", id2, null, path3);
  await track(d, "admin_path_created", actor.id, { items: path3.items.length });
  return { id: id2, ...path3, ...await syncPath(d, actor, id2, path3) };
}
async function updatePath(d, actor, id2, input) {
  const prev = await d.store.get(`learning_paths/${id2}`);
  if (!prev) throw new ApiError("NOT_FOUND", "\u0645\u0633\u06CC\u0631 \u067E\u06CC\u062F\u0627 \u0646\u0634\u062F.");
  const data = { ...await normalizePath(d, input), updatedAt: nowIso(d) };
  await d.store.update(`learning_paths/${id2}`, data);
  await audit(d, actor, "path.updated", "learning_paths", id2, prev, data);
  const next = { ...prev, ...data };
  return { ...next, id: id2, ...await syncPath(d, actor, id2, next) };
}
async function archivePath(d, actor, id2) {
  const prev = await d.store.get(`learning_paths/${id2}`);
  if (!prev) throw new ApiError("NOT_FOUND", "\u0645\u0633\u06CC\u0631 \u067E\u06CC\u062F\u0627 \u0646\u0634\u062F.");
  await d.store.update(`learning_paths/${id2}`, { archived: true, updatedAt: nowIso(d) });
  await audit(d, actor, "path.archived", "learning_paths", id2, prev, { archived: true });
  await syncPath(d, actor, id2, { ...prev, archived: true });
}
async function applyPathDeadlines(d, actor, id2) {
  const path3 = await d.store.get(`learning_paths/${id2}`);
  if (!path3) throw new ApiError("NOT_FOUND", "\u0645\u0633\u06CC\u0631 \u067E\u06CC\u062F\u0627 \u0646\u0634\u062F.");
  if (!path3.startAt)
    throw new ApiError("VALIDATION", "\u0628\u0631\u0627\u06CC \u0645\u062D\u0627\u0633\u0628\u0647 \u0645\u0647\u0644\u062A\u200C\u0647\u0627\u060C \u062A\u0627\u0631\u06CC\u062E \u0634\u0631\u0648\u0639 \u0645\u0633\u06CC\u0631 \u0631\u0627 \u062A\u0639\u06CC\u06CC\u0646 \u06A9\u0646\u06CC\u062F.");
  const updated = [];
  for (const it of path3.items) {
    if (it.deadlineOffsetDays === null) continue;
    const deadlineAt = new Date(
      Date.parse(path3.startAt) + it.deadlineOffsetDays * DAY
    ).toISOString();
    if (deadlineAt <= d.clock().toISOString()) continue;
    await d.store.update(`packages/${it.packageId}`, { deadlineAt, updatedAt: nowIso(d) });
    updated.push({ packageId: it.packageId, deadlineAt });
  }
  await audit(d, actor, "path.deadlines_applied", "learning_paths", id2, null, updated);
  return { updated };
}
var assignmentSchema, pathSchema;
var init_assignments = __esm({
  "../../functions/src/services/assignments.ts"() {
    "use strict";
    init_errors();
    init_validate();
    init_time();
    init_context();
    init_learning_state();
    init_notify();
    assignmentSchema = z3.object({
      type: z3.enum(["global", "team", "user", "brand"]),
      targetId: z3.string().max(80).nullable().optional(),
      packageIds: z3.array(z3.string().max(80)).min(1, "\u062D\u062F\u0627\u0642\u0644 \u06CC\u06A9 \u0628\u0633\u062A\u0647 \u0627\u0646\u062A\u062E\u0627\u0628 \u06A9\u0646\u06CC\u062F.").max(100)
    }).refine((a) => a.type === "global" || !!a.targetId, {
      message: "\u0645\u062E\u0627\u0637\u0628 \u0627\u0646\u062A\u0633\u0627\u0628 \u0631\u0627 \u0627\u0646\u062A\u062E\u0627\u0628 \u06A9\u0646\u06CC\u062F.",
      path: ["targetId"]
    });
    pathSchema = z3.object({
      name: text(2, 80, "\u0646\u0627\u0645 \u0645\u0633\u06CC\u0631"),
      description: z3.string().trim().max(1e3).optional().default(""),
      scope: z3.enum(["global", "team", "user", "brand"]),
      targetId: z3.string().max(80).nullable().optional(),
      startAt: isoDate("\u062A\u0627\u0631\u06CC\u062E \u0634\u0631\u0648\u0639").nullable().optional(),
      items: z3.array(
        z3.object({
          packageId: z3.string().max(80),
          deadlineOffsetDays: z3.number().int().min(0, "\u0645\u0647\u0644\u062A \u0645\u0631\u062D\u0644\u0647 \u0646\u0645\u06CC\u200C\u062A\u0648\u0627\u0646\u062F \u0645\u0646\u0641\u06CC \u0628\u0627\u0634\u062F.").max(365).nullable().optional()
        })
      ).max(100)
    });
  }
});

// ../../functions/src/mail/smtp.ts
var smtp_exports = {};
__export(smtp_exports, {
  SmtpMailer: () => SmtpMailer
});
var SmtpMailer;
var init_smtp = __esm({
  "../../functions/src/mail/smtp.ts"() {
    "use strict";
    SmtpMailer = class {
      constructor(url, from) {
        this.from = from;
        this.transport = import("nodemailer").then((m) => m.createTransport(url));
      }
      from;
      enabled = true;
      transport;
      async send(msg) {
        await (await this.transport).sendMail({ from: this.from, ...msg });
      }
    };
  }
});

// netlify/functions/api.mts
import { randomBytes as randomBytes3 } from "node:crypto";
import http from "node:http";

// ../../functions/src/app.ts
import cors from "cors";
import express from "express";
import helmet from "helmet";

// ../../functions/src/blob/local.ts
import { createHmac, timingSafeEqual } from "node:crypto";
import fs from "node:fs";
import path from "node:path";
var LocalBlobStore = class {
  constructor(root, secret, now = () => Date.now()) {
    this.root = root;
    this.secret = secret;
    this.now = now;
    fs.mkdirSync(root, { recursive: true });
  }
  root;
  secret;
  now;
  resolve(p) {
    const full = path.resolve(this.root, p);
    if (!full.startsWith(path.resolve(this.root) + path.sep))
      throw new Error("Path escapes blob root");
    return full;
  }
  signTicket(t) {
    const body = Buffer.from(JSON.stringify(t)).toString("base64url");
    const sig = createHmac("sha256", this.secret).update(body).digest("base64url");
    return `${body}.${sig}`;
  }
  verifyTicket(token, op) {
    const [body, sig] = token.split(".");
    if (!body || !sig) return null;
    const expected = createHmac("sha256", this.secret).update(body).digest("base64url");
    const a = Buffer.from(sig);
    const b = Buffer.from(expected);
    if (a.length !== b.length || !timingSafeEqual(a, b)) return null;
    try {
      const t = JSON.parse(Buffer.from(body, "base64url").toString("utf8"));
      if (t.op !== op || t.exp < this.now()) return null;
      return t;
    } catch {
      return null;
    }
  }
  async put(p, data, contentType) {
    const full = this.resolve(p);
    fs.mkdirSync(path.dirname(full), { recursive: true });
    fs.writeFileSync(full, data);
    fs.writeFileSync(`${full}.meta.json`, JSON.stringify({ contentType }));
  }
  /** Links an existing file (seed from repository media without copying). */
  linkFrom(p, source, contentType) {
    const full = this.resolve(p);
    fs.mkdirSync(path.dirname(full), { recursive: true });
    if (fs.existsSync(full)) fs.rmSync(full);
    try {
      fs.linkSync(source, full);
    } catch {
      fs.copyFileSync(source, full);
    }
    fs.writeFileSync(`${full}.meta.json`, JSON.stringify({ contentType }));
  }
  async createUploadUrl(p, contentType, maxBytes) {
    const exp = this.now() + 15 * 6e4;
    const token = this.signTicket({ p, ct: contentType, max: maxBytes, exp, op: "put" });
    return {
      url: `/v1/uploads/${token}`,
      method: "PUT",
      headers: { "Content-Type": contentType },
      expiresAt: new Date(exp).toISOString()
    };
  }
  async stat(p) {
    const full = this.resolve(p);
    if (!fs.existsSync(full)) return null;
    const meta = fs.existsSync(`${full}.meta.json`) ? JSON.parse(fs.readFileSync(`${full}.meta.json`, "utf8")) : { contentType: "application/octet-stream" };
    return { size: fs.statSync(full).size, contentType: meta.contentType };
  }
  async readRange(p, start, end) {
    const full = this.resolve(p);
    const fd = fs.openSync(full, "r");
    try {
      const len = Math.max(0, end - start + 1);
      const buf = Buffer.alloc(len);
      const n = fs.readSync(fd, buf, 0, len, start);
      return buf.subarray(0, n);
    } finally {
      fs.closeSync(fd);
    }
  }
  async signedReadUrl(p, ttlSec) {
    const token = this.signTicket({
      p,
      ct: "",
      max: 0,
      exp: this.now() + ttlSec * 1e3,
      op: "get"
    });
    return `/v1/files/signed/${token}`;
  }
  async publicUrl(p) {
    return `/v1/files/public/${p.split("/").map(encodeURIComponent).join("/")}`;
  }
  async delete(p) {
    const full = this.resolve(p);
    fs.rmSync(full, { force: true });
    fs.rmSync(`${full}.meta.json`, { force: true });
  }
};

// ../../functions/src/http/auth.ts
init_errors();
function authenticate(d) {
  return (req, _res, next) => {
    const header = req.headers.authorization ?? "";
    const alt = req.headers["x-access-token"];
    const token = typeof alt === "string" && alt.trim() ? alt.trim() : header.startsWith("Bearer ") ? header.slice(7).trim() : "";
    if (!token) return next(new ApiError("UNAUTHENTICATED"));
    d.auth.verify(token).then(async (claims) => {
      if (!claims) throw new ApiError("UNAUTHENTICATED");
      const user = await d.store.get(`users/${claims.uid}`);
      if (!user) throw new ApiError("UNAUTHENTICATED");
      if (user.status !== "active")
        throw new ApiError(
          "UNAUTHENTICATED",
          "\u062D\u0633\u0627\u0628 \u0634\u0645\u0627 \u063A\u06CC\u0631\u0641\u0639\u0627\u0644 \u0634\u062F\u0647 \u0627\u0633\u062A. \u0628\u0627 \u0645\u062F\u06CC\u0631 \u062E\u0648\u062F \u062A\u0645\u0627\u0633 \u0628\u06AF\u06CC\u0631\u06CC\u062F."
        );
      req.user = user;
      next();
    }).catch(next);
  };
}
function requireRole(...roles) {
  return (req, _res, next) => {
    if (!req.user || !roles.includes(req.user.role)) return next(new ApiError("FORBIDDEN"));
    next();
  };
}
function me(req) {
  if (!req.user) throw new ApiError("UNAUTHENTICATED");
  return req.user;
}
function actorOf(req) {
  const u = me(req);
  return {
    id: u.id,
    role: u.role,
    ip: req.ip ?? null,
    userAgent: req.get("user-agent")?.slice(0, 200) ?? null
  };
}
function h(fn, status = 200) {
  return (req, res, next) => {
    fn(req, res).then((data) => {
      if (res.headersSent) return;
      if (status === 204) res.status(204).end();
      else res.status(status).json({ data });
    }).catch(next);
  };
}

// ../../functions/src/http/middleware.ts
init_errors();
var notFoundHandler = (_req, res) => {
  const err = new ApiError("NOT_FOUND");
  res.status(err.status).json(toErrorBody(err));
};
var errorHandler = (err, _req, res, _next) => {
  if (err instanceof ApiError) {
    res.status(err.status).json(toErrorBody(err));
    return;
  }
  if (typeof err === "object" && err !== null && "type" in err) {
    const type = err.type;
    if (type === "entity.too.large") {
      const e2 = new ApiError("VALIDATION", "\u062D\u062C\u0645 \u0627\u0637\u0644\u0627\u0639\u0627\u062A \u0627\u0631\u0633\u0627\u0644\u06CC \u0628\u06CC\u0634 \u0627\u0632 \u062D\u062F \u0645\u062C\u0627\u0632 \u0627\u0633\u062A.");
      res.status(413).json(toErrorBody(e2));
      return;
    }
    if (type === "entity.parse.failed") {
      const e2 = new ApiError("VALIDATION");
      res.status(e2.status).json(toErrorBody(e2));
      return;
    }
  }
  console.error("Unhandled API error", err);
  const e = new ApiError("INTERNAL");
  res.status(e.status).json(toErrorBody(e));
};

// ../../functions/src/http/rateLimit.ts
init_errors();
var RateLimiter = class {
  constructor(now = () => Date.now(), scale = 1) {
    this.now = now;
    this.scale = scale;
  }
  now;
  scale;
  buckets = /* @__PURE__ */ new Map();
  hit(key, baseLimit, windowMs) {
    const limit = baseLimit * this.scale;
    const t = this.now();
    if (this.buckets.size > 2e4) {
      for (const [k, b2] of this.buckets) if (b2.resetAt <= t) this.buckets.delete(k);
    }
    const b = this.buckets.get(key);
    if (!b || b.resetAt <= t) {
      this.buckets.set(key, { count: 1, resetAt: t + windowMs });
      return true;
    }
    b.count++;
    return b.count <= limit;
  }
  reset() {
    this.buckets.clear();
  }
};
function rateLimit(limiter, name, limit, windowMs, keyFn, message) {
  return (req, _res, next) => {
    if (!limiter.hit(`${name}:${keyFn(req)}`, limit, windowMs))
      return next(new ApiError("RATE_LIMIT", message));
    next();
  };
}

// ../../functions/src/routes/admin.ts
import { Router } from "express";
import { z as z9 } from "zod";
init_validate();
init_assignments();

// ../../functions/src/services/content.ts
init_errors();
init_validate();
init_ids();
import { z as z4 } from "zod";

// ../../functions/src/lib/media.ts
var MEDIA_RULES = {
  audio: {
    mimes: [
      "audio/mpeg",
      "audio/mp4",
      "audio/x-m4a",
      "audio/m4a",
      "audio/aac",
      "audio/wav",
      "audio/x-wav",
      "audio/wave",
      "audio/ogg"
    ],
    maxBytes: 100 * 1024 * 1024,
    label: "\u0635\u0648\u062A"
  },
  video: {
    mimes: [
      "video/mp4",
      "video/quicktime",
      "video/webm",
      "video/x-matroska",
      "video/3gpp",
      "video/x-msvideo",
      "video/avi"
    ],
    maxBytes: 500 * 1024 * 1024,
    label: "\u0648\u06CC\u062F\u06CC\u0648"
  },
  image: {
    mimes: ["image/png", "image/jpeg", "image/webp"],
    maxBytes: 5 * 1024 * 1024,
    label: "\u062A\u0635\u0648\u06CC\u0631"
  }
};
var EXT = {
  "audio/mpeg": "mp3",
  "audio/mp4": "m4a",
  "audio/x-m4a": "m4a",
  "audio/m4a": "m4a",
  "audio/aac": "aac",
  "audio/wav": "wav",
  "audio/x-wav": "wav",
  "audio/wave": "wav",
  "audio/ogg": "ogg",
  "video/mp4": "mp4",
  "video/quicktime": "mov",
  "video/webm": "webm",
  "video/x-matroska": "mkv",
  "video/3gpp": "3gp",
  "video/x-msvideo": "avi",
  "video/avi": "avi",
  "image/png": "png",
  "image/jpeg": "jpg",
  "image/webp": "webp"
};
function sniff(buf) {
  if (buf.length < 12) return null;
  const ascii = (s, e) => buf.subarray(s, e).toString("latin1");
  if (ascii(4, 8) === "ftyp") {
    const brand = ascii(8, 12);
    if (brand === "M4A " || brand === "M4B ") return { mime: "audio/mp4", kinds: ["audio"] };
    if (brand === "qt  ") return { mime: "video/quicktime", kinds: ["video"] };
    if (brand.startsWith("3g")) return { mime: "video/3gpp", kinds: ["video", "audio"] };
    return { mime: "video/mp4", kinds: ["video", "audio"] };
  }
  if (buf[0] === 26 && buf[1] === 69 && buf[2] === 223 && buf[3] === 163) {
    return ascii(0, Math.min(buf.length, 64)).includes("webm") ? { mime: "video/webm", kinds: ["video", "audio"] } : { mime: "video/x-matroska", kinds: ["video"] };
  }
  if (ascii(0, 4) === "RIFF") {
    const sub = ascii(8, 12);
    if (sub === "AVI ") return { mime: "video/x-msvideo", kinds: ["video"] };
    if (sub === "WAVE") return { mime: "audio/wav", kinds: ["audio"] };
    if (sub === "WEBP") return { mime: "image/webp", kinds: ["image"] };
  }
  if (ascii(0, 4) === "OggS") return { mime: "audio/ogg", kinds: ["audio"] };
  if (ascii(0, 3) === "ID3") return { mime: "audio/mpeg", kinds: ["audio"] };
  if (buf[0] === 255 && ((buf[1] ?? 0) & 246) === 240)
    return { mime: "audio/aac", kinds: ["audio"] };
  if (buf[0] === 255 && ((buf[1] ?? 0) & 224) === 224)
    return { mime: "audio/mpeg", kinds: ["audio"] };
  if (buf[0] === 137 && ascii(1, 4) === "PNG") return { mime: "image/png", kinds: ["image"] };
  if (buf[0] === 255 && buf[1] === 216 && buf[2] === 255)
    return { mime: "image/jpeg", kinds: ["image"] };
  return null;
}
function mp4DurationFromBuffer(buf) {
  const idx = buf.indexOf("mvhd", 0, "latin1");
  if (idx < 4) return null;
  const version = buf[idx + 4];
  try {
    if (version === 1) {
      const timescale2 = buf.readUInt32BE(idx + 4 + 4 + 16);
      const duration2 = Number(buf.readBigUInt64BE(idx + 4 + 4 + 16 + 4));
      return timescale2 ? Math.round(duration2 / timescale2 * 10) / 10 : null;
    }
    const timescale = buf.readUInt32BE(idx + 4 + 4 + 8);
    const duration = buf.readUInt32BE(idx + 4 + 4 + 8 + 4);
    return timescale ? Math.round(duration / timescale * 10) / 10 : null;
  } catch {
    return null;
  }
}

// ../../functions/src/services/content.ts
init_context();
init_catalog_cache();
var notFound = (what) => new ApiError("NOT_FOUND", `${what} \u067E\u06CC\u062F\u0627 \u0646\u0634\u062F.`);
async function holdingLogoUrl(d) {
  const s = await d.store.get("settings/branding");
  return s?.holdingLogoUrl ?? "";
}
var brandSchema = z4.object({
  name: text(2, 60, "\u0646\u0627\u0645 \u0628\u0631\u0646\u062F"),
  nameLatin: z4.string().trim().max(60).nullable().optional(),
  sortOrder: z4.number().int().min(0).max(9999).optional()
});
var brandPatchSchema = brandSchema.partial().extend({ archived: z4.boolean().optional(), logoMediaId: z4.string().max(80).optional() });
async function listBrandsAdmin(d) {
  const [brands, products, packages] = await Promise.all([
    d.store.query({ collection: "brands" }),
    d.store.query({ collection: "products", where: [["archived", "==", false]] }),
    d.store.query({ collection: "packages" })
  ]);
  return brands.sort((a, b) => a.sortOrder - b.sortOrder || a.name.localeCompare(b.name, "fa")).map((b) => ({
    ...b,
    productCount: products.filter((p) => p.brandId === b.id).length,
    packageCount: packages.filter((p) => p.brandId === b.id && p.status !== "archived").length
  }));
}
async function assertUniqueBrandName(d, name, exceptId) {
  const same = await d.store.query({ collection: "brands", where: [["name", "==", name]] });
  if (same.some((b) => b.id !== exceptId))
    throw new ApiError("CONFLICT", "\u0628\u0631\u0646\u062F\u06CC \u0628\u0627 \u0627\u06CC\u0646 \u0646\u0627\u0645 \u0648\u062C\u0648\u062F \u062F\u0627\u0631\u062F.");
}
async function createBrand(d, actor, input) {
  await assertUniqueBrandName(d, input.name);
  const id2 = `brand-${d.store.newId().slice(0, 10).toLowerCase()}`;
  const now = nowIso(d);
  const brands = await allBrands(d);
  const brand = {
    name: input.name,
    nameLatin: input.nameLatin ?? null,
    logoUrl: await holdingLogoUrl(d),
    logoPath: null,
    logoIsFallback: true,
    sortOrder: input.sortOrder ?? brands.length + 1,
    archived: false,
    source: "admin",
    createdAt: now,
    updatedAt: now
  };
  await d.store.set(`brands/${id2}`, brand);
  invalidateBrands(d);
  await audit(d, actor, "brand.created", "brands", id2, null, brand);
  return { id: id2, ...brand };
}
async function updateBrand(d, actor, id2, input) {
  const brand = await d.store.get(`brands/${id2}`);
  if (!brand) throw notFound("\u0628\u0631\u0646\u062F");
  if (input.name && input.name !== brand.name) await assertUniqueBrandName(d, input.name, id2);
  const { logoMediaId, ...rest } = input;
  const patch = { ...rest, updatedAt: nowIso(d) };
  if (logoMediaId) {
    const media = await readyMedia(d, logoMediaId, "image");
    if (media.target.type !== "brand_logo" || media.target.id !== id2)
      throw new ApiError("VALIDATION", "\u0627\u06CC\u0646 \u062A\u0635\u0648\u06CC\u0631 \u0628\u0631\u0627\u06CC \u0644\u0648\u06AF\u0648\u06CC \u0627\u06CC\u0646 \u0628\u0631\u0646\u062F \u0622\u067E\u0644\u0648\u062F \u0646\u0634\u062F\u0647 \u0627\u0633\u062A.");
    patch.logoPath = media.path;
    patch.logoUrl = await d.blob.publicUrl(media.path);
    patch.logoIsFallback = false;
  }
  await d.store.update(`brands/${id2}`, patch);
  invalidateBrands(d);
  await audit(
    d,
    actor,
    logoMediaId ? "brand.logo_updated" : "brand.updated",
    "brands",
    id2,
    brand,
    patch
  );
  return { ...brand, ...patch, id: id2 };
}
var productSchema = z4.object({
  brandId: z4.string().min(1, "\u0628\u0631\u0646\u062F \u0631\u0627 \u0627\u0646\u062A\u062E\u0627\u0628 \u06A9\u0646\u06CC\u062F.").max(80),
  name: text(2, 120, "\u0646\u0627\u0645 \u0645\u062D\u0635\u0648\u0644"),
  code: z4.string().trim().max(40).nullable().optional(),
  category: z4.string().trim().max(60).nullable().optional(),
  description: z4.string().trim().max(2e3).nullable().optional()
});
var productPatchSchema = productSchema.partial().extend({ archived: z4.boolean().optional(), imageMediaId: z4.string().max(80).optional() });
async function listProductsAdmin(d, f) {
  const where = [];
  if (f.brandId) where.push(["brandId", "==", f.brandId]);
  if (f.archived !== void 0) where.push(["archived", "==", f.archived]);
  let list = await d.store.query({ collection: "products", where });
  if (f.q)
    list = list.filter((p) => p.name.includes(f.q ?? "") || (p.code ?? "").includes(f.q ?? ""));
  return list.sort((a, b) => a.name.localeCompare(b.name, "fa"));
}
async function createProduct(d, actor, input) {
  const brand = await d.store.get(`brands/${input.brandId}`);
  if (!brand || brand.archived) throw new ApiError("VALIDATION", "\u0628\u0631\u0646\u062F \u0627\u0646\u062A\u062E\u0627\u0628\u200C\u0634\u062F\u0647 \u0645\u0639\u062A\u0628\u0631 \u0646\u06CC\u0633\u062A.");
  const id2 = input.code ? `sb-${input.code.replace(/[^\w-]/g, "")}` : `prd-${d.store.newId().slice(0, 12).toLowerCase()}`;
  if (await d.store.get(`products/${id2}`))
    throw new ApiError("CONFLICT", "\u0645\u062D\u0635\u0648\u0644\u06CC \u0628\u0627 \u0627\u06CC\u0646 \u06A9\u062F \u0648\u062C\u0648\u062F \u062F\u0627\u0631\u062F.");
  const now = nowIso(d);
  const product = {
    brandId: input.brandId,
    name: input.name,
    code: input.code ?? null,
    barcode: null,
    category: input.category ?? null,
    description: input.description ?? null,
    imageUrl: brand.logoUrl,
    imagePath: null,
    imageIsFallback: true,
    archived: false,
    source: "admin",
    createdAt: now,
    updatedAt: now
  };
  await d.store.set(`products/${id2}`, product);
  await audit(d, actor, "product.created", "products", id2, null, product);
  return { id: id2, ...product };
}
async function updateProduct(d, actor, id2, input) {
  const product = await d.store.get(`products/${id2}`);
  if (!product) throw notFound("\u0645\u062D\u0635\u0648\u0644");
  const { imageMediaId, ...rest } = input;
  if (rest.brandId && rest.brandId !== product.brandId) {
    const b = await d.store.get(`brands/${rest.brandId}`);
    if (!b) throw new ApiError("VALIDATION", "\u0628\u0631\u0646\u062F \u0627\u0646\u062A\u062E\u0627\u0628\u200C\u0634\u062F\u0647 \u0645\u0639\u062A\u0628\u0631 \u0646\u06CC\u0633\u062A.");
  }
  const patch = { ...rest, updatedAt: nowIso(d) };
  if (imageMediaId) {
    const media = await readyMedia(d, imageMediaId, "image");
    if (media.target.type !== "product_image" || media.target.id !== id2)
      throw new ApiError("VALIDATION", "\u0627\u06CC\u0646 \u062A\u0635\u0648\u06CC\u0631 \u0628\u0631\u0627\u06CC \u0627\u06CC\u0646 \u0645\u062D\u0635\u0648\u0644 \u0622\u067E\u0644\u0648\u062F \u0646\u0634\u062F\u0647 \u0627\u0633\u062A.");
    patch.imagePath = media.path;
    patch.imageUrl = await d.blob.publicUrl(media.path);
    patch.imageIsFallback = false;
  }
  await d.store.update(`products/${id2}`, patch);
  await audit(
    d,
    actor,
    imageMediaId ? "product.image_updated" : "product.updated",
    "products",
    id2,
    product,
    patch
  );
  return { ...product, ...patch, id: id2 };
}
var uploadUrlSchema = z4.object({
  kind: z4.enum(["video", "audio", "image"]),
  fileName: z4.string().trim().min(1).max(200),
  mime: z4.string().trim().max(100),
  sizeBytes: z4.number().int().positive(),
  target: z4.object({
    type: z4.enum(["section", "brand_logo", "product_image"]),
    id: z4.string().max(80).nullable().optional()
  }).optional()
});
async function createUploadUrl(d, actor, input) {
  const rule = MEDIA_RULES[input.kind];
  const mime = input.mime.toLowerCase();
  if (!rule.mimes.includes(mime))
    throw new ApiError("VALIDATION", `\u0646\u0648\u0639 \u0641\u0627\u06CC\u0644 ${rule.label} \u067E\u0634\u062A\u06CC\u0628\u0627\u0646\u06CC \u0646\u0645\u06CC\u200C\u0634\u0648\u062F.`, {
      allowed: rule.mimes
    });
  if (input.sizeBytes > rule.maxBytes)
    throw new ApiError(
      "VALIDATION",
      `\u062D\u062C\u0645 \u0641\u0627\u06CC\u0644 ${rule.label} \u062D\u062F\u0627\u06A9\u062B\u0631 ${Math.round(rule.maxBytes / 1024 / 1024)} \u0645\u06AF\u0627\u0628\u0627\u06CC\u062A \u0627\u0633\u062A.`
    );
  const target = input.target ?? { type: "section", id: null };
  if (target.type !== "section" && input.kind !== "image")
    throw new ApiError("VALIDATION", "\u0628\u0631\u0627\u06CC \u0644\u0648\u06AF\u0648 \u0648 \u062A\u0635\u0648\u06CC\u0631 \u0645\u062D\u0635\u0648\u0644 \u0641\u0642\u0637 \u062A\u0635\u0648\u06CC\u0631 \u0645\u062C\u0627\u0632 \u0627\u0633\u062A.");
  if (target.type === "brand_logo" && !(target.id && await d.store.get(`brands/${target.id}`)))
    throw notFound("\u0628\u0631\u0646\u062F");
  if (target.type === "product_image" && !(target.id && await d.store.get(`products/${target.id}`)))
    throw notFound("\u0645\u062D\u0635\u0648\u0644");
  const id2 = d.store.newId();
  const ext = EXT[mime] ?? "bin";
  const path3 = target.type === "brand_logo" ? `brands/${target.id}/logo-${id2}.${ext}` : target.type === "product_image" ? `products/${target.id}/main-${id2}.${ext}` : `media/${input.kind}/${id2}.${ext}`;
  const asset = {
    kind: input.kind,
    status: "pending",
    path: path3,
    declaredMime: mime,
    mime: null,
    sizeBytes: null,
    declaredSize: input.sizeBytes,
    originalName: input.fileName.replace(/[^\p{L}\p{N}._\- ]/gu, "_"),
    durationSec: null,
    target: { type: target.type, id: target.id ?? null },
    createdBy: actor.id,
    createdAt: nowIso(d),
    rejectReason: null
  };
  await d.store.set(`media/${id2}`, asset);
  const ticket = await d.blob.createUploadUrl(path3, mime, rule.maxBytes);
  return { mediaId: id2, upload: ticket };
}
var finalizeSchema = z4.object({
  durationSec: z4.number().positive().max(6 * 3600).optional()
});
async function finalizeMedia(d, actor, mediaId, input) {
  const asset = await d.store.get(`media/${mediaId}`);
  if (!asset) throw notFound("\u0641\u0627\u06CC\u0644");
  if (asset.status === "ready") return publicMedia(asset);
  const stat = await d.blob.stat(asset.path);
  if (!stat) throw new ApiError("CONFLICT", "\u0641\u0627\u06CC\u0644 \u0647\u0646\u0648\u0632 \u0622\u067E\u0644\u0648\u062F \u0646\u0634\u062F\u0647 \u0627\u0633\u062A. \u062F\u0648\u0628\u0627\u0631\u0647 \u062A\u0644\u0627\u0634 \u06A9\u0646\u06CC\u062F.");
  const rule = MEDIA_RULES[asset.kind];
  const reject = async (reason) => {
    await d.store.update(`media/${mediaId}`, { status: "rejected", rejectReason: reason });
    await d.blob.delete(asset.path);
    throw new ApiError("VALIDATION", reason);
  };
  if (stat.size > rule.maxBytes) await reject(`\u062D\u062C\u0645 \u0641\u0627\u06CC\u0644 ${rule.label} \u0628\u06CC\u0634 \u0627\u0632 \u062D\u062F \u0645\u062C\u0627\u0632 \u0627\u0633\u062A.`);
  if (stat.size === 0) await reject("\u0641\u0627\u06CC\u0644 \u062E\u0627\u0644\u06CC \u0627\u0633\u062A.");
  const head = await d.blob.readRange(asset.path, 0, 63);
  const detected = sniff(head);
  if (!detected || !detected.kinds.includes(asset.kind))
    await reject(`\u0645\u062D\u062A\u0648\u0627\u06CC \u0641\u0627\u06CC\u0644 \u0628\u0627 \u0646\u0648\u0639 ${rule.label} \u0645\u0637\u0627\u0628\u0642\u062A \u0646\u062F\u0627\u0631\u062F \u06CC\u0627 \u0641\u0631\u0645\u062A \u0622\u0646 \u067E\u0634\u062A\u06CC\u0628\u0627\u0646\u06CC \u0646\u0645\u06CC\u200C\u0634\u0648\u062F.`);
  let duration = input.durationSec ?? null;
  if (!duration && asset.kind !== "image" && detected && ["video/mp4", "audio/mp4", "video/quicktime", "video/3gpp"].includes(detected.mime)) {
    const headBig = await d.blob.readRange(asset.path, 0, Math.min(stat.size, 2 * 1024 * 1024) - 1);
    duration = mp4DurationFromBuffer(headBig);
    if (!duration && stat.size > 2 * 1024 * 1024) {
      const tail = await d.blob.readRange(
        asset.path,
        Math.max(0, stat.size - 4 * 1024 * 1024),
        stat.size - 1
      );
      duration = mp4DurationFromBuffer(tail);
    }
  }
  const mime = detected?.mime === "video/mp4" && asset.kind === "audio" ? "audio/mp4" : detected?.mime ?? asset.declaredMime;
  const patch = { status: "ready", mime, sizeBytes: stat.size, durationSec: duration };
  await d.store.update(`media/${mediaId}`, patch);
  await audit(d, actor, "media.uploaded", "media", mediaId, null, {
    kind: asset.kind,
    mime,
    size: stat.size
  });
  await track(d, "admin_media_uploaded", actor.id, { type: asset.kind });
  return publicMedia({ ...asset, ...patch, id: mediaId });
}
function publicMedia(a) {
  return {
    id: a.id,
    kind: a.kind,
    status: a.status,
    mime: a.mime,
    sizeBytes: a.sizeBytes,
    durationSec: a.durationSec,
    originalName: a.originalName,
    target: a.target
  };
}
async function readyMedia(d, id2, kind) {
  const m = await d.store.get(`media/${id2}`);
  if (!m || m.status !== "ready")
    throw new ApiError("VALIDATION", "\u0641\u0627\u06CC\u0644 \u0627\u0646\u062A\u062E\u0627\u0628\u200C\u0634\u062F\u0647 \u0622\u0645\u0627\u062F\u0647 \u0646\u06CC\u0633\u062A. \u062F\u0648\u0628\u0627\u0631\u0647 \u0622\u067E\u0644\u0648\u062F \u06A9\u0646\u06CC\u062F.");
  if (m.kind !== kind) throw new ApiError("VALIDATION", "\u0646\u0648\u0639 \u0641\u0627\u06CC\u0644 \u0628\u0627 \u0646\u0648\u0639 \u0642\u0633\u0645\u062A \u0645\u0637\u0627\u0628\u0642\u062A \u0646\u062F\u0627\u0631\u062F.");
  return m;
}
var packageSchema = z4.object({
  title: text(3, 120, "\u0639\u0646\u0648\u0627\u0646 \u0628\u0633\u062A\u0647"),
  description: z4.string().trim().max(3e3).optional().default(""),
  brandId: z4.string().max(80).nullable().optional(),
  productId: z4.string().max(80).nullable().optional(),
  deadlineAt: isoDate("\u0645\u0647\u0644\u062A").nullable().optional(),
  estimatedMinutes: z4.number().int().min(0).max(1e3).optional(),
  coverUrl: z4.string().url().max(500).nullable().optional()
});
var packagePatchSchema = packageSchema.partial();
async function validateLinks(d, brandId, productId) {
  let brand = brandId ?? null;
  if (productId) {
    const p = await d.store.get(`products/${productId}`);
    if (!p) throw new ApiError("VALIDATION", "\u0645\u062D\u0635\u0648\u0644 \u0627\u0646\u062A\u062E\u0627\u0628\u200C\u0634\u062F\u0647 \u0645\u0639\u062A\u0628\u0631 \u0646\u06CC\u0633\u062A.");
    if (brand && brand !== p.brandId)
      throw new ApiError("VALIDATION", "\u0645\u062D\u0635\u0648\u0644 \u0628\u0647 \u0628\u0631\u0646\u062F \u0627\u0646\u062A\u062E\u0627\u0628\u200C\u0634\u062F\u0647 \u062A\u0639\u0644\u0642 \u0646\u062F\u0627\u0631\u062F.");
    brand = p.brandId;
  }
  if (brand && !await d.store.get(`brands/${brand}`))
    throw new ApiError("VALIDATION", "\u0628\u0631\u0646\u062F \u0627\u0646\u062A\u062E\u0627\u0628\u200C\u0634\u062F\u0647 \u0645\u0639\u062A\u0628\u0631 \u0646\u06CC\u0633\u062A.");
  return { brandId: brand, productId: productId ?? null };
}
var adminPackageQuery = z4.object({
  brandId: z4.string().max(80).optional(),
  productId: z4.string().max(80).optional(),
  status: z4.enum(["draft", "published", "archived"]).optional(),
  unassigned: z4.enum(["true", "false"]).optional(),
  q: z4.string().max(80).optional()
});
async function listPackagesAdmin(d, f) {
  const where = [];
  if (f.status) where.push(["status", "==", f.status]);
  if (f.productId) where.push(["productId", "==", f.productId]);
  else if (f.brandId) where.push(["brandId", "==", f.brandId]);
  if (f.unassigned === "true") where.push(["brandId", "==", null]);
  let list = await d.store.query({ collection: "packages", where });
  if (f.q) list = list.filter((p) => p.title.includes(f.q ?? ""));
  return list.sort((a, b) => a.updatedAt < b.updatedAt ? 1 : -1);
}
async function getPackageAdmin(d, id2) {
  const pkg = await d.store.get(`packages/${id2}`);
  if (!pkg) throw notFound("\u0628\u0633\u062A\u0647");
  const sections = (await d.store.query({ collection: `packages/${id2}/sections` })).sort(
    (a, b) => a.order - b.order
  );
  const quizzes = await d.store.getMany(sections.map((s) => `quizzes/${s.quizId}`));
  return {
    package: pkg,
    sections: sections.map((s, i) => ({
      ...s,
      quiz: quizzes[i] ? {
        id: quizzes[i]?.id,
        questionCount: quizzes[i]?.questionCount ?? 0,
        needsReview: quizzes[i]?.needsReview ?? false,
        version: quizzes[i]?.version ?? 1
      } : null
    })),
    publishIssues: await validatePublish(d, pkg, sections)
  };
}
async function createPackage(d, actor, input, seedTag = null) {
  const links = await validateLinks(d, input.brandId, input.productId);
  const id2 = d.store.newId();
  const now = nowIso(d);
  const pkg = {
    ...links,
    title: input.title,
    description: input.description ?? "",
    status: "draft",
    deadlineAt: input.deadlineAt ?? null,
    estimatedMinutes: input.estimatedMinutes ?? 0,
    coverUrl: input.coverUrl ?? null,
    sections: [],
    createdBy: actor.id,
    publishedAt: null,
    seedTag,
    createdAt: now,
    updatedAt: now
  };
  await d.store.set(`packages/${id2}`, pkg);
  await audit(d, actor, "package.created", "packages", id2, null, pkg);
  await track(d, "admin_package_created", actor.id, { packageId: id2 });
  return { id: id2, ...pkg };
}
async function updatePackage(d, actor, id2, input) {
  const pkg = await d.store.get(`packages/${id2}`);
  if (!pkg) throw notFound("\u0628\u0633\u062A\u0647");
  const patch = { ...input, updatedAt: nowIso(d) };
  if (input.brandId !== void 0 || input.productId !== void 0) {
    const links = await validateLinks(
      d,
      input.brandId !== void 0 ? input.brandId : pkg.brandId,
      input.productId !== void 0 ? input.productId : pkg.productId
    );
    if (pkg.status === "published" && !links.brandId)
      throw new ApiError("VALIDATION", "\u0628\u0633\u062A\u0647 \u0645\u0646\u062A\u0634\u0631\u0634\u062F\u0647 \u0628\u0627\u06CC\u062F \u0628\u0631\u0646\u062F \u062F\u0627\u0634\u062A\u0647 \u0628\u0627\u0634\u062F.");
    Object.assign(patch, links);
  }
  if (pkg.status === "published" && input.deadlineAt !== void 0) {
    if (!input.deadlineAt) throw new ApiError("VALIDATION", "\u0628\u0633\u062A\u0647 \u0645\u0646\u062A\u0634\u0631\u0634\u062F\u0647 \u0628\u0627\u06CC\u062F \u0645\u0647\u0644\u062A \u062F\u0627\u0634\u062A\u0647 \u0628\u0627\u0634\u062F.");
  }
  await d.store.update(`packages/${id2}`, patch);
  await audit(d, actor, "package.updated", "packages", id2, pkg, patch);
  await track(d, "admin_package_updated", actor.id, { packageId: id2 });
  return { ...pkg, ...patch, id: id2 };
}
async function validatePublish(d, pkg, sectionsIn) {
  const issues = [];
  if (!pkg.brandId) issues.push("\u0628\u0631\u0646\u062F \u0628\u0633\u062A\u0647 \u0645\u0634\u062E\u0635 \u0646\u0634\u062F\u0647 \u0627\u0633\u062A (\u067E\u06CC\u0634\u200C\u0646\u0648\u06CC\u0633 \u0628\u062F\u0648\u0646 \u062A\u062E\u0635\u06CC\u0635).");
  if (!pkg.deadlineAt) issues.push("\u0645\u0647\u0644\u062A \u0628\u0633\u062A\u0647 \u062A\u0639\u06CC\u06CC\u0646 \u0646\u0634\u062F\u0647 \u0627\u0633\u062A.");
  else if (pkg.deadlineAt <= d.clock().toISOString()) issues.push("\u0645\u0647\u0644\u062A \u0628\u0633\u062A\u0647 \u0628\u0627\u06CC\u062F \u062F\u0631 \u0622\u06CC\u0646\u062F\u0647 \u0628\u0627\u0634\u062F.");
  const sections = (sectionsIn ?? await d.store.query({ collection: `packages/${pkg.id}/sections` })).filter((s) => !s.archived);
  if (!sections.length) issues.push("\u0628\u0633\u062A\u0647 \u0628\u0627\u06CC\u062F \u062D\u062F\u0627\u0642\u0644 \u06CC\u06A9 \u0642\u0633\u0645\u062A \u062F\u0627\u0634\u062A\u0647 \u0628\u0627\u0634\u062F.");
  for (const s of sections) {
    const label = `\u0642\u0633\u0645\u062A \xAB${s.title}\xBB`;
    if (!(s.durationSec > 0)) issues.push(`${label}: \u0645\u062F\u062A \u0632\u0645\u0627\u0646 \u0645\u0634\u062E\u0635 \u0646\u06CC\u0633\u062A.`);
    if (s.mediaSource === "youtube" && !s.youtubeId)
      issues.push(`${label}: \u0644\u06CC\u0646\u06A9 \u06CC\u0648\u062A\u06CC\u0648\u0628 \u0645\u0639\u062A\u0628\u0631 \u0646\u06CC\u0633\u062A.`);
    if (s.mediaSource === "file" && !s.mediaPath)
      issues.push(`${label}: \u0641\u0627\u06CC\u0644 \u0631\u0633\u0627\u0646\u0647 \u0622\u067E\u0644\u0648\u062F \u0646\u0634\u062F\u0647 \u0627\u0633\u062A.`);
    const qs = await d.store.query({
      collection: `quizzes/${s.quizId}/questions`,
      where: [["archived", "==", false]]
    });
    if (qs.length < 3) issues.push(`${label}: \u0622\u0632\u0645\u0648\u0646 \u0628\u0627\u06CC\u062F \u062D\u062F\u0627\u0642\u0644 \u06F3 \u0633\u0624\u0627\u0644 \u062F\u0627\u0634\u062A\u0647 \u0628\u0627\u0634\u062F.`);
    if (qs.some((q) => !q.options.some((o) => o.key === q.answerKey)))
      issues.push(`${label}: \u0628\u0631\u0627\u06CC \u0628\u0631\u062E\u06CC \u0633\u0624\u0627\u0644\u200C\u0647\u0627 \u06AF\u0632\u06CC\u0646\u0647 \u0635\u062D\u06CC\u062D \u0627\u0646\u062A\u062E\u0627\u0628 \u0646\u0634\u062F\u0647 \u0627\u0633\u062A.`);
  }
  return issues;
}
async function publishPackage(d, actor, id2) {
  const pkg = await d.store.get(`packages/${id2}`);
  if (!pkg) throw notFound("\u0628\u0633\u062A\u0647");
  if (pkg.status === "published") return pkg;
  const issues = await validatePublish(d, pkg);
  if (issues.length)
    throw new ApiError("VALIDATION", "\u0628\u0633\u062A\u0647 \u0647\u0646\u0648\u0632 \u06A9\u0627\u0645\u0644 \u0646\u06CC\u0633\u062A \u0648 \u0645\u0646\u062A\u0634\u0631 \u0646\u0645\u06CC\u200C\u0634\u0648\u062F.", { issues });
  const now = nowIso(d);
  await d.store.update(`packages/${id2}`, {
    status: "published",
    publishedAt: pkg.publishedAt ?? now,
    updatedAt: now
  });
  await audit(
    d,
    actor,
    "package.published",
    "packages",
    id2,
    { status: pkg.status },
    { status: "published" }
  );
  await track(d, "admin_package_published", actor.id, { packageId: id2 });
  const { notifyAssignedUsers: notifyAssignedUsers2 } = await Promise.resolve().then(() => (init_assignments(), assignments_exports));
  await notifyAssignedUsers2(d, [id2]);
  return { ...pkg, status: "published", id: id2 };
}
async function unpublishPackage(d, actor, id2) {
  const pkg = await d.store.get(`packages/${id2}`);
  if (!pkg) throw notFound("\u0628\u0633\u062A\u0647");
  const started = await d.store.query({
    collection: "section_progress",
    where: [["packageId", "==", id2]],
    limit: 1
  });
  if (started.length)
    throw new ApiError(
      "CONFLICT",
      "\u0628\u0639\u0636\u06CC \u06A9\u0627\u0631\u0628\u0631\u0627\u0646 \u0627\u06CC\u0646 \u0628\u0633\u062A\u0647 \u0631\u0627 \u0634\u0631\u0648\u0639 \u06A9\u0631\u062F\u0647\u200C\u0627\u0646\u062F\u061B \u0628\u0647\u200C\u062C\u0627\u06CC \u0644\u063A\u0648 \u0627\u0646\u062A\u0634\u0627\u0631\u060C \u0622\u0646 \u0631\u0627 \u0628\u0627\u06CC\u06AF\u0627\u0646\u06CC \u06A9\u0646\u06CC\u062F."
    );
  await d.store.update(`packages/${id2}`, { status: "draft", updatedAt: nowIso(d) });
  await audit(
    d,
    actor,
    "package.unpublished",
    "packages",
    id2,
    { status: pkg.status },
    { status: "draft" }
  );
  return { ...pkg, status: "draft", id: id2 };
}
async function archivePackage(d, actor, id2) {
  const pkg = await d.store.get(`packages/${id2}`);
  if (!pkg) throw notFound("\u0628\u0633\u062A\u0647");
  await d.store.update(`packages/${id2}`, { status: "archived", updatedAt: nowIso(d) });
  await audit(
    d,
    actor,
    "package.archived",
    "packages",
    id2,
    { status: pkg.status },
    { status: "archived" }
  );
  await track(d, "admin_package_archived", actor.id, { packageId: id2 });
  return { ...pkg, status: "archived", id: id2 };
}
var sectionSchema = z4.object({
  title: text(2, 120, "\u0639\u0646\u0648\u0627\u0646 \u0642\u0633\u0645\u062A"),
  description: z4.string().trim().max(3e3).optional().default(""),
  transcript: z4.string().trim().max(2e4).optional().default(""),
  mediaType: z4.enum(["video", "audio"]),
  mediaSource: z4.enum(["youtube", "file"]),
  youtubeUrl: z4.string().trim().max(300).nullable().optional(),
  mediaId: z4.string().max(80).nullable().optional(),
  durationSec: z4.number().positive("\u0645\u062F\u062A \u0632\u0645\u0627\u0646 \u0628\u0627\u06CC\u062F \u0628\u06CC\u0634\u062A\u0631 \u0627\u0632 \u0635\u0641\u0631 \u0628\u0627\u0634\u062F.").max(6 * 3600).optional()
}).refine((s) => !(s.mediaType === "audio" && s.mediaSource === "youtube"), {
  message: "\u0642\u0633\u0645\u062A \u0635\u0648\u062A\u06CC \u0641\u0642\u0637 \u0628\u0627 \u0641\u0627\u06CC\u0644 \u0622\u067E\u0644\u0648\u062F\u06CC \u0645\u0645\u06A9\u0646 \u0627\u0633\u062A.",
  path: ["mediaSource"]
});
var sectionPatchSchema = z4.object({
  title: text(2, 120, "\u0639\u0646\u0648\u0627\u0646 \u0642\u0633\u0645\u062A").optional(),
  description: z4.string().trim().max(3e3).optional(),
  transcript: z4.string().trim().max(2e4).optional(),
  mediaType: z4.enum(["video", "audio"]).optional(),
  mediaSource: z4.enum(["youtube", "file"]).optional(),
  youtubeUrl: z4.string().trim().max(300).nullable().optional(),
  mediaId: z4.string().max(80).nullable().optional(),
  durationSec: z4.number().positive().max(6 * 3600).optional(),
  archived: z4.boolean().optional()
});
async function resolveMedia(d, s) {
  if (s.mediaSource === "youtube") {
    const yid = s.youtubeUrl ? extractYoutubeId(s.youtubeUrl) : null;
    if (!yid)
      throw new ApiError(
        "VALIDATION",
        "\u0644\u06CC\u0646\u06A9 \u06CC\u0648\u062A\u06CC\u0648\u0628 \u0645\u0639\u062A\u0628\u0631 \u0646\u06CC\u0633\u062A. \u0646\u0645\u0648\u0646\u0647: https://youtu.be/xxxxxxxxxxx",
        { field: "youtubeUrl" }
      );
    if (!s.durationSec)
      throw new ApiError("VALIDATION", "\u0645\u062F\u062A \u0632\u0645\u0627\u0646 \u0648\u06CC\u062F\u06CC\u0648 \u0631\u0627 \u0648\u0627\u0631\u062F \u06A9\u0646\u06CC\u062F.", { field: "durationSec" });
    return {
      youtubeUrl: s.youtubeUrl ?? null,
      youtubeId: yid,
      mediaId: null,
      mediaPath: null,
      mediaMime: null,
      mediaSizeBytes: null,
      durationSec: s.durationSec
    };
  }
  if (!s.mediaId)
    throw new ApiError("VALIDATION", "\u0641\u0627\u06CC\u0644 \u0631\u0633\u0627\u0646\u0647 \u0631\u0627 \u0622\u067E\u0644\u0648\u062F \u06A9\u0646\u06CC\u062F.", { field: "mediaId" });
  const m = await readyMedia(d, s.mediaId, s.mediaType);
  const durationSec = s.durationSec ?? m.durationSec ?? 0;
  if (!(durationSec > 0))
    throw new ApiError("VALIDATION", "\u0645\u062F\u062A \u0632\u0645\u0627\u0646 \u0641\u0627\u06CC\u0644 \u0645\u0634\u062E\u0635 \u0646\u0634\u062F\u061B \u0622\u0646 \u0631\u0627 \u0648\u0627\u0631\u062F \u06A9\u0646\u06CC\u062F.", {
      field: "durationSec"
    });
  return {
    youtubeUrl: null,
    youtubeId: null,
    mediaId: m.id,
    mediaPath: m.path,
    mediaMime: m.mime,
    mediaSizeBytes: m.sizeBytes,
    durationSec
  };
}
async function refreshPackageSummary(d, packageId) {
  const sections = (await d.store.query({ collection: `packages/${packageId}/sections` })).sort((a, b) => a.order - b.order);
  const summary = sections.map((s) => ({
    id: s.id,
    order: s.order,
    title: s.title,
    mediaType: s.mediaType,
    durationSec: s.durationSec,
    quizId: s.quizId,
    archived: s.archived
  }));
  const minutes = Math.round(
    sections.filter((s) => !s.archived).reduce((a, s) => a + s.durationSec, 0) / 60
  );
  await d.store.update(`packages/${packageId}`, {
    sections: summary,
    estimatedMinutes: Math.max(1, minutes),
    updatedAt: nowIso(d)
  });
}
async function createSection(d, actor, packageId, input) {
  const pkg = await d.store.get(`packages/${packageId}`);
  if (!pkg) throw notFound("\u0628\u0633\u062A\u0647");
  if (pkg.status === "archived")
    throw new ApiError("CONFLICT", "\u0628\u0633\u062A\u0647 \u0628\u0627\u06CC\u06AF\u0627\u0646\u06CC\u200C\u0634\u062F\u0647 \u0642\u0627\u0628\u0644 \u0648\u06CC\u0631\u0627\u06CC\u0634 \u0646\u06CC\u0633\u062A.");
  const media = await resolveMedia(d, input);
  const existing = await d.store.query({ collection: `packages/${packageId}/sections` });
  const id2 = d.store.newId();
  const quizId = d.store.newId();
  const now = nowIso(d);
  const section = {
    packageId,
    order: existing.reduce((m, s) => Math.max(m, s.order), 0) + 1,
    title: input.title,
    description: input.description ?? "",
    transcript: input.transcript ?? "",
    mediaType: input.mediaType,
    mediaSource: input.mediaSource,
    ...media,
    quizId,
    archived: false,
    createdAt: now,
    updatedAt: now
  };
  const quiz = {
    sectionId: id2,
    packageId,
    passScore: null,
    maxAttempts: null,
    version: 1,
    active: true,
    questionCount: 0,
    needsReview: false,
    createdAt: now,
    updatedAt: now
  };
  await d.store.set(
    `packages/${packageId}/sections/${id2}`,
    section
  );
  await d.store.set(`section_index/${id2}`, { packageId });
  await d.store.set(`quizzes/${quizId}`, quiz);
  await refreshPackageSummary(d, packageId);
  await audit(d, actor, "section.created", "sections", id2, null, section);
  return { id: id2, ...section };
}
async function updateSection(d, actor, packageId, sectionId, input) {
  const path3 = `packages/${packageId}/sections/${sectionId}`;
  const s = await d.store.get(path3);
  if (!s) throw notFound("\u0642\u0633\u0645\u062A");
  const patch = { updatedAt: nowIso(d) };
  for (const k of ["title", "description", "transcript", "archived"])
    if (input[k] !== void 0) patch[k] = input[k];
  const mediaTouched = ["mediaType", "mediaSource", "youtubeUrl", "mediaId", "durationSec"].some(
    (k) => input[k] !== void 0
  );
  if (mediaTouched) {
    const merged = {
      mediaType: input.mediaType ?? s.mediaType,
      mediaSource: input.mediaSource ?? s.mediaSource,
      youtubeUrl: input.youtubeUrl !== void 0 ? input.youtubeUrl : s.youtubeUrl,
      mediaId: input.mediaId !== void 0 ? input.mediaId : s.mediaId,
      durationSec: input.durationSec ?? s.durationSec
    };
    if (merged.mediaType === "audio" && merged.mediaSource === "youtube")
      throw new ApiError("VALIDATION", "\u0642\u0633\u0645\u062A \u0635\u0648\u062A\u06CC \u0641\u0642\u0637 \u0628\u0627 \u0641\u0627\u06CC\u0644 \u0622\u067E\u0644\u0648\u062F\u06CC \u0645\u0645\u06A9\u0646 \u0627\u0633\u062A.");
    Object.assign(
      patch,
      { mediaType: merged.mediaType, mediaSource: merged.mediaSource },
      await resolveMedia(d, merged)
    );
  }
  await d.store.update(path3, patch);
  await refreshPackageSummary(d, packageId);
  await audit(
    d,
    actor,
    input.archived ? "section.archived" : "section.updated",
    "sections",
    sectionId,
    s,
    patch
  );
  return { ...s, ...patch, id: sectionId };
}
var reorderSchema = z4.object({ ids: z4.array(z4.string().max(80)).min(1).max(200) });
async function reorderSections(d, actor, packageId, orderIds) {
  const sections = await d.store.query({ collection: `packages/${packageId}/sections` });
  const known = new Set(sections.map((s) => s.id));
  if (orderIds.length !== sections.length || orderIds.some((id2) => !known.has(id2)))
    throw new ApiError("VALIDATION", "\u062A\u0631\u062A\u06CC\u0628 \u0627\u0631\u0633\u0627\u0644\u06CC \u0628\u0627 \u0642\u0633\u0645\u062A\u200C\u0647\u0627\u06CC \u0628\u0633\u062A\u0647 \u0645\u0637\u0627\u0628\u0642\u062A \u0646\u062F\u0627\u0631\u062F.");
  await d.store.batchSet(
    orderIds.map((id2, i) => ({
      path: `packages/${packageId}/sections/${id2}`,
      data: { order: i + 1 },
      merge: true
    }))
  );
  await refreshPackageSummary(d, packageId);
  await audit(
    d,
    actor,
    "section.reordered",
    "packages",
    packageId,
    sections.map((s) => s.id),
    orderIds
  );
  return { ok: true };
}
var OPTION_KEYS = ["a", "b", "c", "d"];
var questionSchema = z4.object({
  stem: text(3, 500, "\u0645\u062A\u0646 \u0633\u0624\u0627\u0644"),
  options: z4.array(text(1, 200, "\u06AF\u0632\u06CC\u0646\u0647")).length(4, "\u0647\u0631 \u0633\u0624\u0627\u0644 \u0628\u0627\u06CC\u062F \u06F4 \u06AF\u0632\u06CC\u0646\u0647 \u062F\u0627\u0634\u062A\u0647 \u0628\u0627\u0634\u062F."),
  answerKey: z4.enum(["a", "b", "c", "d"], {
    errorMap: () => ({ message: "\u06AF\u0632\u06CC\u0646\u0647 \u0635\u062D\u06CC\u062D \u0627\u0646\u062A\u062E\u0627\u0628 \u0646\u0634\u062F\u0647 \u0627\u0633\u062A." })
  }),
  explanation: z4.string().trim().max(500).optional().default("")
}).refine((q) => new Set(q.options.map((o) => o.trim())).size === q.options.length, {
  message: "\u06AF\u0632\u06CC\u0646\u0647\u200C\u0647\u0627\u06CC \u062A\u06A9\u0631\u0627\u0631\u06CC \u0645\u062C\u0627\u0632 \u0646\u06CC\u0633\u062A.",
  path: ["options"]
});
var quizSettingsSchema = z4.object({
  passScore: z4.number().int().min(1).max(100).nullable().optional(),
  maxAttempts: z4.number().int().min(1).max(10).nullable().optional(),
  needsReview: z4.boolean().optional()
});
async function getQuizAdmin(d, quizId) {
  const quiz = await d.store.get(`quizzes/${quizId}`);
  if (!quiz) throw notFound("\u0622\u0632\u0645\u0648\u0646");
  const questions = (await d.store.query({ collection: `quizzes/${quizId}/questions` })).sort((a, b) => a.order - b.order);
  return {
    quiz,
    questions: questions.filter((q) => !q.archived),
    archivedCount: questions.filter((q) => q.archived).length
  };
}
async function bumpQuiz(d, quizId) {
  const qs = await d.store.query({
    collection: `quizzes/${quizId}/questions`,
    where: [["archived", "==", false]]
  });
  const quiz = await d.store.get(`quizzes/${quizId}`);
  await d.store.update(`quizzes/${quizId}`, {
    version: (quiz?.version ?? 1) + 1,
    questionCount: qs.length,
    updatedAt: nowIso(d)
  });
}
async function addQuestion(d, actor, quizId, input) {
  const quiz = await d.store.get(`quizzes/${quizId}`);
  if (!quiz) throw notFound("\u0622\u0632\u0645\u0648\u0646");
  const existing = await d.store.query({
    collection: `quizzes/${quizId}/questions`,
    where: [["archived", "==", false]]
  });
  if (existing.length >= 20) throw new ApiError("VALIDATION", "\u0647\u0631 \u0622\u0632\u0645\u0648\u0646 \u062D\u062F\u0627\u06A9\u062B\u0631 \u06F2\u06F0 \u0633\u0624\u0627\u0644 \u062F\u0627\u0631\u062F.");
  const id2 = d.store.newId();
  const now = nowIso(d);
  const q = {
    order: existing.reduce((m, x) => Math.max(m, x.order), 0) + 1,
    stem: input.stem,
    options: input.options.map((t, i) => ({ key: OPTION_KEYS[i] ?? String(i), text: t })),
    answerKey: input.answerKey,
    explanation: input.explanation ?? "",
    version: 1,
    archived: false,
    createdAt: now,
    updatedAt: now
  };
  await d.store.set(`quizzes/${quizId}/questions/${id2}`, q);
  await bumpQuiz(d, quizId);
  await audit(d, actor, "question.created", "questions", id2, null, q);
  await track(d, existing.length === 0 ? "admin_quiz_created" : "admin_quiz_updated", actor.id, {
    quizId
  });
  return { id: id2, ...q };
}
async function updateQuestion(d, actor, quizId, questionId, input) {
  const path3 = `quizzes/${quizId}/questions/${questionId}`;
  const q = await d.store.get(path3);
  if (!q || q.archived) throw notFound("\u0633\u0624\u0627\u0644");
  const patch = {
    stem: input.stem,
    options: input.options.map((t, i) => ({ key: OPTION_KEYS[i] ?? String(i), text: t })),
    answerKey: input.answerKey,
    explanation: input.explanation ?? "",
    version: q.version + 1,
    updatedAt: nowIso(d)
  };
  await d.store.update(path3, patch);
  await bumpQuiz(d, quizId);
  await audit(d, actor, "question.updated", "questions", questionId, q, patch);
  await track(d, "admin_quiz_updated", actor.id, { quizId });
  return { ...q, ...patch, id: questionId };
}
async function archiveQuestion(d, actor, quizId, questionId) {
  const path3 = `quizzes/${quizId}/questions/${questionId}`;
  const q = await d.store.get(path3);
  if (!q) throw notFound("\u0633\u0624\u0627\u0644");
  await d.store.update(path3, { archived: true, updatedAt: nowIso(d) });
  await bumpQuiz(d, quizId);
  await audit(d, actor, "question.archived", "questions", questionId, q, { archived: true });
}
async function reorderQuestions(d, actor, quizId, orderIds) {
  const qs = await d.store.query({
    collection: `quizzes/${quizId}/questions`,
    where: [["archived", "==", false]]
  });
  const known = new Set(qs.map((q) => q.id));
  if (orderIds.length !== qs.length || orderIds.some((id2) => !known.has(id2)))
    throw new ApiError("VALIDATION", "\u062A\u0631\u062A\u06CC\u0628 \u0627\u0631\u0633\u0627\u0644\u06CC \u0628\u0627 \u0633\u0624\u0627\u0644\u200C\u0647\u0627\u06CC \u0622\u0632\u0645\u0648\u0646 \u0645\u0637\u0627\u0628\u0642\u062A \u0646\u062F\u0627\u0631\u062F.");
  await d.store.batchSet(
    orderIds.map((id2, i) => ({
      path: `quizzes/${quizId}/questions/${id2}`,
      data: { order: i + 1 },
      merge: true
    }))
  );
  await audit(d, actor, "question.reordered", "quizzes", quizId, null, orderIds);
  return { ok: true };
}
async function updateQuizSettings(d, actor, quizId, input) {
  const quiz = await d.store.get(`quizzes/${quizId}`);
  if (!quiz) throw notFound("\u0622\u0632\u0645\u0648\u0646");
  const patch = { ...input, updatedAt: nowIso(d) };
  await d.store.update(`quizzes/${quizId}`, patch);
  await audit(d, actor, "quiz.settings_updated", "quizzes", quizId, quiz, patch);
  return { ...quiz, ...patch, id: quizId };
}
async function contentTree(d) {
  const [brands, products, packages] = await Promise.all([
    d.store.query({ collection: "brands", where: [["archived", "==", false]] }),
    d.store.query({ collection: "products", where: [["archived", "==", false]] }),
    d.store.query({ collection: "packages" })
  ]);
  const livePk = packages.filter((p) => p.status !== "archived");
  return {
    brands: brands.sort((a, b) => a.sortOrder - b.sortOrder).map((b) => ({
      id: b.id,
      name: b.name,
      logoUrl: b.logoUrl,
      logoIsFallback: b.logoIsFallback,
      productCount: products.filter((p) => p.brandId === b.id).length,
      brandLevelPackages: livePk.filter((p) => p.brandId === b.id && !p.productId).length,
      packageCount: livePk.filter((p) => p.brandId === b.id).length
    })),
    unassignedCount: livePk.filter((p) => !p.brandId).length
  };
}

// ../../functions/src/services/jobs.ts
init_time();
init_ids();
init_context();
init_learning_state();
init_notify();

// ../../functions/src/services/reports.ts
init_errors();
init_time();
init_context();
init_learning_state();
init_notify();
import { z as z6 } from "zod";

// ../../functions/src/services/users.ts
init_errors();
init_validate();
init_ids();
import { randomInt } from "node:crypto";
import { z as z5 } from "zod";

// ../../functions/src/store/types.ts
var StoreConflictError = class extends Error {
  constructor(path3) {
    super(`Document already exists: ${path3}`);
  }
};
var StoreNotFoundError = class extends Error {
  constructor(path3) {
    super(`Document not found: ${path3}`);
  }
};

// ../../functions/src/services/users.ts
init_context();
var passwordSchema = z5.string({ required_error: "\u0631\u0645\u0632 \u0639\u0628\u0648\u0631 \u0631\u0627 \u0648\u0627\u0631\u062F \u06A9\u0646\u06CC\u062F." }).min(8, "\u0631\u0645\u0632 \u0639\u0628\u0648\u0631 \u0628\u0627\u06CC\u062F \u062D\u062F\u0627\u0642\u0644 \u06F8 \u0646\u0648\u06CC\u0633\u0647 \u0628\u0627\u0634\u062F.").max(128, "\u0631\u0645\u0632 \u0639\u0628\u0648\u0631 \u062E\u06CC\u0644\u06CC \u0637\u0648\u0644\u0627\u0646\u06CC \u0627\u0633\u062A.").refine(
  (p) => /[A-Za-z\u0600-\u06FF]/.test(p) && /\d|[۰-۹]/.test(p),
  "\u0631\u0645\u0632 \u0639\u0628\u0648\u0631 \u0628\u0627\u06CC\u062F \u062D\u062F\u0627\u0642\u0644 \u06CC\u06A9 \u062D\u0631\u0641 \u0648 \u06CC\u06A9 \u0639\u062F\u062F \u062F\u0627\u0634\u062A\u0647 \u0628\u0627\u0634\u062F."
);
var identifierSchema = z5.string({ required_error: "\u0634\u0645\u0627\u0631\u0647 \u0645\u0648\u0628\u0627\u06CC\u0644 \u06CC\u0627 \u0627\u06CC\u0645\u06CC\u0644 \u0631\u0627 \u0648\u0627\u0631\u062F \u06A9\u0646\u06CC\u062F." }).trim().min(3, "\u0634\u0645\u0627\u0631\u0647 \u0645\u0648\u0628\u0627\u06CC\u0644 \u06CC\u0627 \u0627\u06CC\u0645\u06CC\u0644 \u0631\u0627 \u0648\u0627\u0631\u062F \u06A9\u0646\u06CC\u062F.").max(120);
var registerSchema = z5.object({
  name: text(2, 60, "\u0646\u0627\u0645"),
  identifier: identifierSchema,
  password: passwordSchema
});
var loginSchema = z5.object({
  identifier: identifierSchema,
  password: z5.string().min(1, "\u0631\u0645\u0632 \u0639\u0628\u0648\u0631 \u0631\u0627 \u0648\u0627\u0631\u062F \u06A9\u0646\u06CC\u062F.").max(128)
});
function parseIdentifier(raw) {
  const s = raw.trim();
  if (s.includes("@")) {
    const email = s.toLowerCase();
    if (!z5.string().email().safeParse(email).success)
      throw new ApiError("VALIDATION", "\u0627\u06CC\u0645\u06CC\u0644 \u0648\u0627\u0631\u062F\u0634\u062F\u0647 \u062F\u0631\u0633\u062A \u0646\u06CC\u0633\u062A.");
    return { kind: "email", email, authEmail: email };
  }
  const phone = normalizePhone(s);
  if (!phone) throw new ApiError("VALIDATION", "\u0634\u0645\u0627\u0631\u0647 \u0645\u0648\u0628\u0627\u06CC\u0644 \u062F\u0631\u0633\u062A \u0646\u06CC\u0633\u062A. \u0645\u062B\u0627\u0644: \u06F0\u06F9\u06F1\u06F2\u06F1\u06F2\u06F3\u06F4\u06F5\u06F6\u06F7");
  return { kind: "phone", phone, authEmail: phoneToAuthEmail(phone) };
}
function publicUser(u) {
  return {
    id: u.id,
    name: u.name,
    phone: u.phone,
    email: u.email,
    role: u.role,
    teamId: u.teamId,
    brandIds: u.brandIds,
    status: u.status,
    pointsBalance: u.pointsBalance,
    onboardedAt: u.onboardedAt,
    lastActiveAt: u.lastActiveAt,
    createdAt: u.createdAt
  };
}
async function register(d, input, role = "marketer", extra = {}) {
  const idf = parseIdentifier(input.identifier);
  const keyId = ids.uniqueKey(idf.kind, idf.kind === "phone" ? idf.phone : idf.email);
  const now = nowIso(d);
  try {
    await d.store.create(`unique_keys/${keyId}`, { kind: idf.kind, createdAt: now, uid: null });
  } catch (e) {
    if (e instanceof StoreConflictError) {
      throw new ApiError(
        "CONFLICT",
        idf.kind === "phone" ? "\u0627\u06CC\u0646 \u0634\u0645\u0627\u0631\u0647 \u0642\u0628\u0644\u0627\u064B \u062B\u0628\u062A \u0634\u062F\u0647 \u0627\u0633\u062A. \u0648\u0627\u0631\u062F \u0634\u0648\u06CC\u062F." : "\u0627\u06CC\u0646 \u0627\u06CC\u0645\u06CC\u0644 \u0642\u0628\u0644\u0627\u064B \u062B\u0628\u062A \u0634\u062F\u0647 \u0627\u0633\u062A. \u0648\u0627\u0631\u062F \u0634\u0648\u06CC\u062F."
      );
    }
    throw e;
  }
  let uid;
  try {
    uid = await d.auth.createUser({
      email: idf.authEmail,
      password: input.password,
      displayName: input.name
    });
  } catch (e) {
    await d.store.delete(`unique_keys/${keyId}`);
    const code = e.code ?? "";
    if (code.includes("email-already-exists") || e instanceof StoreConflictError)
      throw new ApiError("CONFLICT", "\u0627\u06CC\u0646 \u062D\u0633\u0627\u0628 \u0642\u0628\u0644\u0627\u064B \u062B\u0628\u062A \u0634\u062F\u0647 \u0627\u0633\u062A. \u0648\u0627\u0631\u062F \u0634\u0648\u06CC\u062F.");
    throw e;
  }
  const user = {
    name: input.name,
    phone: idf.kind === "phone" ? idf.phone : null,
    email: idf.kind === "email" ? idf.email : null,
    firebaseUid: uid,
    role,
    teamId: null,
    brandIds: [],
    status: "active",
    pointsBalance: 0,
    onboardedAt: null,
    lastActiveAt: null,
    createdAt: now,
    updatedAt: now,
    ...extra
  };
  await d.store.set(`users/${uid}`, user);
  await d.store.update(`unique_keys/${keyId}`, { uid });
  await d.auth.setClaims(uid, { role: user.role });
  await track(d, "signup_completed", uid, { method: idf.kind });
  return { ...user, id: uid };
}
async function loginGuard(d, key) {
  const g = await d.store.get(`login_guards/${key}`);
  if (g?.lockedUntil && g.lockedUntil > nowIso(d)) {
    throw new ApiError(
      "RATE_LIMIT",
      "\u0628\u0647 \u062F\u0644\u06CC\u0644 \u062A\u0644\u0627\u0634\u200C\u0647\u0627\u06CC \u0646\u0627\u0645\u0648\u0641\u0642 \u0632\u06CC\u0627\u062F\u060C \u0648\u0631\u0648\u062F \u062A\u0627 \u06F1\u06F5 \u062F\u0642\u06CC\u0642\u0647 \u0628\u0633\u062A\u0647 \u0634\u062F. \u0628\u0639\u062F\u0627\u064B \u062F\u0648\u0628\u0627\u0631\u0647 \u062A\u0644\u0627\u0634 \u06A9\u0646\u06CC\u062F."
    );
  }
  return g;
}
async function login(d, input) {
  let idf;
  try {
    idf = parseIdentifier(input.identifier);
  } catch {
    throw new ApiError("UNAUTHENTICATED", "\u0631\u0645\u0632 \u06CC\u0627 \u0646\u0627\u0645 \u06A9\u0627\u0631\u0628\u0631\u06CC \u0627\u0634\u062A\u0628\u0627\u0647 \u0627\u0633\u062A.");
  }
  const guardKey = ids.hash(idf.authEmail);
  const guard = await loginGuard(d, guardKey);
  const r = await d.auth.signIn(idf.authEmail, input.password);
  if (!r.ok) {
    if (r.reason === "disabled") {
      await track(d, "login_failed", null, { reason: "disabled" });
      throw new ApiError("FORBIDDEN", "\u062D\u0633\u0627\u0628 \u0634\u0645\u0627 \u063A\u06CC\u0631\u0641\u0639\u0627\u0644 \u0634\u062F\u0647 \u0627\u0633\u062A. \u0628\u0627 \u0645\u062F\u06CC\u0631 \u062E\u0648\u062F \u062A\u0645\u0627\u0633 \u0628\u06AF\u06CC\u0631\u06CC\u062F.");
    }
    const fails = (guard?.fails ?? 0) + 1;
    const locked = fails >= 5;
    await d.store.set(`login_guards/${guardKey}`, {
      fails: locked ? 0 : fails,
      lockedUntil: locked ? new Date(d.clock().getTime() + 15 * 6e4).toISOString() : null
    });
    await track(d, "login_failed", null, { reason: r.reason });
    if (r.reason === "locked" || locked)
      throw new ApiError(
        "RATE_LIMIT",
        "\u0628\u0647 \u062F\u0644\u06CC\u0644 \u062A\u0644\u0627\u0634\u200C\u0647\u0627\u06CC \u0646\u0627\u0645\u0648\u0641\u0642 \u0632\u06CC\u0627\u062F\u060C \u0648\u0631\u0648\u062F \u062A\u0627 \u06F1\u06F5 \u062F\u0642\u06CC\u0642\u0647 \u0628\u0633\u062A\u0647 \u0634\u062F. \u0628\u0639\u062F\u0627\u064B \u062F\u0648\u0628\u0627\u0631\u0647 \u062A\u0644\u0627\u0634 \u06A9\u0646\u06CC\u062F."
      );
    throw new ApiError("UNAUTHENTICATED", "\u0631\u0645\u0632 \u06CC\u0627 \u0646\u0627\u0645 \u06A9\u0627\u0631\u0628\u0631\u06CC \u0627\u0634\u062A\u0628\u0627\u0647 \u0627\u0633\u062A.");
  }
  if (guard) await d.store.delete(`login_guards/${guardKey}`);
  const user = await d.store.get(`users/${r.uid}`);
  if (!user) throw new ApiError("UNAUTHENTICATED", "\u0631\u0645\u0632 \u06CC\u0627 \u0646\u0627\u0645 \u06A9\u0627\u0631\u0628\u0631\u06CC \u0627\u0634\u062A\u0628\u0627\u0647 \u0627\u0633\u062A.");
  if (user.status !== "active")
    throw new ApiError("FORBIDDEN", "\u062D\u0633\u0627\u0628 \u0634\u0645\u0627 \u063A\u06CC\u0631\u0641\u0639\u0627\u0644 \u0634\u062F\u0647 \u0627\u0633\u062A. \u0628\u0627 \u0645\u062F\u06CC\u0631 \u062E\u0648\u062F \u062A\u0645\u0627\u0633 \u0628\u06AF\u06CC\u0631\u06CC\u062F.");
  await d.store.update(`users/${r.uid}`, { lastActiveAt: nowIso(d) });
  await track(d, "login_success", r.uid, {});
  return { user: publicUser(user), ...r.tokens };
}
async function refresh(d, refreshToken) {
  const r = await d.auth.refresh(refreshToken);
  if (!r) throw new ApiError("UNAUTHENTICATED");
  const user = await d.store.get(`users/${r.uid}`);
  if (!user || user.status !== "active") throw new ApiError("UNAUTHENTICATED");
  return { user: publicUser(user), ...r.tokens };
}
async function logout(d, userId) {
  await d.auth.revoke(userId);
}
async function requestPasswordReset(d, identifier) {
  let idf;
  try {
    idf = parseIdentifier(identifier);
  } catch {
    return;
  }
  const users = await d.store.query({
    collection: "users",
    where: [idf.kind === "phone" ? ["phone", "==", idf.phone] : ["email", "==", idf.email]],
    limit: 1
  });
  const user = users[0];
  if (!user || user.status !== "active") return;
  if (idf.kind === "email") {
    await d.auth.sendPasswordResetEmail(idf.email);
  } else {
    const { notifyUsers: notifyUsers2 } = await Promise.resolve().then(() => (init_notify(), notify_exports));
    const admins = await d.store.query({
      collection: "users",
      where: [
        ["role", "in", ["admin", "superadmin"]],
        ["status", "==", "active"]
      ]
    });
    await notifyUsers2(
      d,
      admins.map((a) => a.id),
      "manual",
      {
        title: "\u062F\u0631\u062E\u0648\u0627\u0633\u062A \u0628\u0627\u0632\u06CC\u0627\u0628\u06CC \u0631\u0645\u0632",
        body: `${user.name} \u062F\u0631\u062E\u0648\u0627\u0633\u062A \u0628\u0627\u0632\u06CC\u0627\u0628\u06CC \u0631\u0645\u0632 \u0639\u0628\u0648\u0631 \u062F\u0627\u0631\u062F. \u0627\u0632 \u0628\u062E\u0634 \u06A9\u0627\u0631\u0628\u0631\u0627\u0646 \u0631\u0645\u0632 \u0645\u0648\u0642\u062A \u0628\u0633\u0627\u0632\u06CC\u062F.`
      },
      {
        actionRef: `/admin/users/${user.id}`,
        throttleKey: `pwreset_${user.id}`,
        throttleMs: 36e5
      }
    );
  }
  await track(d, "password_reset_requested", null, { method: idf.kind });
}
var patchMeSchema = z5.object({ name: text(2, 60, "\u0646\u0627\u0645") });
var changePasswordSchema = z5.object({
  currentPassword: z5.string().min(1).max(128),
  newPassword: passwordSchema
});
async function updateMe(d, user, input) {
  await d.store.update(`users/${user.id}`, { name: input.name, updatedAt: nowIso(d) });
  return publicUser({ ...user, name: input.name });
}
async function changePassword(d, user, input) {
  const authEmail = user.email ?? (user.phone ? phoneToAuthEmail(user.phone) : "");
  const r = await d.auth.signIn(authEmail, input.currentPassword);
  if (!r.ok) throw new ApiError("VALIDATION", "\u0631\u0645\u0632 \u0641\u0639\u0644\u06CC \u0627\u0634\u062A\u0628\u0627\u0647 \u0627\u0633\u062A.");
  await d.auth.setPassword(user.id, input.newPassword);
  await audit(d, { id: user.id, role: user.role }, "user.password_changed", "users", user.id);
}
async function completeOnboarding(d, user) {
  if (user.onboardedAt) return { onboardedAt: user.onboardedAt };
  const at = nowIso(d);
  await d.store.update(`users/${user.id}`, { onboardedAt: at });
  await track(d, "onboarding_completed", user.id);
  return { onboardedAt: at };
}
var adminUserQuery = z5.object({
  q: z5.string().max(80).optional(),
  role: z5.enum(["marketer", "manager", "admin", "superadmin"]).optional(),
  teamId: z5.string().max(80).optional(),
  status: z5.enum(["active", "inactive"]).optional()
});
async function listUsers(d, f) {
  const where = [];
  if (f.role) where.push(["role", "==", f.role]);
  if (f.teamId) where.push(["teamId", "==", f.teamId === "none" ? null : f.teamId]);
  if (f.status) where.push(["status", "==", f.status]);
  let users = await d.store.query({ collection: "users", where });
  if (f.q) {
    const q = f.q.trim().toLowerCase();
    const phone = normalizePhone(q);
    users = users.filter(
      (u) => u.name.toLowerCase().includes(q) || (u.email ?? "").includes(q) || (u.phone ?? "").includes(phone ?? (q.replace(/\D/g, "") || "\xA7"))
    );
  }
  users.sort((a, b) => a.name.localeCompare(b.name, "fa"));
  return users.map(publicUser);
}
var adminPatchUserSchema = z5.object({
  name: text(2, 60, "\u0646\u0627\u0645").optional(),
  role: z5.enum(["marketer", "manager", "admin", "superadmin"]).optional(),
  teamId: z5.string().max(80).nullable().optional(),
  status: z5.enum(["active", "inactive"]).optional(),
  brandIds: z5.array(z5.string().max(80)).max(50).optional()
}).refine((v) => Object.keys(v).length > 0, "\u0647\u06CC\u0686 \u062A\u063A\u06CC\u06CC\u0631\u06CC \u0627\u0631\u0633\u0627\u0644 \u0646\u0634\u062F\u0647 \u0627\u0633\u062A.");
var PRIVILEGED = ["admin", "superadmin"];
async function adminUpdateUser(d, actor, userId, patch) {
  const target = await d.store.get(`users/${userId}`);
  if (!target) throw new ApiError("NOT_FOUND", "\u06A9\u0627\u0631\u0628\u0631 \u067E\u06CC\u062F\u0627 \u0646\u0634\u062F.");
  const selfEdit = actor.id === userId;
  if (selfEdit && (patch.role !== void 0 || patch.status !== void 0)) {
    throw new ApiError("FORBIDDEN", "\u0646\u0645\u06CC\u200C\u062A\u0648\u0627\u0646\u06CC\u062F \u0646\u0642\u0634 \u06CC\u0627 \u0648\u0636\u0639\u06CC\u062A \u062D\u0633\u0627\u0628 \u062E\u0648\u062F\u062A\u0627\u0646 \u0631\u0627 \u062A\u063A\u06CC\u06CC\u0631 \u062F\u0647\u06CC\u062F.");
  }
  const roleChanged = patch.role !== void 0 && patch.role !== target.role;
  if (roleChanged || patch.status !== void 0 && PRIVILEGED.includes(target.role)) {
    const touchesPrivileged = PRIVILEGED.includes(target.role) || patch.role !== void 0 && PRIVILEGED.includes(patch.role);
    if (touchesPrivileged && actor.role !== "superadmin")
      throw new ApiError("FORBIDDEN", "\u0641\u0642\u0637 \u0645\u062F\u06CC\u0631 \u0627\u0631\u0634\u062F \u0633\u06CC\u0633\u062A\u0645 \u0645\u06CC\u200C\u062A\u0648\u0627\u0646\u062F \u0646\u0642\u0634\u200C\u0647\u0627\u06CC \u0645\u062F\u06CC\u0631\u06CC\u062A\u06CC \u0631\u0627 \u062A\u063A\u06CC\u06CC\u0631 \u062F\u0647\u062F.");
  }
  const losingSuper = target.role === "superadmin" && (patch.role !== void 0 && patch.role !== "superadmin" || patch.status === "inactive");
  if (losingSuper) {
    const supers = await d.store.query({
      collection: "users",
      where: [
        ["role", "==", "superadmin"],
        ["status", "==", "active"]
      ]
    });
    if (supers.filter((s) => s.id !== userId).length === 0)
      throw new ApiError(
        "CONFLICT",
        "\u0627\u06CC\u0646 \u0622\u062E\u0631\u06CC\u0646 \u0645\u062F\u06CC\u0631 \u0627\u0631\u0634\u062F \u0633\u06CC\u0633\u062A\u0645 \u0627\u0633\u062A \u0648 \u0646\u0645\u06CC\u200C\u062A\u0648\u0627\u0646 \u0646\u0642\u0634 \u06CC\u0627 \u0648\u0636\u0639\u06CC\u062A \u0622\u0646 \u0631\u0627 \u062A\u063A\u06CC\u06CC\u0631 \u062F\u0627\u062F."
      );
  }
  if (patch.teamId) {
    const team = await d.store.get(`teams/${patch.teamId}`);
    if (!team || team.archived) throw new ApiError("VALIDATION", "\u062A\u06CC\u0645 \u0627\u0646\u062A\u062E\u0627\u0628\u200C\u0634\u062F\u0647 \u0645\u0639\u062A\u0628\u0631 \u0646\u06CC\u0633\u062A.");
  }
  if (patch.brandIds?.length) {
    const brands = await d.store.getMany(patch.brandIds.map((b) => `brands/${b}`));
    if (brands.some((b) => !b)) throw new ApiError("VALIDATION", "\u0628\u0631\u0646\u062F \u0627\u0646\u062A\u062E\u0627\u0628\u200C\u0634\u062F\u0647 \u0645\u0639\u062A\u0628\u0631 \u0646\u06CC\u0633\u062A.");
  }
  const warnings = [];
  if (patch.status === "inactive" && target.role === "manager") {
    const teams = await d.store.query({
      collection: "teams",
      where: [["managerId", "==", userId]]
    });
    if (teams.length) warnings.push("\u0627\u06CC\u0646 \u0645\u062F\u06CC\u0631 \u0645\u0633\u0626\u0648\u0644 \u062A\u06CC\u0645 \u0627\u0633\u062A\u061B \u06CC\u06A9 \u0645\u062F\u06CC\u0631 \u062C\u062F\u06CC\u062F \u0628\u0631\u0627\u06CC \u062A\u06CC\u0645 \u062A\u0639\u06CC\u06CC\u0646 \u06A9\u0646\u06CC\u062F.");
  }
  const update = { ...patch, updatedAt: nowIso(d) };
  await d.store.update(`users/${userId}`, update);
  if (roleChanged) await d.auth.setClaims(userId, { role: patch.role });
  if (roleChanged || patch.status === "inactive") await d.auth.revoke(userId);
  if (patch.status !== void 0 && patch.status !== target.status)
    await d.auth.setDisabled(userId, patch.status === "inactive");
  const before = Object.fromEntries(
    Object.keys(patch).map((k) => [k, target[k]])
  );
  await audit(
    d,
    actor,
    roleChanged ? "user.role_changed" : "user.updated",
    "users",
    userId,
    before,
    patch
  );
  await track(d, "admin_user_updated", actor.id, { fields: Object.keys(patch) });
  const updated = await d.store.get(`users/${userId}`);
  return { user: updated ? publicUser(updated) : null, warnings };
}
function tempPassword() {
  const letters = "abcdefghjkmnpqrstuvwxyz";
  let s = "";
  for (let i = 0; i < 6; i++) s += letters[randomInt(letters.length)];
  return `${s}${randomInt(1e3, 9999)}`;
}
async function adminResetPassword(d, actor, userId) {
  const target = await d.store.get(`users/${userId}`);
  if (!target) throw new ApiError("NOT_FOUND", "\u06A9\u0627\u0631\u0628\u0631 \u067E\u06CC\u062F\u0627 \u0646\u0634\u062F.");
  if (PRIVILEGED.includes(target.role) && actor.role !== "superadmin")
    throw new ApiError("FORBIDDEN");
  await audit(d, actor, "user.password_reset", "users", userId);
  await track(d, "admin_password_reset", actor.id, { method: target.email ? "email" : "temp" });
  if (target.email) {
    await d.auth.sendPasswordResetEmail(target.email);
    return { method: "email", temporaryPassword: null };
  }
  const pwd = tempPassword();
  await d.auth.setPassword(userId, pwd);
  await d.auth.revoke(userId);
  return { method: "temporary", temporaryPassword: pwd };
}
var teamSchema = z5.object({
  name: text(2, 60, "\u0646\u0627\u0645 \u062A\u06CC\u0645"),
  managerId: z5.string().max(80).nullable().optional()
});
async function listTeams(d) {
  const [teams, users] = await Promise.all([
    d.store.query({ collection: "teams" }),
    d.store.query({ collection: "users", where: [["status", "==", "active"]] })
  ]);
  return teams.filter((t) => !t.archived).map((t) => ({
    id: t.id,
    name: t.name,
    managerId: t.managerId,
    managerName: users.find((u) => u.id === t.managerId)?.name ?? null,
    memberCount: users.filter((u) => u.teamId === t.id && u.role === "marketer").length
  })).sort((a, b) => a.name.localeCompare(b.name, "fa"));
}
async function assignManager(d, teamId, managerId) {
  if (!managerId) return;
  const m = await d.store.get(`users/${managerId}`);
  if (!m || m.role !== "manager" || m.status !== "active")
    throw new ApiError("VALIDATION", "\u0645\u062F\u06CC\u0631 \u062A\u06CC\u0645 \u0628\u0627\u06CC\u062F \u06A9\u0627\u0631\u0628\u0631\u06CC \u0641\u0639\u0627\u0644 \u0628\u0627 \u0646\u0642\u0634 \xAB\u0645\u062F\u06CC\u0631 \u0641\u0631\u0648\u0634\xBB \u0628\u0627\u0634\u062F.");
  await d.store.update(`users/${managerId}`, { teamId, updatedAt: nowIso(d) });
}
async function createTeam(d, actor, input) {
  const id2 = d.store.newId();
  const now = nowIso(d);
  await assignManager(d, id2, input.managerId);
  const team = {
    name: input.name,
    managerId: input.managerId ?? null,
    archived: false,
    createdAt: now,
    updatedAt: now
  };
  await d.store.set(`teams/${id2}`, team);
  await audit(d, actor, "team.created", "teams", id2, null, team);
  return { id: id2, ...team };
}
async function updateTeam(d, actor, teamId, input) {
  const team = await d.store.get(`teams/${teamId}`);
  if (!team) throw new ApiError("NOT_FOUND", "\u062A\u06CC\u0645 \u067E\u06CC\u062F\u0627 \u0646\u0634\u062F.");
  if (input.managerId !== void 0) await assignManager(d, teamId, input.managerId);
  const patch = { ...input, updatedAt: nowIso(d) };
  await d.store.update(`teams/${teamId}`, patch);
  await audit(d, actor, "team.updated", "teams", teamId, team, patch);
  return { ...team, ...patch, id: teamId };
}

// ../../functions/src/services/reports.ts
function isLagging(p, now) {
  if (p.status === "completed" || p.packageStatus !== "published" || !p.deadlineAt) return false;
  const left = Date.parse(p.deadlineAt) - now.getTime();
  return left < 0 || left <= 72 * HOUR && p.percent < 50;
}
async function loadMembers(d, users) {
  const shared = await loadShared(d);
  const out = [];
  for (const u of users)
    out.push({ user: u, packages: (await loadUserLearning(d, u, shared)).packages });
  return out;
}
function summarize(members, now) {
  let assigned = 0;
  let completed = 0;
  let onTime = 0;
  const delays = [];
  const laggards = [];
  for (const m of members) {
    for (const p of m.packages) {
      if (p.packageStatus !== "published" && p.status !== "completed") continue;
      assigned++;
      if (p.status === "completed") {
        completed++;
        if (p.onTime) onTime++;
        else if (p.completedAt && p.deadlineAt)
          delays.push((Date.parse(p.completedAt) - Date.parse(p.deadlineAt)) / DAY);
      } else if (p.deadlineAt && p.deadlineAt < now.toISOString())
        delays.push((now.getTime() - Date.parse(p.deadlineAt)) / DAY);
      if (isLagging(p, now)) {
        const stuck = p.sections.find((s) => s.state !== "completed" && s.state !== "locked");
        laggards.push({
          userId: m.user.id,
          name: m.user.name,
          packageId: p.id,
          packageTitle: p.title,
          percent: p.percent,
          deadlineAt: p.deadlineAt,
          overdueDays: p.deadlineAt && p.deadlineAt < now.toISOString() ? Math.ceil((now.getTime() - Date.parse(p.deadlineAt)) / DAY) : 0,
          lastActivityAt: p.lastActivityAt,
          stuckAt: stuck ? stuck.title : null
        });
      }
    }
  }
  laggards.sort((a, b) => b.overdueDays - a.overdueDays || a.percent - b.percent);
  return {
    kpis: {
      members: members.length,
      completionRate: assigned ? Math.round(completed / assigned * 100) : 0,
      onTimeRate: completed ? Math.round(onTime / completed * 100) : 0,
      laggardCount: new Set(laggards.map((l) => l.userId)).size,
      avgDelayDays: delays.length ? Math.round(delays.reduce((a, b) => a + b, 0) / delays.length * 10) / 10 : 0,
      assigned,
      completed
    },
    laggards
  };
}
async function teamMembers(d, manager) {
  if (!manager.teamId) return [];
  return d.store.query({
    collection: "users",
    where: [
      ["teamId", "==", manager.teamId],
      ["role", "==", "marketer"]
    ]
  });
}
async function assertTeamMember(d, manager, userId) {
  const u = await d.store.get(`users/${userId}`);
  if (!u) throw new ApiError(manager.role === "manager" ? "FORBIDDEN" : "NOT_FOUND");
  if (manager.role === "manager" && (!manager.teamId || u.teamId !== manager.teamId))
    throw new ApiError("FORBIDDEN", "\u0627\u06CC\u0646 \u06A9\u0627\u0631\u0628\u0631 \u0639\u0636\u0648 \u062A\u06CC\u0645 \u0634\u0645\u0627 \u0646\u06CC\u0633\u062A.");
  return u;
}
async function managerDashboard(d, manager) {
  const team = manager.teamId ? await d.store.get(`teams/${manager.teamId}`) : null;
  const members = await loadMembers(
    d,
    (await teamMembers(d, manager)).filter((u) => u.status === "active")
  );
  const pendingRetakes = manager.teamId ? await d.store.query({
    collection: "retake_requests",
    where: [
      ["teamId", "==", manager.teamId],
      ["status", "==", "pending"]
    ]
  }) : [];
  await track(d, "manager_dashboard_viewed", manager.id);
  return {
    team: team ? { id: team.id, name: team.name } : null,
    ...summarize(members, d.clock()),
    pendingRetakes: pendingRetakes.length
  };
}
var reportQuery = z6.object({
  from: z6.string().max(40).optional(),
  to: z6.string().max(40).optional(),
  brand: z6.string().max(80).optional(),
  product: z6.string().max(80).optional(),
  user: z6.string().max(80).optional(),
  team: z6.string().max(80).optional(),
  status: z6.enum(["new", "in_progress", "completed", "overdue"]).optional()
});
function completionRows(members, f, now) {
  const from = f.from ? Date.parse(f.from) : null;
  const to = f.to ? Date.parse(f.to) : null;
  if (f.from && Number.isNaN(from) || f.to && Number.isNaN(to) || from && to && from > to)
    throw new ApiError("VALIDATION", "\u0628\u0627\u0632\u0647 \u062A\u0627\u0631\u06CC\u062E \u0645\u0639\u062A\u0628\u0631 \u0646\u06CC\u0633\u062A.");
  const rows = [];
  for (const m of members) {
    if (f.user && m.user.id !== f.user) continue;
    for (const p of m.packages) {
      if (f.brand && p.brand?.id !== f.brand) continue;
      if (f.product && p.product?.id !== f.product) continue;
      if (f.status === "overdue" ? !p.overdue : f.status && p.status !== f.status) continue;
      if (from && (!p.deadlineAt || Date.parse(p.deadlineAt) < from)) continue;
      if (to && (!p.deadlineAt || Date.parse(p.deadlineAt) > to + DAY - 1)) continue;
      const stuck = p.sections.find((s) => s.state !== "completed");
      rows.push({
        userId: m.user.id,
        userName: m.user.name,
        teamId: m.user.teamId,
        packageId: p.id,
        packageTitle: p.title,
        brandId: p.brand?.id ?? null,
        brandName: p.brand?.name ?? null,
        productId: p.product?.id ?? null,
        productName: p.product?.name ?? null,
        percent: p.percent,
        status: p.status,
        overdue: p.overdue,
        lagging: isLagging(p, now),
        deadlineAt: p.deadlineAt,
        completedAt: p.completedAt,
        onTime: p.onTime,
        lastActivityAt: p.lastActivityAt,
        stuckAt: stuck?.title ?? null
      });
    }
  }
  return rows.sort((a, b) => Number(b.lagging) - Number(a.lagging) || a.percent - b.percent);
}
async function managerReport(d, manager, f) {
  const members = await loadMembers(d, await teamMembers(d, manager));
  await track(d, "manager_report_viewed", manager.id, { filters: Object.keys(f) });
  return {
    rows: completionRows(members, f, d.clock()),
    members: members.map((m) => ({ id: m.user.id, name: m.user.name }))
  };
}
async function userTimeline(d, viewer, userId) {
  const u = await assertTeamMember(d, viewer, userId);
  const [{ packages }, attempts, messages] = await Promise.all([
    loadUserLearning(d, u),
    d.store.query({ collection: "attempts", where: [["userId", "==", userId]] }),
    d.store.query({
      collection: "messages",
      where: [["toUserId", "==", userId]],
      orderBy: [["createdAt", "desc"]],
      limit: 30
    })
  ]);
  if (viewer.role === "manager")
    await track(d, "manager_user_detail_viewed", viewer.id, { userId });
  return {
    user: publicUser(u),
    packages: packages.map((p) => ({
      ...p,
      sections: p.sections.map((s) => ({
        ...s,
        attempts: attempts.filter((a) => a.sectionId === s.id && a.status === "submitted").sort((a, b) => a.attemptNumber - b.attemptNumber).map((a) => ({
          attemptNumber: a.attemptNumber,
          score: a.score,
          passed: a.passed,
          submittedAt: a.submittedAt
        }))
      }))
    })),
    messages: messages.map((m) => ({
      id: m.id,
      type: m.type,
      body: m.body,
      packageId: m.packageId,
      readAt: m.readAt,
      createdAt: m.createdAt
    }))
  };
}
var messageSchema = z6.object({
  body: z6.string().trim().min(1, "\u0645\u062A\u0646 \u067E\u06CC\u0627\u0645 \u0631\u0627 \u0628\u0646\u0648\u06CC\u0633\u06CC\u062F.").max(1e3, "\u067E\u06CC\u0627\u0645 \u062D\u062F\u0627\u06A9\u062B\u0631 \u06F1\u06F0\u06F0\u06F0 \u0646\u0648\u06CC\u0633\u0647 \u0627\u0633\u062A."),
  packageId: z6.string().max(80).nullable().optional()
});
var noteSchema = z6.object({
  body: z6.string().trim().min(1, "\u0645\u062A\u0646 \u06CC\u0627\u062F\u062F\u0627\u0634\u062A \u0631\u0627 \u0628\u0646\u0648\u06CC\u0633\u06CC\u062F.").max(1e3),
  packageId: z6.string().min(1, "\u0622\u0645\u0648\u0632\u0634 \u0645\u0631\u0628\u0648\u0637 \u0631\u0627 \u0627\u0646\u062A\u062E\u0627\u0628 \u06A9\u0646\u06CC\u062F.").max(80)
});
async function sendMessage(d, manager, userId, type, input) {
  const u = await assertTeamMember(d, manager, userId);
  if (u.status !== "active")
    throw new ApiError("CONFLICT", "\u0627\u06CC\u0646 \u06A9\u0627\u0631\u0628\u0631 \u063A\u06CC\u0631\u0641\u0639\u0627\u0644 \u0627\u0633\u062A \u0648 \u067E\u06CC\u0627\u0645 \u0628\u0647 \u0627\u0648 \u0646\u0645\u06CC\u200C\u0631\u0633\u062F.");
  const id2 = d.store.newId();
  const msg = {
    fromUserId: manager.id,
    toUserId: userId,
    type,
    packageId: input.packageId ?? null,
    body: input.body,
    readAt: null,
    createdAt: d.clock().toISOString()
  };
  await d.store.set(`messages/${id2}`, msg);
  await audit(
    d,
    { id: manager.id, role: manager.role },
    type === "note" ? "manager.note_added" : "manager.message_sent",
    "messages",
    id2,
    null,
    { toUserId: userId, packageId: msg.packageId }
  );
  await track(d, type === "note" ? "manager_note_added" : "manager_message_sent", manager.id, {
    hasPackage: !!msg.packageId
  });
  await notifyTemplate(
    d,
    [userId],
    "manager_message",
    { manager: manager.name, snippet: input.body.slice(0, 80) },
    {
      actionRef: msg.packageId ? `/packages/${msg.packageId}` : "/notifications",
      priority: "high"
    }
  );
  return { id: id2, ...msg };
}
async function myMessages(d, userId) {
  const list = await d.store.query({
    collection: "messages",
    where: [["toUserId", "==", userId]],
    orderBy: [["createdAt", "desc"]],
    limit: 50
  });
  const senders = await d.store.getMany(
    [...new Set(list.map((m) => m.fromUserId))].map((id2) => `users/${id2}`)
  );
  const names = new Map(senders.filter((s) => !!s).map((s) => [s.id, s.name]));
  return list.map((m) => ({
    id: m.id,
    type: m.type,
    body: m.body,
    packageId: m.packageId,
    fromName: names.get(m.fromUserId) ?? "\u0645\u062F\u06CC\u0631",
    readAt: m.readAt,
    createdAt: m.createdAt
  }));
}
async function markMessageRead(d, userId, id2) {
  const m = await d.store.get(`messages/${id2}`);
  if (!m || m.toUserId !== userId) throw new ApiError("NOT_FOUND");
  if (!m.readAt) await d.store.update(`messages/${id2}`, { readAt: d.clock().toISOString() });
  return { ok: true };
}
async function listRetakes(d, viewer, status = "pending") {
  const where = [["status", "==", status]];
  if (viewer.role === "manager") {
    if (!viewer.teamId) return [];
    where.push(["teamId", "==", viewer.teamId]);
  }
  const list = await d.store.query({ collection: "retake_requests", where });
  const users = await d.store.getMany(
    [...new Set(list.map((r) => r.userId))].map((id2) => `users/${id2}`)
  );
  const names = new Map(users.filter((u) => !!u).map((u) => [u.id, u.name]));
  const out = [];
  for (const r of list.sort((a, b) => a.createdAt < b.createdAt ? 1 : -1)) {
    const attempts = await d.store.query({
      collection: "attempts",
      where: [
        ["userId", "==", r.userId],
        ["quizId", "==", r.quizId]
      ]
    });
    const pkg = await d.store.get(`packages/${r.packageId}`);
    out.push({
      ...r,
      userName: names.get(r.userId) ?? "\u2014",
      packageTitle: pkg?.title ?? "",
      sectionTitle: pkg?.sections.find((s) => s.id === r.sectionId)?.title ?? "",
      scores: attempts.filter((a) => a.status === "submitted").sort((a, b) => a.attemptNumber - b.attemptNumber).map((a) => a.score)
    });
  }
  return out;
}
async function reviewRetake(d, reviewer, id2, decision, note) {
  const path3 = `retake_requests/${id2}`;
  const result = await d.store.runTransaction(async (tx) => {
    const r = await tx.get(path3);
    if (!r) throw new ApiError("NOT_FOUND", "\u062F\u0631\u062E\u0648\u0627\u0633\u062A \u067E\u06CC\u062F\u0627 \u0646\u0634\u062F.");
    if (reviewer.role === "manager" && (!reviewer.teamId || r.teamId !== reviewer.teamId))
      throw new ApiError("FORBIDDEN", "\u0627\u06CC\u0646 \u062F\u0631\u062E\u0648\u0627\u0633\u062A \u0645\u0631\u0628\u0648\u0637 \u0628\u0647 \u062A\u06CC\u0645 \u0634\u0645\u0627 \u0646\u06CC\u0633\u062A.");
    if (reviewer.role === "manager" && r.escalated && r.status === "pending")
      throw new ApiError("FORBIDDEN", "\u0627\u06CC\u0646 \u062F\u0631\u062E\u0648\u0627\u0633\u062A \u0628\u0647 \u0645\u062F\u06CC\u0631 \u0633\u06CC\u0633\u062A\u0645 \u0627\u0631\u062C\u0627\u0639 \u0634\u062F\u0647 \u0627\u0633\u062A.");
    if (r.status !== "pending") {
      if (r.status === decision) return { r, changed: false };
      throw new ApiError("CONFLICT", "\u0627\u06CC\u0646 \u062F\u0631\u062E\u0648\u0627\u0633\u062A \u0642\u0628\u0644\u0627\u064B \u0628\u0631\u0631\u0633\u06CC \u0634\u062F\u0647 \u0627\u0633\u062A.");
    }
    tx.update(path3, {
      status: decision,
      reviewedBy: reviewer.id,
      reviewNote: note,
      reviewedAt: d.clock().toISOString()
    });
    return { r: { ...r, status: decision }, changed: true };
  });
  if (result.changed) {
    const actor = { id: reviewer.id, role: reviewer.role };
    await audit(
      d,
      actor,
      `retake.${decision}`,
      "retake_requests",
      id2,
      { status: "pending" },
      { status: decision, note }
    );
    await track(d, decision === "approved" ? "retake_approved" : "retake_rejected", reviewer.id, {
      quizId: result.r.quizId
    });
    const pkg = await d.store.get(`packages/${result.r.packageId}`);
    await notifyTemplate(
      d,
      [result.r.userId],
      "retake_reviewed",
      { title: pkg?.title ?? "", result: decision === "approved" ? "\u062A\u0623\u06CC\u06CC\u062F" : "\u0631\u062F" },
      { actionRef: `/sections/${result.r.sectionId}` }
    );
  }
  return { id: id2, status: decision };
}
async function adminCompletion(d, f) {
  const where = [["role", "==", "marketer"]];
  if (f.team) where.push(["teamId", "==", f.team]);
  const users = await d.store.query({ collection: "users", where });
  const members = await loadMembers(d, users);
  return { rows: completionRows(members, f, d.clock()), ...summarize(members, d.clock()) };
}
async function adminKpis(d) {
  const now = d.clock();
  const since30 = new Date(now.getTime() - 30 * DAY).toISOString();
  const since7 = new Date(now.getTime() - 7 * DAY).toISOString();
  const [users, events, completions, firstAttempts] = await Promise.all([
    d.store.query({ collection: "users", where: [["role", "==", "marketer"]] }),
    d.store.query({
      collection: "analytics_events",
      where: [["ts", ">=", since30]]
    }),
    d.store.query({
      collection: "package_completions"
    }),
    d.store.query({
      collection: "attempts",
      where: [
        ["attemptNumber", "==", 1],
        ["status", "==", "submitted"]
      ]
    })
  ]);
  const played = events.filter(
    (e) => e.name === "section_played" || e.name === "playback_heartbeat"
  );
  const mau = new Set(played.map((e) => e.userId)).size;
  const wau = new Set(played.filter((e) => e.ts >= since7).map((e) => e.userId)).size;
  const firstCompletion = /* @__PURE__ */ new Map();
  for (const c of completions)
    if (!firstCompletion.has(c.userId) || (firstCompletion.get(c.userId) ?? "") > c.completedAt)
      firstCompletion.set(c.userId, c.completedAt);
  const activated = users.filter((u) => {
    const fc = firstCompletion.get(u.id);
    return fc && Date.parse(fc) - Date.parse(u.createdAt) <= 7 * DAY;
  }).length;
  const late = completions.filter((c) => !c.onTime);
  const nudges = events.filter((e) => e.name === "mentor_nudge_created").length;
  const reengaged = events.filter((e) => e.name === "reengaged_after_nudge").length;
  return {
    marketers: users.length,
    activeMarketers: users.filter((u) => u.status === "active").length,
    activationRate: users.length ? Math.round(activated / users.length * 100) : 0,
    wau,
    mau,
    wauMau: mau ? Math.round(wau / mau * 100) : 0,
    onTimeCompletionRate: completions.length ? Math.round(completions.filter((c) => c.onTime).length / completions.length * 100) : 0,
    firstPassRate: firstAttempts.length ? Math.round(firstAttempts.filter((a) => a.passed).length / firstAttempts.length * 100) : 0,
    avgDelayHours: late.length ? Math.round(late.reduce((a, c) => a + c.delayHours, 0) / late.length) : 0,
    completions: completions.length,
    nudgeReengagementRate: nudges ? Math.round(reengaged / nudges * 100) : 0
  };
}
async function adminDashboard(d) {
  const [kpis, packages, pendingRetakes] = await Promise.all([
    adminKpis(d),
    d.store.query({ collection: "packages" }),
    d.store.query({
      collection: "retake_requests",
      where: [["status", "==", "pending"]]
    })
  ]);
  return {
    kpis,
    content: {
      published: packages.filter((p) => p.status === "published").length,
      drafts: packages.filter((p) => p.status === "draft").length,
      unassigned: packages.filter((p) => p.status !== "archived" && !p.brandId).length,
      archived: packages.filter((p) => p.status === "archived").length
    },
    pendingRetakes: pendingRetakes.length
  };
}
var auditQuery = z6.object({
  actor: z6.string().max(80).optional(),
  action: z6.string().max(80).optional(),
  from: z6.string().max(40).optional(),
  entity: z6.string().max(60).optional()
});
async function listAudit(d, f) {
  const where = [];
  if (f.actor) where.push(["actorId", "==", f.actor]);
  if (f.action) where.push(["action", "==", f.action]);
  if (f.entity) where.push(["entity", "==", f.entity]);
  if (f.from) where.push(["createdAt", ">=", new Date(f.from).toISOString()]);
  const list = await d.store.query({
    collection: "audit_logs",
    where,
    orderBy: [["createdAt", "desc"]],
    limit: 200
  });
  return list.map(({ expireAt: _e, ...rest }) => rest);
}

// ../../functions/src/services/jobs.ts
async function runDeadlineSweep(d) {
  const policy = await getPolicy(d);
  const now = d.clock();
  const shared = await loadShared(d);
  const marketers = await d.store.query({
    collection: "users",
    where: [
      ["role", "==", "marketer"],
      ["status", "==", "active"]
    ]
  });
  const stats = { warnings: 0, passed: 0, managerReports: 0 };
  const passedByTeam = /* @__PURE__ */ new Map();
  const thresholds = [...policy.warningHours].sort((a, b) => a - b);
  for (const u of marketers) {
    const { packages } = await loadUserLearning(d, u, shared);
    for (const p of packages) {
      if (p.status === "completed" || p.packageStatus !== "published" || !p.deadlineAt) continue;
      const left = Date.parse(p.deadlineAt) - now.getTime();
      if (left > 0) {
        const h2 = thresholds.find((t) => left <= t * HOUR);
        if (h2 !== void 0) {
          const n = await notifyTemplate(
            d,
            [u.id],
            "deadline_warning",
            { title: p.title, hours: Math.max(1, Math.round(left / HOUR)) },
            {
              actionRef: `/packages/${p.id}`,
              priority: "high",
              urgent: left < 24 * HOUR,
              throttleKey: `warn_${p.id}_${h2}_${p.deadlineAt}`,
              throttleMs: 3650 * DAY
            }
          );
          if (n) {
            stats.warnings++;
            await track(d, "deadline_warning_sent", u.id, { packageId: p.id, hours: h2 });
          }
        }
      } else {
        const escId = ids.escalation(u.id, p.id, "deadline_passed");
        try {
          await d.store.create(`escalation_events/${escId}`, {
            userId: u.id,
            teamId: u.teamId,
            packageId: p.id,
            type: "deadline_passed",
            createdAt: now.toISOString()
          });
        } catch {
          continue;
        }
        await notifyTemplate(
          d,
          [u.id],
          "deadline_passed",
          { title: p.title },
          { actionRef: `/packages/${p.id}`, priority: "high", urgent: true }
        );
        await track(d, "deadline_passed", u.id, { packageId: p.id });
        stats.passed++;
        if (u.teamId) {
          const list = passedByTeam.get(u.teamId) ?? [];
          list.push({ name: u.name, title: p.title });
          passedByTeam.set(u.teamId, list);
        }
      }
    }
  }
  for (const [teamId, list] of passedByTeam) {
    const managers = await d.store.query({
      collection: "users",
      where: [
        ["teamId", "==", teamId],
        ["role", "==", "manager"],
        ["status", "==", "active"]
      ]
    });
    const body = list.length === 1 ? `\u0645\u0647\u0644\u062A \xAB${list[0]?.title}\xBB \u0628\u0631\u0627\u06CC ${list[0]?.name} \u062A\u0645\u0627\u0645 \u0634\u062F \u0648 \u0622\u0645\u0648\u0632\u0634 \u06A9\u0627\u0645\u0644 \u0646\u0634\u062F\u0647 \u0627\u0633\u062A.` : `\u0645\u0647\u0644\u062A \u0622\u0645\u0648\u0632\u0634 \u0628\u0631\u0627\u06CC ${list.length} \u0645\u0648\u0631\u062F \u062F\u0631 \u062A\u06CC\u0645 \u0634\u0645\u0627 \u062A\u0645\u0627\u0645 \u0634\u062F \u0648 \u06A9\u0627\u0645\u0644 \u0646\u0634\u062F\u0647 \u0627\u0633\u062A.`;
    stats.managerReports += await notifyTemplate(
      d,
      managers.map((m) => m.id),
      "escalation",
      { body },
      { actionRef: "/manager", priority: "high" }
    );
  }
  return stats;
}
async function runDailyReminders(d) {
  const shared = await loadShared(d);
  const marketers = await d.store.query({
    collection: "users",
    where: [
      ["role", "==", "marketer"],
      ["status", "==", "active"]
    ]
  });
  let sent = 0;
  for (const u of marketers) {
    const { packages } = await loadUserLearning(d, u, shared);
    const p = packages.find((x) => x.status === "in_progress" && x.packageStatus === "published");
    if (!p) continue;
    if (u.lastActiveAt && d.clock().getTime() - Date.parse(u.lastActiveAt) < 20 * HOUR) continue;
    sent += await notifyTemplate(
      d,
      [u.id],
      "reminder",
      { title: p.title, percent: p.percent },
      { actionRef: `/packages/${p.id}`, throttleKey: "daily_reminder", throttleMs: 20 * HOUR }
    );
  }
  return { sent };
}
async function runWeeklyDigest(d, force = false) {
  const policy = await getPolicy(d);
  const p = zonedParts(d.clock(), policy.timezone);
  if (!force && (p.weekday !== policy.weeklyDigestDay || p.hour !== policy.weeklyDigestHour))
    return { sent: 0, skipped: true };
  const teams = await d.store.query({
    collection: "teams",
    where: [["archived", "==", false]]
  });
  let sent = 0;
  for (const t of teams) {
    const managers = await d.store.query({
      collection: "users",
      where: [
        ["teamId", "==", t.id],
        ["role", "==", "manager"],
        ["status", "==", "active"]
      ]
    });
    if (!managers.length) continue;
    const members = await loadMembers(
      d,
      await d.store.query({
        collection: "users",
        where: [
          ["teamId", "==", t.id],
          ["role", "==", "marketer"],
          ["status", "==", "active"]
        ]
      })
    );
    const lagging = members.filter((m) => m.packages.some((pk) => isLagging(pk, d.clock())));
    const count = lagging.length;
    const week = `${p.year}-${p.month}-${p.day}`;
    const n = await notifyTemplate(
      d,
      managers.map((m) => m.id),
      "weekly_digest",
      { count },
      {
        actionRef: "/manager",
        priority: "high",
        throttleKey: `digest_${t.id}_${week}`,
        throttleMs: 6 * DAY
      }
    );
    sent += n;
    if (n > 0 && d.mail.enabled) {
      const text2 = weeklyDigestEmail(t.name, lagging, d.config.appUrl);
      for (const mgr of managers.filter((m) => m.email)) {
        try {
          await d.mail.send({
            to: mgr.email ?? "",
            subject: `\u06AF\u0632\u0627\u0631\u0634 \u0647\u0641\u062A\u06AF\u06CC ${t.name}: ${count} \u0646\u0641\u0631 \u0639\u0642\u0628\u200C\u0627\u0646\u062F`,
            text: text2
          });
        } catch (e) {
          console.warn("[digest] email failed", e.message);
        }
      }
    }
  }
  return { sent, skipped: false };
}
function weeklyDigestEmail(teamName, lagging, appUrl) {
  const lines = [
    `\u0633\u0644\u0627\u0645\u060C`,
    ``,
    `\u062E\u0644\u0627\u0635\u0647 \u0647\u0641\u062A\u06AF\u06CC ${teamName}:`,
    lagging.length ? `${lagging.length} \u0646\u0641\u0631 \u0627\u0632 \u062A\u06CC\u0645 \u0634\u0645\u0627 \u062F\u0631 \u0622\u0645\u0648\u0632\u0634\u200C\u0647\u0627 \u0639\u0642\u0628 \u0647\u0633\u062A\u0646\u062F:` : "\u0647\u06CC\u0686\u200C\u06A9\u0633 \u062F\u0631 \u062A\u06CC\u0645 \u0634\u0645\u0627 \u0639\u0642\u0628 \u0646\u06CC\u0633\u062A. \u0639\u0627\u0644\u06CC \u0627\u0633\u062A!",
    ...lagging.map(
      (m) => `\u2022 ${m.user.name}: ${m.packages.filter((pk) => pk.percent < 100).map((pk) => `${pk.title} (${pk.percent}\u066A)`).join("\u060C ")}`
    ),
    ``,
    appUrl ? `\u0628\u0631\u0627\u06CC \u067E\u06CC\u06AF\u06CC\u0631\u06CC \u0648\u0627\u0631\u062F \u067E\u0646\u0644 \u0634\u0648\u06CC\u062F: ${appUrl}/manager` : "\u0628\u0631\u0627\u06CC \u067E\u06CC\u06AF\u06CC\u0631\u06CC \u0648\u0627\u0631\u062F \u067E\u0646\u0644 \u0645\u062F\u06CC\u0631 \u0634\u0648\u06CC\u062F."
  ];
  return lines.join("\n");
}

// ../../functions/src/services/mentor.ts
init_errors();
init_time();
init_context();
init_learning_state();
init_catalog_cache();
import { z as z7 } from "zod";
var MAX_INPUT = 500;
var INJECTION = [
  /ignore (all|the|previous|above)/i,
  /disregard (all|previous|the)/i,
  /system prompt/i,
  /you are now/i,
  /act as/i,
  /jailbreak/i,
  /دستور(ات)? (قبلی|قبل|بالا) را (نادیده|فراموش)/,
  /(نادیده|فراموش) (بگیر|کن).{0,20}(دستور|قوانین|قانون)/,
  /(پرامپت|پرومپت) (سیستم|سیستمی)/,
  /نقش (خود|ت) را عوض/,
  /از این به بعد تو/
];
var BANNED = [
  /(دوز|دوزاژ|تجویز|نسخه) (دارو|قرص)/,
  /(تشخیص|درمان) (بیماری|سرطان|عفونت)/,
  /(وکیل|شکایت|دادگاه|حقوقی)/,
  /(سرمایه ?گذاری|بورس|ارز دیجیتال|کریپتو)/,
  /(شماره|تلفن|آدرس|ایمیل|حقوق|نمره)[\s‌]+(همکار|بقیه|دیگران|فلانی)/
];
function normalizeFa(s) {
  return s.replace(/ي/g, "\u06CC").replace(/ك/g, "\u06A9").replace(/[\u064B-\u065F\u0670]/g, "").replace(/[۰-۹]/g, (x) => String("\u06F0\u06F1\u06F2\u06F3\u06F4\u06F5\u06F6\u06F7\u06F8\u06F9".indexOf(x))).replace(/\u200c/g, " ").replace(/\s+/g, " ").trim();
}
function checkInput(raw) {
  const text2 = normalizeFa(raw);
  if (!text2) return { ok: false, reason: "empty" };
  if (text2.length > MAX_INPUT) return { ok: false, reason: "too_long" };
  if (INJECTION.some((r) => r.test(text2))) return { ok: false, reason: "injection" };
  if (BANNED.some((r) => r.test(text2))) return { ok: false, reason: "banned" };
  return { ok: true, text: text2 };
}
var PII = [/\b09\d{9}\b/g, /\+98\d{10}/g, /[\w.+-]+@[\w-]+\.[\w.]+/g];
function scrubPii(s) {
  return PII.reduce((acc, r) => acc.replace(r, "[\u062D\u0630\u0641\u200C\u0634\u062F\u0647]"), s);
}
var UNKNOWN_REPLY = "\u0646\u0645\u06CC\u200C\u062F\u0627\u0646\u0645\u061B \u067E\u0627\u0633\u062E \u0627\u06CC\u0646 \u0633\u0624\u0627\u0644 \u062F\u0631 \u0645\u062D\u062A\u0648\u0627\u06CC \u0627\u06CC\u0646 \u0622\u0645\u0648\u0632\u0634 \u0646\u06CC\u0633\u062A. \u0644\u0637\u0641\u0627\u064B \u0627\u0632 \u0645\u062F\u06CC\u0631 \u062E\u0648\u062F \u0628\u067E\u0631\u0633\u06CC\u062F.";
var FALLBACK_REPLY = "\u0645\u0646\u062A\u0648\u0631 \u0627\u0644\u0627\u0646 \u062F\u0631 \u062F\u0633\u062A\u0631\u0633 \u0646\u06CC\u0633\u062A \u2014 \u0627\u06CC\u0646 \u0633\u0624\u0627\u0644 \u0631\u0627 \u0627\u0632 \u0645\u062F\u06CC\u0631 \u062E\u0648\u062F \u0628\u067E\u0631\u0633\u06CC\u062F.";
var BLOCKED_REPLY = "\u0645\u0646 \u0641\u0642\u0637 \u062F\u0631\u0628\u0627\u0631\u0647 \u0645\u062D\u062A\u0648\u0627\u06CC \u0647\u0645\u06CC\u0646 \u0622\u0645\u0648\u0632\u0634 \u0645\u06CC\u200C\u062A\u0648\u0627\u0646\u0645 \u06A9\u0645\u06A9 \u06A9\u0646\u0645. \u0633\u0624\u0627\u0644 \u062F\u06CC\u06AF\u0631\u06CC \u062F\u0631\u0628\u0627\u0631\u0647 \u0622\u0645\u0648\u0632\u0634 \u062F\u0627\u0631\u06CC\u061F";
function checkOutput(raw) {
  const text2 = scrubPii(
    raw.replace(/[*#`_>]/g, "").replace(/\s+/g, " ").trim()
  );
  if (!text2) return { ok: false, text: "", unknown: false };
  if (/نمی[\s‌]?دانم|اطلاعی ندارم|در محتوا نیست/.test(text2))
    return { ok: true, text: UNKNOWN_REPLY, unknown: true };
  const letters = text2.replace(/[^A-Za-z\u0600-\u06FF]/g, "");
  const fa = (letters.match(/[\u0600-\u06FF]/g) ?? []).length;
  if (letters.length > 0 && fa / letters.length < 0.6)
    return { ok: false, text: "", unknown: false };
  const sentences = text2.split(/(?<=[.!؟?])\s+/).filter(Boolean);
  return { ok: true, text: sentences.slice(0, 3).join(" "), unknown: false };
}
var STOP = new Set(
  "\u0648 \u062F\u0631 \u0628\u0647 \u0627\u0632 \u06A9\u0647 \u0627\u06CC\u0646 \u0622\u0646 \u0631\u0627 \u0628\u0627 \u0628\u0631\u0627\u06CC \u06CC\u06A9 \u062A\u0627 \u0627\u0633\u062A \u0647\u0633\u062A \u0628\u0648\u062F \u0634\u0648\u062F \u06A9\u0646\u062F \u0645\u06CC \u0686\u0647 \u0686\u06CC \u0686\u06CC\u0647 \u0686\u0637\u0648\u0631 \u0686\u06AF\u0648\u0646\u0647 \u0622\u06CC\u0627 \u0627\u06AF\u0631 \u06CC\u0627 \u0647\u0645 \u0646\u06CC\u0632 \u0647\u0627 \u0647\u0627\u06CC \u0627\u06CC \u0631\u0648 \u0647\u0631 \u062F\u0627\u0631\u062F \u062F\u0627\u0631\u0645 \u062F\u0627\u0631\u0647 \u06A9\u062F\u0627\u0645 \u06A9\u062F\u0648\u0645 \u0628\u0627\u06CC\u062F \u0634\u062F\u0647 \u06A9\u0631\u062F \u06A9\u0646 \u0645\u0646 \u062A\u0648 \u0645\u0627 \u0634\u0645\u0627 \u0627\u0648".split(
    " "
  )
);
function tokenize(s) {
  return normalizeFa(s.toLowerCase()).split(/[^a-z0-9\u0600-\u06FF]+/).map((t) => t.replace(/(های|ها|ی|ای|ترین|تر)$/u, (m, _g, off) => off >= 3 ? "" : m)).filter((t) => t.length >= 2 && !STOP.has(t));
}
function scoreChunk(queryTokens, chunk) {
  const tokens = tokenize(`${chunk.title} ${chunk.text}`);
  if (!tokens.length) return 0;
  let score = 0;
  for (const q of new Set(queryTokens)) {
    let best = 0;
    for (const t of tokens) {
      if (t === q) best = Math.max(best, 1);
      else if (q.length >= 3 && t.length >= 3 && (t.startsWith(q) || q.startsWith(t)))
        best = Math.max(best, 0.6);
    }
    score += best;
  }
  return score;
}
function retrieve(query, chunks, k = 3) {
  const q = tokenize(query);
  return chunks.map((c) => ({ ...c, score: scoreChunk(q, c) })).filter((c) => c.score > 0).sort((a, b) => b.score - a.score).slice(0, k);
}
var MIN_SCORE = 1;
async function buildChunks(d, packages) {
  const chunks = [];
  const products = await productsById(
    d,
    packages.map((p) => p.productId ?? "")
  );
  const brands = await d.store.getMany(
    [...new Set(packages.map((p) => p.brandId).filter((b) => !!b))].map(
      (b) => `brands/${b}`
    )
  );
  const brandName = new Map(
    brands.filter((b) => !!b).map((b) => [b.id, b.name])
  );
  for (const p of packages) {
    const product = p.productId ? products.get(p.productId) : void 0;
    const header = [
      p.brandId ? `\u0628\u0631\u0646\u062F ${brandName.get(p.brandId) ?? ""}` : "",
      product ? `\u0645\u062D\u0635\u0648\u0644 ${product.name}` : ""
    ].filter(Boolean).join("\u060C ");
    chunks.push({
      sourceType: "package",
      sourceId: p.id,
      title: p.title,
      text: `${header}. ${p.description} ${product?.description ?? ""}`.slice(0, 1500)
    });
    const sections = await d.store.query({
      collection: `packages/${p.id}/sections`,
      where: [["archived", "==", false]]
    });
    for (const s of sections) {
      const body = `${s.description} ${s.transcript}`.trim();
      const parts = body.length > 700 ? body.match(/[\s\S]{1,600}(?:\s|$)/g) ?? [body] : [body];
      for (const part of parts)
        chunks.push({
          sourceType: "section",
          sourceId: s.id,
          title: s.title,
          text: `${header}. ${part}`
        });
      const quiz = await d.store.get(`quizzes/${s.quizId}`);
      if (quiz) {
        const qs = await d.store.query({
          collection: `quizzes/${quiz.id}/questions`,
          where: [["archived", "==", false]]
        });
        const qa = qs.map((q) => `${q.stem} ${q.explanation}`).join(" ");
        if (qa.trim())
          chunks.push({
            sourceType: "section",
            sourceId: s.id,
            title: s.title,
            text: qa.slice(0, 1500)
          });
      }
    }
  }
  return chunks;
}
var SYSTEM_PROMPT = "\u062A\u0648 \u0645\u0646\u062A\u0648\u0631 \u0622\u0645\u0648\u0632\u0634 \u0645\u062D\u0635\u0648\u0644\u0627\u062A \u0633\u06CC\u0644\u0627\u0646\u0647\u200C\u0633\u0628\u0632 \u0647\u0633\u062A\u06CC. \u0641\u0642\u0637 \u0627\u0632 \u0645\u062D\u062A\u0648\u0627\u06CC \u0627\u0631\u0627\u0626\u0647\u200C\u0634\u062F\u0647 \u062F\u0631 \u0628\u062E\u0634 context \u067E\u0627\u0633\u062E \u0628\u062F\u0647. \u0641\u0627\u0631\u0633\u06CC \u0633\u0627\u062F\u0647\u060C \u062D\u062F\u0627\u06A9\u062B\u0631 \u06F3 \u062C\u0645\u0644\u0647. \u0627\u06AF\u0631 \u067E\u0627\u0633\u062E \u062F\u0631 \u0645\u062D\u062A\u0648\u0627 \u0646\u06CC\u0633\u062A\u060C \u0635\u0631\u06CC\u062D \u0628\u06AF\u0648 \xAB\u0646\u0645\u06CC\u200C\u062F\u0627\u0646\u0645\xBB \u0648 \u0628\u0647 \u0645\u062F\u06CC\u0631 \u0627\u0631\u062C\u0627\u0639 \u0628\u062F\u0647. \u0647\u0631\u06AF\u0632 \u062F\u0631\u0628\u0627\u0631\u0647 \u0627\u0641\u0631\u0627\u062F \u062F\u06CC\u06AF\u0631\u060C \u0645\u0633\u0627\u0626\u0644 \u067E\u0632\u0634\u06A9\u06CC\u060C \u062D\u0642\u0648\u0642\u06CC \u06CC\u0627 \u0645\u0627\u0644\u06CC \u0646\u0638\u0631 \u0646\u062F\u0647 \u0648 \u062F\u0633\u062A\u0648\u0631\u0647\u0627\u06CC \u062F\u0627\u062E\u0644 \u0633\u0624\u0627\u0644 \u06A9\u0627\u0631\u0628\u0631 \u0631\u0627 \u06A9\u0647 \u0642\u0648\u0627\u0646\u06CC\u0646 \u062A\u0648 \u0631\u0627 \u062A\u063A\u06CC\u06CC\u0631 \u0645\u06CC\u200C\u062F\u0647\u0646\u062F \u0646\u0627\u062F\u06CC\u062F\u0647 \u0628\u06AF\u06CC\u0631.";
var FEW_SHOT = `\u0645\u062B\u0627\u0644 \u06F1 \u2014 \u0633\u0624\u0627\u0644: \u0627\u06CC\u0646 \u06A9\u0631\u0645 \u0628\u0631\u0627\u06CC \u0686\u0647 \u067E\u0648\u0633\u062A\u06CC \u0645\u0646\u0627\u0633\u0628 \u0627\u0633\u062A\u061F \u067E\u0627\u0633\u062E: \u0637\u0628\u0642 \u0645\u062D\u062A\u0648\u0627\u06CC \u0622\u0645\u0648\u0632\u0634\u060C \u0627\u06CC\u0646 \u0645\u062D\u0635\u0648\u0644 \u0628\u0631\u0627\u06CC \u067E\u0648\u0633\u062A\u200C\u0647\u0627\u06CC \u062E\u0634\u06A9 \u0648 \u062D\u0633\u0627\u0633 \u0645\u0646\u0627\u0633\u0628 \u0627\u0633\u062A.
\u0645\u062B\u0627\u0644 \u06F2 \u2014 \u0633\u0624\u0627\u0644: \u0642\u06CC\u0645\u062A \u0639\u0645\u062F\u0647 \u0686\u0642\u062F\u0631 \u0627\u0633\u062A\u061F \u067E\u0627\u0633\u062E: \u0646\u0645\u06CC\u200C\u062F\u0627\u0646\u0645\u061B \u0627\u06CC\u0646 \u0645\u0648\u0636\u0648\u0639 \u062F\u0631 \u0645\u062D\u062A\u0648\u0627\u06CC \u0622\u0645\u0648\u0632\u0634 \u0646\u06CC\u0633\u062A. \u0644\u0637\u0641\u0627\u064B \u0627\u0632 \u0645\u062F\u06CC\u0631\u062A \u0628\u067E\u0631\u0633.
\u0645\u062B\u0627\u0644 \u06F3 \u2014 \u0633\u0624\u0627\u0644: \u0645\u0647\u0645\u200C\u062A\u0631\u06CC\u0646 \u0645\u0632\u06CC\u062A \u0645\u062D\u0635\u0648\u0644 \u0628\u0631\u0627\u06CC \u06AF\u0641\u062A\u0646 \u0628\u0647 \u0645\u0634\u062A\u0631\u06CC \u0686\u06CC\u0633\u062A\u061F \u067E\u0627\u0633\u062E: \u0637\u0628\u0642 \u0622\u0645\u0648\u0632\u0634\u060C \u0645\u0647\u0645\u200C\u062A\u0631\u06CC\u0646 \u0645\u0632\u06CC\u062A \u0645\u0627\u0646\u062F\u06AF\u0627\u0631\u06CC \u0628\u0627\u0644\u0627 \u0648 \u062C\u0630\u0628 \u0633\u0631\u06CC\u0639 \u0627\u0633\u062A\u061B \u0627\u06CC\u0646 \u0631\u0627 \u0627\u0648\u0644 \u0628\u0647 \u0645\u0634\u062A\u0631\u06CC \u0628\u06AF\u0648.`;
var chatSchema = z7.object({
  text: z7.string().min(1, "\u0633\u0624\u0627\u0644 \u062E\u0648\u062F \u0631\u0627 \u0628\u0646\u0648\u06CC\u0633\u06CC\u062F.").max(2e3),
  packageId: z7.string().max(80).nullable().optional()
});
var feedbackSchema = z7.object({
  messageId: z7.string().min(1).max(200),
  feedback: z7.enum(["up", "down"])
});
async function consumeQuota(d, userId) {
  const policy = await getPolicy(d);
  const day = dayKey(d.clock(), policy.timezone);
  return d.store.runTransaction(async (tx) => {
    const g = await tx.get(`mentor_usage/${day}`);
    const u = await tx.get(`mentor_usage/${day}_${userId}`);
    if ((u?.count ?? 0) >= policy.mentorDailyLimitPerUser) return "user";
    if ((g?.count ?? 0) >= policy.mentorDailyLimitGlobal) return "global";
    tx.set(`mentor_usage/${day}`, { count: (g?.count ?? 0) + 1, day }, { merge: true });
    tx.set(
      `mentor_usage/${day}_${userId}`,
      { count: (u?.count ?? 0) + 1, day, userId },
      { merge: true }
    );
    return "ok";
  });
}
async function chat(d, user, input) {
  const policy = await getPolicy(d);
  if (!policy.mentorChatEnabled)
    throw new ApiError("FORBIDDEN", "\u0686\u062A \u0645\u0646\u062A\u0648\u0631 \u0641\u0639\u0644\u0627\u064B \u062E\u0627\u0645\u0648\u0634 \u0627\u0633\u062A. \u0633\u0624\u0627\u0644\u062A \u0631\u0627 \u0627\u0632 \u0645\u062F\u06CC\u0631 \u0628\u067E\u0631\u0633.");
  const quota = await consumeQuota(d, user.id);
  if (quota === "user")
    throw new ApiError(
      "RATE_LIMIT",
      `\u0633\u0642\u0641 ${policy.mentorDailyLimitPerUser} \u067E\u06CC\u0627\u0645 \u0627\u0645\u0631\u0648\u0632 \u062A\u0645\u0627\u0645 \u0634\u062F. \u0641\u0631\u062F\u0627 \u062F\u0648\u0628\u0627\u0631\u0647 \u0628\u067E\u0631\u0633.`
    );
  if (quota === "global")
    throw new ApiError("RATE_LIMIT", "\u0645\u0646\u062A\u0648\u0631 \u0627\u0645\u0631\u0648\u0632 \u062E\u06CC\u0644\u06CC \u0634\u0644\u0648\u063A \u0628\u0648\u062F\u0647. \u0633\u0624\u0627\u0644\u062A \u0631\u0627 \u0627\u0632 \u0645\u062F\u06CC\u0631 \u0628\u067E\u0631\u0633.");
  const { packages } = await loadUserLearning(d, user);
  const packageId = input.packageId ?? null;
  if (packageId && !packages.some((p) => p.id === packageId))
    throw new ApiError("NOT_FOUND", "\u0627\u06CC\u0646 \u0622\u0645\u0648\u0632\u0634 \u0628\u0631\u0627\u06CC \u0634\u0645\u0627 \u0641\u0639\u0627\u0644 \u0646\u06CC\u0633\u062A.");
  const now = d.clock();
  const expireAt = new Date(now.getTime() + 180 * DAY);
  const save = async (role, text2, extra = {}) => {
    const id2 = d.store.newId();
    const msg = {
      userId: user.id,
      role,
      text: text2,
      packageId,
      sources: [],
      outcome: null,
      feedback: null,
      createdAt: new Date(d.clock().getTime() + (role === "assistant" ? 1 : 0)).toISOString(),
      expireAt,
      ...extra
    };
    await d.store.set(`chat_messages/${id2}`, msg);
    return id2;
  };
  const verdict = checkInput(input.text);
  await save("user", scrubPii(input.text.slice(0, MAX_INPUT)));
  await track(d, "mentor_message_sent", user.id, { packageId });
  if (!verdict.ok) {
    const reply = verdict.reason === "too_long" ? `\u0633\u0624\u0627\u0644 \u062E\u06CC\u0644\u06CC \u0637\u0648\u0644\u0627\u0646\u06CC \u0627\u0633\u062A. \u0644\u0637\u0641\u0627\u064B \u06A9\u0648\u062A\u0627\u0647\u200C\u062A\u0631 (\u062D\u062F\u0627\u06A9\u062B\u0631 ${MAX_INPUT} \u0646\u0648\u06CC\u0633\u0647) \u0628\u067E\u0631\u0633.` : BLOCKED_REPLY;
    const id2 = await save("assistant", reply, { outcome: "blocked" });
    return { messageId: id2, reply, sources: [], outcome: "blocked" };
  }
  const scope = packageId ? packages.filter((p) => p.id === packageId) : packages;
  const pkgDocs = (await d.store.getMany(scope.map((p) => `packages/${p.id}`))).filter(
    (p) => !!p
  );
  const chunks = await buildChunks(d, pkgDocs);
  const top = retrieve(verdict.text, chunks, 3);
  const sources = dedupeSources(top);
  if (!top.length || (top[0]?.score ?? 0) < MIN_SCORE) {
    const id2 = await save("assistant", UNKNOWN_REPLY, { outcome: "unknown" });
    return { messageId: id2, reply: UNKNOWN_REPLY, sources: [], outcome: "unknown" };
  }
  if (!d.llm) {
    const reply = fallbackReply(verdict.text, top);
    const id2 = await save("assistant", reply, { outcome: "fallback", sources });
    return { messageId: id2, reply, sources, outcome: "fallback" };
  }
  const history = await d.store.query({
    collection: "chat_messages",
    where: [["userId", "==", user.id]],
    orderBy: [["createdAt", "desc"]],
    limit: 5
  });
  const recent = history.slice(1, 5).reverse().map((m) => `${m.role === "user" ? "\u06A9\u0627\u0631\u0628\u0631" : "\u0645\u0646\u062A\u0648\u0631"}: ${m.text.slice(0, 300)}`).join("\n");
  const progressSummary = scope.slice(0, 3).map((p) => `\xAB${p.title}\xBB: ${p.percent}\u066A`).join("\u060C ");
  const prompt = `${FEW_SHOT}

<context>
${top.map((c, i) => `[${i + 1}] ${c.title}: ${c.text.slice(0, 900)}`).join("\n")}
</context>

\u067E\u06CC\u0634\u0631\u0641\u062A \u06A9\u0627\u0631\u0628\u0631: ${progressSummary || "\u2014"}
${recent ? `\u06AF\u0641\u062A\u200C\u0648\u06AF\u0648\u06CC \u0627\u062E\u06CC\u0631:
${recent}
` : ""}
\u0633\u0624\u0627\u0644: ${verdict.text}
\u067E\u0627\u0633\u062E:`;
  try {
    const raw = await d.llm.generate({ system: SYSTEM_PROMPT, prompt, maxTokens: 300 });
    const out = checkOutput(raw);
    if (!out.ok) throw new Error("output guard rejected");
    const outcome = out.unknown ? "unknown" : "answered";
    const id2 = await save("assistant", out.text, { outcome, sources: out.unknown ? [] : sources });
    await track(d, "mentor_llm_call", user.id, {
      model: d.llm.name,
      promptChars: prompt.length,
      replyChars: raw.length,
      approxTokens: Math.round((prompt.length + raw.length) / 3.5)
    });
    return { messageId: id2, reply: out.text, sources: out.unknown ? [] : sources, outcome };
  } catch (e) {
    console.warn("mentor LLM fallback", e.message);
    const reply = fallbackReply(verdict.text, top);
    const id2 = await save("assistant", reply, { outcome: "fallback", sources });
    return { messageId: id2, reply, sources, outcome: "fallback" };
  }
}
function extractiveAnswer(query, top, max = 2) {
  const q = tokenize(query);
  const seen = /* @__PURE__ */ new Set();
  const scored = [];
  let order = 0;
  for (const c of top) {
    for (const raw of c.text.split(/(?<=[.!؟?])\s+|\n+/)) {
      const text2 = raw.replace(/\s+/g, " ").trim();
      order++;
      if (text2.length < 12 || /[؟?]$/.test(text2) || seen.has(text2)) continue;
      seen.add(text2);
      const score = scoreChunk(q, { sourceType: "section", sourceId: "", title: "", text: text2 });
      if (score > 0) scored.push({ text: text2, score, order });
    }
  }
  const best = scored.sort((a, b) => b.score - a.score || a.order - b.order).slice(0, max).sort((a, b) => a.order - b.order).map((x) => /[.!]$/.test(x.text) ? x.text : `${x.text}.`);
  return best.length ? scrubPii(best.join(" ")) : null;
}
function fallbackReply(query, top) {
  const title = top[0]?.title ?? "";
  const extract = extractiveAnswer(query, top);
  if (!extract) return `${FALLBACK_REPLY} \u067E\u06CC\u0634\u0646\u0647\u0627\u062F: \u0642\u0633\u0645\u062A \xAB${title}\xBB \u0631\u0627 \u062F\u0648\u0628\u0627\u0631\u0647 \u0645\u0631\u0648\u0631 \u06A9\u0646.`;
  return `\u0637\u0628\u0642 \u0645\u062D\u062A\u0648\u0627\u06CC \u0622\u0645\u0648\u0632\u0634: ${extract} \u0628\u0631\u0627\u06CC \u062C\u0632\u0626\u06CC\u0627\u062A \u0628\u06CC\u0634\u062A\u0631 \u0642\u0633\u0645\u062A \xAB${title}\xBB \u0631\u0627 \u0645\u0631\u0648\u0631 \u06A9\u0646.`;
}
function dedupeSources(chunks) {
  const seen = /* @__PURE__ */ new Set();
  const out = [];
  for (const c of chunks) {
    const k = `${c.sourceType}:${c.sourceId}`;
    if (seen.has(k)) continue;
    seen.add(k);
    out.push({ type: c.sourceType, id: c.sourceId, title: c.title });
  }
  return out;
}
async function chatHistory(d, userId, packageId) {
  const list = await d.store.query({
    collection: "chat_messages",
    where: [["userId", "==", userId]],
    orderBy: [["createdAt", "desc"]],
    limit: 40
  });
  return list.filter((m) => !packageId || m.packageId === packageId).reverse().map((m) => ({
    id: m.id,
    role: m.role,
    text: m.text,
    sources: m.sources,
    outcome: m.outcome,
    feedback: m.feedback,
    createdAt: m.createdAt
  }));
}
async function feedback(d, user, input) {
  const m = await d.store.get(`chat_messages/${input.messageId}`);
  if (!m || m.userId !== user.id || m.role !== "assistant") throw new ApiError("NOT_FOUND");
  await d.store.update(`chat_messages/${input.messageId}`, { feedback: input.feedback });
  await track(d, "mentor_feedback", user.id, { feedback: input.feedback });
  return { ok: true };
}
async function mentorStats(d, days = 30) {
  const since = new Date(d.clock().getTime() - days * DAY).toISOString();
  const msgs = await d.store.query({
    collection: "chat_messages",
    where: [
      ["role", "==", "assistant"],
      ["createdAt", ">=", since]
    ]
  });
  const up = msgs.filter((m) => m.feedback === "up").length;
  const down = msgs.filter((m) => m.feedback === "down").length;
  const byOutcome = { answered: 0, unknown: 0, blocked: 0, fallback: 0 };
  for (const m of msgs) if (m.outcome) byOutcome[m.outcome] = (byOutcome[m.outcome] ?? 0) + 1;
  return {
    days,
    replies: msgs.length,
    up,
    down,
    satisfaction: up + down ? Math.round(up / (up + down) * 100) : null,
    byOutcome,
    users: new Set(msgs.map((m) => m.userId)).size
  };
}
async function mentorTranscript(d, actor, userId) {
  await audit(d, actor, "mentor.transcript_viewed", "chat_messages", userId);
  return chatHistory(d, userId, null);
}

// ../../functions/src/services/mentor-rules.ts
init_time();
init_context();
async function createNudge(d, userId, ruleId, message, actionRef, refKey) {
  const policy = await getPolicy(d);
  const day = dayKey(d.clock(), policy.timezone);
  const id2 = `${userId}_${ruleId}_${refKey}_${day}`.slice(0, 1400);
  try {
    const nudge = {
      userId,
      ruleId,
      message,
      actionRef,
      dayKey: day,
      acted: false,
      createdAt: d.clock().toISOString()
    };
    await d.store.create(`mentor_nudges/${id2}`, nudge);
  } catch {
    return false;
  }
  await track(d, "mentor_nudge_created", userId, { ruleId });
  return true;
}
function hoursLeft(deadline, now) {
  return Math.max(0, Math.round((Date.parse(deadline) - now.getTime()) / HOUR));
}
function evaluateScheduledRules(packages, lastActiveAt, now, inactiveDays) {
  const hits = [];
  const active = packages.filter(
    (p) => p.status !== "completed" && p.packageStatus === "published"
  );
  for (const p of active) {
    if (!p.deadlineAt) continue;
    const left = Date.parse(p.deadlineAt) - now.getTime();
    if (left > 0 && left <= 72 * HOUR && p.percent < 80) {
      const next = p.sections.find((s) => s.state !== "completed" && s.state !== "locked");
      const h2 = hoursLeft(p.deadlineAt, now);
      hits.push({
        ruleId: "R1",
        message: `\u062A\u0627 \u0645\u0647\u0644\u062A \xAB${p.title}\xBB ${h2} \u0633\u0627\u0639\u062A \u0645\u0627\u0646\u062F\u0647 \u2014 ${next ? `\u0642\u0633\u0645\u062A \xAB${next.title}\xBB \u0631\u0627 \u0627\u062F\u0627\u0645\u0647 \u0628\u062F\u0647.` : "\u0627\u062F\u0627\u0645\u0647 \u0628\u062F\u0647."}`,
        actionRef: next ? `/sections/${next.id}` : `/packages/${p.id}`,
        refKey: p.id
      });
    }
  }
  if (active.length > 0) {
    const last = lastActiveAt ? Date.parse(lastActiveAt) : 0;
    if (now.getTime() - last >= inactiveDays * DAY) {
      const first = active[0];
      hits.push({
        ruleId: "R4",
        message: first ? `\u0686\u0646\u062F \u0631\u0648\u0632\u06CC \u0627\u0633\u062A \u0633\u0631 \u0646\u0632\u062F\u0647\u200C\u0627\u06CC. \xAB${first.title}\xBB \u0645\u0646\u062A\u0638\u0631 \u062A\u0648\u0633\u062A \u2014 \u0641\u0642\u0637 \u0686\u0646\u062F \u062F\u0642\u06CC\u0642\u0647 \u0648\u0642\u062A \u0628\u06AF\u0630\u0627\u0631.` : "\u0686\u0646\u062F \u0631\u0648\u0632\u06CC \u0627\u0633\u062A \u0633\u0631 \u0646\u0632\u062F\u0647\u200C\u0627\u06CC \u2014 \u0622\u0645\u0648\u0632\u0634\u200C\u0647\u0627\u06CC\u062A \u0645\u0646\u062A\u0638\u0631\u0646\u062F.",
        actionRef: first ? `/packages/${first.id}` : "/",
        refKey: "inactive"
      });
    }
  }
  return hits;
}
async function runMentorDaily(d) {
  const { loadShared: loadShared2, loadUserLearning: loadUserLearning2 } = await Promise.resolve().then(() => (init_learning_state(), learning_state_exports));
  const policy = await getPolicy(d);
  const users = await d.store.query({
    collection: "users",
    where: [
      ["role", "==", "marketer"],
      ["status", "==", "active"]
    ]
  });
  const shared = await loadShared2(d);
  let n = 0;
  for (const u of users) {
    const { packages } = await loadUserLearning2(d, u, shared);
    for (const hit of evaluateScheduledRules(
      packages,
      u.lastActiveAt,
      d.clock(),
      policy.reminderInactiveDays
    )) {
      if (await createNudge(d, u.id, hit.ruleId, hit.message, hit.actionRef, hit.refKey)) n++;
    }
  }
  return n;
}
async function myNudges(d, userId) {
  const since = new Date(d.clock().getTime() - 7 * DAY).toISOString();
  const list = await d.store.query({
    collection: "mentor_nudges",
    where: [
      ["userId", "==", userId],
      ["createdAt", ">=", since]
    ],
    orderBy: [["createdAt", "desc"]],
    limit: 10
  });
  return list.map((n) => ({
    id: n.id,
    ruleId: n.ruleId,
    message: n.message,
    actionRef: n.actionRef,
    createdAt: n.createdAt
  }));
}

// ../../functions/src/routes/admin.ts
init_notify();

// ../../functions/src/services/policies.ts
init_policy();
init_context();
import { z as z8 } from "zod";
var hhmm = z8.string().regex(/^([01]\d|2[0-3]):[0-5]\d$/, "\u0633\u0627\u0639\u062A \u0628\u0627\u06CC\u062F \u0628\u0647 \u0634\u06A9\u0644 \u06F2\u06F2:\u06F0\u06F0 \u0628\u0627\u0634\u062F.");
var policySchema = z8.object({
  passScore: z8.number().int().min(1, "\u0646\u0645\u0631\u0647 \u0642\u0628\u0648\u0644\u06CC \u0628\u06CC\u0646 \u06F1 \u062A\u0627 \u06F1\u06F0\u06F0 \u0627\u0633\u062A.").max(100, "\u0646\u0645\u0631\u0647 \u0642\u0628\u0648\u0644\u06CC \u0628\u06CC\u0646 \u06F1 \u062A\u0627 \u06F1\u06F0\u06F0 \u0627\u0633\u062A."),
  maxAttempts: z8.number().int().min(1, "\u062A\u0639\u062F\u0627\u062F \u062A\u0644\u0627\u0634 \u0628\u06CC\u0646 \u06F1 \u062A\u0627 \u06F1\u06F0 \u0627\u0633\u062A.").max(10, "\u062A\u0639\u062F\u0627\u062F \u062A\u0644\u0627\u0634 \u0628\u06CC\u0646 \u06F1 \u062A\u0627 \u06F1\u06F0 \u0627\u0633\u062A."),
  completionThreshold: z8.number().int().min(50, "\u0622\u0633\u062A\u0627\u0646\u0647 \u062A\u06A9\u0645\u06CC\u0644 \u0628\u06CC\u0646 \u06F5\u06F0 \u062A\u0627 \u06F1\u06F0\u06F0 \u0627\u0633\u062A.").max(100, "\u0622\u0633\u062A\u0627\u0646\u0647 \u062A\u06A9\u0645\u06CC\u0644 \u0628\u06CC\u0646 \u06F5\u06F0 \u062A\u0627 \u06F1\u06F0\u06F0 \u0627\u0633\u062A."),
  pointsTable: z8.object({
    first_pass_quiz: z8.number().int().min(0).max(1e3),
    package_completion: z8.number().int().min(0).max(1e3),
    on_time_completion: z8.number().int().min(0).max(1e3)
  }),
  penaltyEnabled: z8.boolean(),
  latePenalty: z8.number().int().min(0).max(1e3),
  warningHours: z8.array(
    z8.number().int().min(1).max(24 * 14)
  ).min(1).max(4),
  quietHours: z8.object({ start: hhmm, end: hhmm }),
  weeklyDigestDay: z8.number().int().min(0).max(6),
  weeklyDigestHour: z8.number().int().min(0).max(23),
  reminderInactiveDays: z8.number().int().min(1).max(30),
  mentorChatEnabled: z8.boolean(),
  mentorDailyLimitPerUser: z8.number().int().min(1).max(200),
  mentorDailyLimitGlobal: z8.number().int().min(1).max(1e5)
});
async function readPolicy(d) {
  const { timezone: _tz, ...p } = await getPolicy(d);
  return p;
}
async function updatePolicy(d, actor, input) {
  const before = await getPolicy(d);
  const next = {
    ...DEFAULT_POLICY,
    ...input,
    warningHours: [...new Set(input.warningHours)].sort((a, b) => b - a),
    updatedAt: nowIso(d),
    updatedBy: actor.id
  };
  await d.store.set("policies/global", next);
  invalidatePolicy(d);
  const changed = Object.keys(input).filter(
    (k) => JSON.stringify(before[k]) !== JSON.stringify(input[k])
  );
  await audit(d, actor, "policy.updated", "policies", "global", before, next);
  await track(d, "admin_policy_updated", actor.id, { keys: changed });
  return next;
}

// ../../functions/src/routes/admin.ts
var id = (req, k = "id") => String(req.params[k] ?? "");
function adminRouter(d, limiter) {
  const r = Router();
  r.use("/admin", requireRole("admin", "superadmin"));
  r.get(
    "/admin/dashboard",
    h(async () => adminDashboard(d))
  );
  r.get(
    "/admin/content/tree",
    h(async () => contentTree(d))
  );
  r.get(
    "/admin/brands",
    h(async () => listBrandsAdmin(d))
  );
  r.post(
    "/admin/brands",
    h(
      async (req) => createBrand(d, actorOf(req), parse(brandSchema, req.body)),
      201
    )
  );
  r.patch(
    "/admin/brands/:id",
    h(
      async (req) => updateBrand(d, actorOf(req), id(req), parse(brandPatchSchema, req.body))
    )
  );
  r.get(
    "/admin/products",
    h(async (req) => {
      const q = parse(
        z9.object({
          brandId: z9.string().max(80).optional(),
          q: z9.string().max(80).optional(),
          archived: z9.enum(["true", "false"]).optional()
        }),
        req.query
      );
      return listProductsAdmin(d, {
        brandId: q.brandId,
        q: q.q,
        archived: q.archived === void 0 ? void 0 : q.archived === "true"
      });
    })
  );
  r.post(
    "/admin/products",
    h(
      async (req) => createProduct(d, actorOf(req), parse(productSchema, req.body)),
      201
    )
  );
  r.patch(
    "/admin/products/:id",
    h(
      async (req) => updateProduct(d, actorOf(req), id(req), parse(productPatchSchema, req.body))
    )
  );
  r.post(
    "/admin/media/upload-url",
    rateLimit(limiter, "upload", 30, 6e4, (req) => me(req).id),
    h(
      async (req) => createUploadUrl(d, actorOf(req), parse(uploadUrlSchema, req.body)),
      201
    )
  );
  r.post(
    "/admin/media/:id/finalize",
    h(
      async (req) => finalizeMedia(d, actorOf(req), id(req), parse(finalizeSchema, req.body))
    )
  );
  r.get(
    "/admin/packages",
    h(async (req) => listPackagesAdmin(d, parse(adminPackageQuery, req.query)))
  );
  r.post(
    "/admin/packages",
    h(
      async (req) => createPackage(d, actorOf(req), parse(packageSchema, req.body)),
      201
    )
  );
  r.get(
    "/admin/packages/:id",
    h(async (req) => getPackageAdmin(d, id(req)))
  );
  r.patch(
    "/admin/packages/:id",
    h(
      async (req) => updatePackage(d, actorOf(req), id(req), parse(packagePatchSchema, req.body))
    )
  );
  r.post(
    "/admin/packages/:id/publish",
    h(async (req) => publishPackage(d, actorOf(req), id(req)))
  );
  r.post(
    "/admin/packages/:id/unpublish",
    h(async (req) => unpublishPackage(d, actorOf(req), id(req)))
  );
  r.post(
    "/admin/packages/:id/archive",
    h(async (req) => archivePackage(d, actorOf(req), id(req)))
  );
  r.post(
    "/admin/packages/:id/sections",
    h(
      async (req) => createSection(d, actorOf(req), id(req), parse(sectionSchema, req.body)),
      201
    )
  );
  r.put(
    "/admin/packages/:id/sections/order",
    h(
      async (req) => reorderSections(d, actorOf(req), id(req), parse(reorderSchema, req.body).ids)
    )
  );
  r.patch(
    "/admin/packages/:id/sections/:sid",
    h(
      async (req) => updateSection(
        d,
        actorOf(req),
        id(req),
        id(req, "sid"),
        parse(sectionPatchSchema, req.body)
      )
    )
  );
  r.get(
    "/admin/quizzes/:id",
    h(async (req) => getQuizAdmin(d, id(req)))
  );
  r.patch(
    "/admin/quizzes/:id",
    h(
      async (req) => updateQuizSettings(
        d,
        actorOf(req),
        id(req),
        parse(quizSettingsSchema, req.body)
      )
    )
  );
  r.post(
    "/admin/quizzes/:id/questions",
    h(
      async (req) => addQuestion(d, actorOf(req), id(req), parse(questionSchema, req.body)),
      201
    )
  );
  r.put(
    "/admin/quizzes/:id/questions/order",
    h(
      async (req) => reorderQuestions(
        d,
        actorOf(req),
        id(req),
        parse(reorderSchema, req.body).ids
      )
    )
  );
  r.put(
    "/admin/quizzes/:id/questions/:qid",
    h(
      async (req) => updateQuestion(
        d,
        actorOf(req),
        id(req),
        id(req, "qid"),
        parse(questionSchema, req.body)
      )
    )
  );
  r.delete(
    "/admin/quizzes/:id/questions/:qid",
    h(async (req) => archiveQuestion(d, actorOf(req), id(req), id(req, "qid")), 204)
  );
  r.get(
    "/admin/paths",
    h(async () => listPaths(d))
  );
  r.post(
    "/admin/paths",
    h(
      async (req) => createPath(d, actorOf(req), parse(pathSchema, req.body)),
      201
    )
  );
  r.put(
    "/admin/paths/:id",
    h(
      async (req) => updatePath(d, actorOf(req), id(req), parse(pathSchema, req.body))
    )
  );
  r.delete(
    "/admin/paths/:id",
    h(async (req) => archivePath(d, actorOf(req), id(req)), 204)
  );
  r.post(
    "/admin/paths/:id/apply-deadlines",
    h(async (req) => applyPathDeadlines(d, actorOf(req), id(req)))
  );
  r.get(
    "/admin/assignments",
    h(async (req) => listAssignments(d, req.query.includeRevoked === "true"))
  );
  r.post(
    "/admin/assignments",
    h(
      async (req) => createAssignment(
        d,
        actorOf(req),
        parse(assignmentSchema, req.body)
      ),
      201
    )
  );
  r.delete(
    "/admin/assignments/:id",
    h(async (req) => revokeAssignment(d, actorOf(req), id(req)))
  );
  r.get(
    "/admin/users",
    h(async (req) => listUsers(d, parse(adminUserQuery, req.query)))
  );
  r.get(
    "/admin/users/:id",
    h(async (req) => userTimeline(d, me(req), id(req)))
  );
  r.patch(
    "/admin/users/:id",
    h(
      async (req) => adminUpdateUser(d, actorOf(req), id(req), parse(adminPatchUserSchema, req.body))
    )
  );
  r.post(
    "/admin/users/:id/reset-password",
    rateLimit(limiter, "reset", 10, 6e4, (req) => me(req).id),
    h(async (req) => adminResetPassword(d, actorOf(req), id(req)))
  );
  r.get(
    "/admin/teams",
    h(async () => listTeams(d))
  );
  r.post(
    "/admin/teams",
    h(async (req) => createTeam(d, actorOf(req), parse(teamSchema, req.body)), 201)
  );
  r.patch(
    "/admin/teams/:id",
    h(
      async (req) => updateTeam(
        d,
        actorOf(req),
        id(req),
        parse(teamSchema.partial().extend({ archived: z9.boolean().optional() }), req.body)
      )
    )
  );
  r.get(
    "/admin/reports/completion",
    h(async (req) => adminCompletion(d, parse(reportQuery, req.query)))
  );
  r.get(
    "/admin/reports/kpis",
    h(async () => adminKpis(d))
  );
  r.get(
    "/admin/reports/mentor",
    h(async () => mentorStats(d))
  );
  r.get(
    "/admin/retake-requests",
    h(
      async (req) => listRetakes(
        d,
        me(req),
        parse(
          z9.object({ status: z9.enum(["pending", "approved", "rejected"]).optional() }),
          req.query
        ).status
      )
    )
  );
  const retakeNote = z9.object({ note: z9.string().trim().max(500).nullable().optional() });
  for (const decision of ["approved", "rejected"])
    r.post(
      `/admin/retake-requests/:id/${decision === "approved" ? "approve" : "reject"}`,
      h(
        async (req) => reviewRetake(
          d,
          me(req),
          id(req),
          decision,
          parse(retakeNote, req.body).note ?? null
        )
      )
    );
  r.get(
    "/admin/mentor/transcripts/:userId",
    requireRole("superadmin"),
    h(async (req) => mentorTranscript(d, actorOf(req), id(req, "userId")))
  );
  r.get(
    "/admin/notification-templates",
    h(async () => getTemplates(d))
  );
  r.put(
    "/admin/notification-templates/:key",
    h(
      async (req) => updateTemplate(
        d,
        actorOf(req),
        id(req, "key"),
        parse(templateSchema, req.body)
      )
    )
  );
  r.post(
    "/admin/notifications/send",
    rateLimit(
      limiter,
      "manual-send",
      5,
      60 * 6e4,
      (req) => me(req).id,
      "\u0627\u0631\u0633\u0627\u0644 \u062F\u0633\u062A\u06CC \u0627\u0639\u0644\u0627\u0646 \u062D\u062F\u0627\u06A9\u062B\u0631 \u06F5 \u0628\u0627\u0631 \u062F\u0631 \u0633\u0627\u0639\u062A \u0645\u0645\u06A9\u0646 \u0627\u0633\u062A."
    ),
    h(async (req) => manualSend(d, actorOf(req), parse(manualSendSchema, req.body)))
  );
  r.get(
    "/admin/policies",
    h(async () => readPolicy(d))
  );
  r.put(
    "/admin/policies",
    h(
      async (req) => updatePolicy(d, actorOf(req), parse(policySchema, req.body))
    )
  );
  r.get(
    "/admin/audit-logs",
    h(async (req) => listAudit(d, parse(auditQuery, req.query)))
  );
  r.post(
    "/admin/jobs/:name",
    requireRole("superadmin"),
    h(async (req) => {
      switch (id(req, "name")) {
        case "deadline-sweep":
          return runDeadlineSweep(d);
        case "daily-reminders":
          return runDailyReminders(d);
        case "weekly-digest":
          return runWeeklyDigest(d, true);
        case "mentor-daily":
          return { nudges: await runMentorDaily(d) };
        case "flush-push":
          return { sent: await flushDeferredPush(d) };
        default:
          return { error: "unknown job" };
      }
    })
  );
  return r;
}

// ../../functions/src/routes/auth.ts
init_notify();
import { Router as Router2 } from "express";
import { z as z10 } from "zod";
init_validate();
var ip = (req) => req.ip ?? "unknown";
function authRouter(d, limiter) {
  const r = Router2();
  const perIp = (name, n) => rateLimit(limiter, name, n, 6e4, ip);
  r.post(
    "/auth/register",
    perIp("register", 5),
    h(async (req) => {
      const input = parse(registerSchema, req.body);
      const user = await register(d, input);
      await notifyTemplate(d, [user.id], "welcome", { name: user.name }, { actionRef: "/" });
      const session = await login(d, {
        identifier: input.identifier,
        password: input.password
      });
      return {
        user: publicUser(user),
        idToken: session.idToken,
        refreshToken: session.refreshToken,
        expiresIn: session.expiresIn
      };
    }, 201)
  );
  r.post(
    "/auth/login",
    perIp("login", 10),
    h(async (req) => login(d, parse(loginSchema, req.body)))
  );
  r.post(
    "/auth/refresh",
    perIp("refresh", 30),
    h(
      async (req) => refresh(
        d,
        parse(z10.object({ refreshToken: z10.string().min(10).max(4096) }), req.body).refreshToken
      )
    )
  );
  r.post(
    "/auth/logout",
    authenticate(d),
    h(async (req) => logout(d, me(req).id), 204)
  );
  r.post(
    "/auth/password-reset",
    perIp("pwreset", 5),
    h(async (req) => {
      await requestPasswordReset(
        d,
        parse(z10.object({ identifier: z10.string().min(3).max(120) }), req.body).identifier
      );
      return { accepted: true };
    }, 202)
  );
  return r;
}

// ../../functions/src/routes/files.ts
init_errors();
import fs2 from "node:fs";
import path2 from "node:path";
import { pipeline } from "node:stream/promises";
import { Router as Router3 } from "express";
function localFilesRouter(blob) {
  const r = Router3();
  r.put("/uploads/:token", async (req, res, next) => {
    try {
      const t = blob.verifyTicket(String(req.params.token), "put");
      if (!t) throw new ApiError("FORBIDDEN", "\u0644\u06CC\u0646\u06A9 \u0622\u067E\u0644\u0648\u062F \u0645\u0646\u0642\u0636\u06CC \u06CC\u0627 \u0646\u0627\u0645\u0639\u062A\u0628\u0631 \u0627\u0633\u062A.");
      const len = Number(req.headers["content-length"] ?? 0);
      if (len > t.max) throw new ApiError("VALIDATION", "\u062D\u062C\u0645 \u0641\u0627\u06CC\u0644 \u0628\u06CC\u0634 \u0627\u0632 \u062D\u062F \u0645\u062C\u0627\u0632 \u0627\u0633\u062A.");
      const full = blob.resolve(t.p);
      fs2.mkdirSync(full.substring(0, full.lastIndexOf("/")), { recursive: true });
      let received = 0;
      req.on("data", (chunk) => {
        received += chunk.length;
        if (received > t.max) req.destroy(new Error("too large"));
      });
      await pipeline(req, fs2.createWriteStream(full));
      fs2.writeFileSync(`${full}.meta.json`, JSON.stringify({ contentType: t.ct }));
      res.status(200).json({ data: { ok: true, size: received } });
    } catch (e) {
      next(
        e instanceof ApiError ? e : new ApiError("VALIDATION", "\u0622\u067E\u0644\u0648\u062F \u0646\u0627\u0645\u0648\u0641\u0642 \u0628\u0648\u062F. \u062F\u0648\u0628\u0627\u0631\u0647 \u062A\u0644\u0627\u0634 \u06A9\u0646\u06CC\u062F.")
      );
    }
  });
  const send = (res, p) => {
    const full = blob.resolve(p);
    if (!fs2.existsSync(full)) throw new ApiError("NOT_FOUND");
    const meta = fs2.existsSync(`${full}.meta.json`) ? JSON.parse(fs2.readFileSync(`${full}.meta.json`, "utf8")) : {};
    res.setHeader("X-Content-Type-Options", "nosniff");
    res.setHeader("Cross-Origin-Resource-Policy", "cross-origin");
    res.sendFile(path2.relative(blob.root, full), {
      root: blob.root,
      headers: {
        "Content-Type": meta.contentType ?? "application/octet-stream",
        "Cache-Control": "private, max-age=3600"
      },
      dotfiles: "deny"
    });
  };
  r.get("/files/signed/:token", (req, res, next) => {
    try {
      const t = blob.verifyTicket(String(req.params.token), "get");
      if (!t) throw new ApiError("FORBIDDEN", "\u0644\u06CC\u0646\u06A9 \u0641\u0627\u06CC\u0644 \u0645\u0646\u0642\u0636\u06CC \u0634\u062F\u0647 \u0627\u0633\u062A. \u0635\u0641\u062D\u0647 \u0631\u0627 \u062F\u0648\u0628\u0627\u0631\u0647 \u0628\u0627\u0632 \u06A9\u0646\u06CC\u062F.");
      send(res, t.p);
    } catch (e) {
      next(e);
    }
  });
  r.get(/^\/files\/public\/((?:brands|products|branding)\/.+)$/, (req, res, next) => {
    try {
      const p = decodeURIComponent(req.params[0] ?? "");
      if (p.includes("..") || p.endsWith(".meta.json")) throw new ApiError("NOT_FOUND");
      send(res, p);
    } catch (e) {
      next(e);
    }
  });
  return r;
}

// ../../functions/src/routes/health.ts
import { Router as Router4 } from "express";
function healthRouter(config2) {
  const router = Router4();
  router.get("/health", (_req, res) => {
    res.json({
      data: {
        status: "ok",
        service: "seylane-sabz-learning-api",
        version: config2.version,
        env: config2.env,
        time: (/* @__PURE__ */ new Date()).toISOString()
      }
    });
  });
  return router;
}

// ../../functions/src/routes/manager.ts
import { Router as Router5 } from "express";
import { z as z11 } from "zod";
init_validate();
function managerRouter(d, limiter) {
  const r = Router5();
  r.use("/manager", requireRole("manager"));
  const uid = (req) => me(req).id;
  r.get(
    "/manager/dashboard",
    h(async (req) => managerDashboard(d, me(req)))
  );
  r.get(
    "/manager/reports/completion",
    h(async (req) => managerReport(d, me(req), parse(reportQuery, req.query)))
  );
  r.get(
    "/manager/users/:id/progress",
    h(async (req) => userTimeline(d, me(req), String(req.params.id)))
  );
  const spam = rateLimit(
    limiter,
    "mgr-msg",
    20,
    60 * 6e4,
    uid,
    "\u062A\u0639\u062F\u0627\u062F \u067E\u06CC\u0627\u0645\u200C\u0647\u0627\u06CC \u0634\u0645\u0627 \u062F\u0631 \u0627\u06CC\u0646 \u0633\u0627\u0639\u062A \u0632\u06CC\u0627\u062F \u0628\u0648\u062F\u0647 \u0627\u0633\u062A. \u06A9\u0645\u06CC \u0628\u0639\u062F \u062F\u0648\u0628\u0627\u0631\u0647 \u062A\u0644\u0627\u0634 \u06A9\u0646\u06CC\u062F."
  );
  r.post(
    "/manager/users/:id/messages",
    spam,
    h(
      async (req) => sendMessage(
        d,
        me(req),
        String(req.params.id),
        "message",
        parse(messageSchema, req.body)
      ),
      201
    )
  );
  r.post(
    "/manager/users/:id/notes",
    spam,
    h(
      async (req) => sendMessage(
        d,
        me(req),
        String(req.params.id),
        "note",
        parse(noteSchema, req.body)
      ),
      201
    )
  );
  r.get(
    "/manager/retake-requests",
    h(
      async (req) => listRetakes(
        d,
        me(req),
        parse(
          z11.object({ status: z11.enum(["pending", "approved", "rejected"]).optional() }),
          req.query
        ).status
      )
    )
  );
  const note = z11.object({ note: z11.string().trim().max(500).nullable().optional() });
  r.post(
    "/manager/retake-requests/:id/approve",
    h(
      async (req) => reviewRetake(
        d,
        me(req),
        String(req.params.id),
        "approved",
        parse(note, req.body).note ?? null
      )
    )
  );
  r.post(
    "/manager/retake-requests/:id/reject",
    h(
      async (req) => reviewRetake(
        d,
        me(req),
        String(req.params.id),
        "rejected",
        parse(note, req.body).note ?? null
      )
    )
  );
  return r;
}

// ../../functions/src/routes/me.ts
import { Router as Router6 } from "express";
import { z as z13 } from "zod";
init_validate();
init_context();

// ../../functions/src/services/learning.ts
init_errors();
init_ids();
init_time();
init_context();
init_learning_state();
import { z as z12 } from "zod";
init_notify();

// ../../functions/src/services/rewards.ts
init_ids();
init_context();
var DEFAULT_BADGES = [
  {
    id: "first_package",
    code: "first_package",
    title: "\u0627\u0648\u0644\u06CC\u0646 \u0642\u062F\u0645",
    description: "\u0627\u0648\u0644\u06CC\u0646 \u0628\u0633\u062A\u0647 \u0622\u0645\u0648\u0632\u0634\u06CC \u0631\u0627 \u06A9\u0627\u0645\u0644 \u06A9\u0631\u062F\u06CC.",
    icon: "sprout",
    rule: { type: "first_package", threshold: 1 },
    active: true
  },
  {
    id: "on_time_3",
    code: "on_time_3",
    title: "\u0647\u0645\u06CC\u0634\u0647 \u0628\u0647\u200C\u0645\u0648\u0642\u0639",
    description: "\u0633\u0647 \u0628\u0633\u062A\u0647 \u067E\u0634\u062A\u200C\u0633\u0631\u0647\u0645 \u0631\u0627 \u0642\u0628\u0644 \u0627\u0632 \u0645\u0647\u0644\u062A \u062A\u0645\u0627\u0645 \u06A9\u0631\u062F\u06CC.",
    icon: "alarm-clock-check",
    rule: { type: "on_time_streak", threshold: 3 },
    active: true
  },
  {
    id: "sharp_5",
    code: "sharp_5",
    title: "\u062A\u06CC\u0632\u0647\u0648\u0634",
    description: "\u062F\u0631 \u067E\u0646\u062C \u0622\u0632\u0645\u0648\u0646 \u0627\u0632 \u0647\u0645\u0627\u0646 \u062A\u0644\u0627\u0634 \u0627\u0648\u0644 \u0642\u0628\u0648\u0644 \u0634\u062F\u06CC.",
    icon: "brain",
    rule: { type: "first_try_passes", threshold: 5 },
    active: true
  },
  {
    id: "packages_5",
    code: "packages_5",
    title: "\u067E\u0631\u062A\u0644\u0627\u0634",
    description: "\u067E\u0646\u062C \u0628\u0633\u062A\u0647 \u0622\u0645\u0648\u0632\u0634\u06CC \u0631\u0627 \u06A9\u0627\u0645\u0644 \u06A9\u0631\u062F\u06CC.",
    icon: "medal",
    rule: { type: "packages_completed", threshold: 5 },
    active: true
  },
  {
    id: "points_500",
    code: "points_500",
    title: "\u0633\u062A\u0627\u0631\u0647 \u0641\u0631\u0648\u0634",
    description: "\u0628\u0647 \u06F5\u06F0\u06F0 \u0627\u0645\u062A\u06CC\u0627\u0632 \u0631\u0633\u06CC\u062F\u06CC.",
    icon: "star",
    rule: { type: "points", threshold: 500 },
    active: true
  }
];
async function awardPoints(d, userId, reason, refId, amount) {
  if (!amount) return false;
  const ledgerPath = `points_ledger/${ids.points(userId, reason, refId)}`;
  const awarded = await d.store.runTransaction(async (tx) => {
    const existing = await tx.get(ledgerPath);
    if (existing) return false;
    const user = await tx.get(`users/${userId}`);
    if (!user) return false;
    const entry = {
      userId,
      amount,
      reason,
      refId,
      createdAt: d.clock().toISOString()
    };
    tx.create(ledgerPath, entry);
    tx.update(`users/${userId}`, { pointsBalance: (user.pointsBalance ?? 0) + amount });
    return true;
  });
  if (awarded) await track(d, "points_earned", userId, { amount, reason });
  return awarded;
}
function onTimeStreak(completions) {
  const sorted = [...completions].sort((a, b) => a.completedAt < b.completedAt ? -1 : 1);
  let streak = 0;
  for (let i = sorted.length - 1; i >= 0; i--) {
    if (sorted[i]?.onTime) streak++;
    else break;
  }
  return streak;
}
function earnedBadgeIds(badges, stats) {
  return badges.filter((b) => b.active).filter((b) => {
    const t = b.rule.threshold;
    switch (b.rule.type) {
      case "first_package":
      case "packages_completed":
        return stats.packagesCompleted >= t;
      case "on_time_streak":
        return stats.onTimeStreak >= t;
      case "first_try_passes":
        return stats.firstTryPasses >= t;
      case "points":
        return stats.points >= t;
    }
  }).map((b) => b.id);
}
async function listBadges(d) {
  const b = await d.store.query({ collection: "badges" });
  return b.length ? b : DEFAULT_BADGES;
}
async function evaluateBadges(d, userId) {
  const [badges, completions, firstPass, user, owned] = await Promise.all([
    listBadges(d),
    d.store.query({
      collection: "package_completions",
      where: [["userId", "==", userId]]
    }),
    d.store.query({
      collection: "points_ledger",
      where: [
        ["userId", "==", userId],
        ["reason", "==", "first_pass_quiz"]
      ]
    }),
    d.store.get(`users/${userId}`),
    d.store.query({ collection: "user_badges", where: [["userId", "==", userId]] })
  ]);
  const stats = {
    packagesCompleted: completions.length,
    onTimeStreak: onTimeStreak(completions),
    firstTryPasses: firstPass.length,
    points: user?.pointsBalance ?? 0
  };
  const have = new Set(owned.map((o) => o.badgeId));
  const fresh = [];
  for (const id2 of earnedBadgeIds(badges, stats)) {
    if (have.has(id2)) continue;
    try {
      await d.store.create(`user_badges/${ids.userBadge(userId, id2)}`, {
        userId,
        badgeId: id2,
        earnedAt: d.clock().toISOString()
      });
      const b = badges.find((x) => x.id === id2);
      if (b) fresh.push(b);
      await track(d, "badge_earned", userId, { badgeId: id2 });
    } catch {
    }
  }
  if (fresh.length) {
    const { notifyTemplate: notifyTemplate2 } = await Promise.resolve().then(() => (init_notify(), notify_exports));
    for (const b of fresh)
      await notifyTemplate2(
        d,
        [userId],
        "badge_earned",
        { title: b.title },
        { actionRef: "/cards", priority: "low" }
      );
  }
  return fresh;
}
async function myPoints(d, userId) {
  const [user, ledger] = await Promise.all([
    d.store.get(`users/${userId}`),
    d.store.query({
      collection: "points_ledger",
      where: [["userId", "==", userId]],
      orderBy: [["createdAt", "desc"]],
      limit: 100
    })
  ]);
  return {
    balance: user?.pointsBalance ?? 0,
    ledger: ledger.map((l) => ({
      id: l.id,
      amount: l.amount,
      reason: l.reason,
      refId: l.refId,
      createdAt: l.createdAt
    }))
  };
}
async function myBadges(d, userId) {
  const [badges, owned] = await Promise.all([
    listBadges(d),
    d.store.query({ collection: "user_badges", where: [["userId", "==", userId]] })
  ]);
  const map = new Map(owned.map((o) => [o.badgeId, o.earnedAt]));
  return badges.filter((b) => b.active).map((b) => ({
    id: b.id,
    code: b.code,
    title: b.title,
    description: b.description,
    icon: b.icon,
    earned: map.has(b.id),
    earnedAt: map.get(b.id) ?? null
  }));
}

// ../../functions/src/services/learning.ts
var LOCKED = "\u0627\u06CC\u0646 \u0642\u0633\u0645\u062A \u0647\u0646\u0648\u0632 \u0642\u0641\u0644 \u0627\u0633\u062A. \u0627\u0628\u062A\u062F\u0627 \u0642\u0633\u0645\u062A \u0642\u0628\u0644 \u0631\u0627 \u06A9\u0627\u0645\u0644 \u06A9\u0646\u06CC\u062F \u0648 \u062F\u0631 \u0622\u0632\u0645\u0648\u0646 \u0622\u0646 \u0642\u0628\u0648\u0644 \u0634\u0648\u06CC\u062F.";
async function home(d, user) {
  const { packages } = await loadUserLearning(d, user);
  const active = packages.filter((p) => p.packageStatus === "published" || p.status !== "new");
  const totalProgress = active.length ? Math.round(active.reduce((a, p) => a + p.percent, 0) / active.length) : 0;
  await track(d, "home_viewed", user.id);
  return {
    nextItem: computeNextItem(packages),
    totalProgress,
    counts: {
      inProgress: packages.filter((p) => p.status === "in_progress").length,
      new: packages.filter((p) => p.status === "new").length,
      completed: packages.filter((p) => p.status === "completed").length,
      overdue: packages.filter((p) => p.overdue).length
    },
    pointsBalance: user.pointsBalance,
    packages: packages.map(stripSections)
  };
}
function stripSections(p) {
  const { sections, ...rest } = p;
  return {
    ...rest,
    sectionCount: sections.filter((s) => !s.archived).length,
    completedSections: sections.filter((s) => !s.archived && s.state === "completed").length
  };
}
async function listMyPackages(d, user, status) {
  const { packages } = await loadUserLearning(d, user);
  await track(d, "catalog_viewed", user.id, { status: status ?? "all" });
  return packages.filter((p) => !status || p.status === status).map(stripSections);
}
async function packageForUser(d, user, packageId) {
  const { packages } = await loadUserLearning(d, user);
  const p = packages.find((x) => x.id === packageId);
  if (!p) throw new ApiError("NOT_FOUND", "\u0627\u06CC\u0646 \u0622\u0645\u0648\u0632\u0634 \u0628\u0631\u0627\u06CC \u0634\u0645\u0627 \u0641\u0639\u0627\u0644 \u0646\u06CC\u0633\u062A.");
  return p;
}
async function myPackage(d, user, packageId) {
  const p = await packageForUser(d, user, packageId);
  const notes = await d.store.query({
    collection: "messages",
    where: [
      ["toUserId", "==", user.id],
      ["packageId", "==", packageId]
    ],
    orderBy: [["createdAt", "desc"]],
    limit: 20
  });
  const senders = await d.store.getMany(
    [...new Set(notes.map((n) => n.fromUserId))].map((id2) => `users/${id2}`)
  );
  const nameOf = new Map(senders.filter((s) => !!s).map((s) => [s.id, s.name]));
  await track(d, "package_opened", user.id, { packageId, status: p.status });
  return {
    package: stripSections(p),
    sections: p.sections,
    notes: notes.map((n) => ({
      id: n.id,
      type: n.type,
      body: n.body,
      fromName: nameOf.get(n.fromUserId) ?? "\u0645\u062F\u06CC\u0631",
      readAt: n.readAt,
      createdAt: n.createdAt
    }))
  };
}
async function sectionIndex(d, sectionId) {
  const idx = await d.store.get(`section_index/${sectionId}`);
  if (!idx) throw new ApiError("NOT_FOUND", "\u0627\u06CC\u0646 \u0642\u0633\u0645\u062A \u067E\u06CC\u062F\u0627 \u0646\u0634\u062F.");
  const [section, pkg] = await Promise.all([
    d.store.get(`packages/${idx.packageId}/sections/${sectionId}`),
    d.store.get(`packages/${idx.packageId}`)
  ]);
  if (!section || !pkg) throw new ApiError("NOT_FOUND", "\u0627\u06CC\u0646 \u0642\u0633\u0645\u062A \u067E\u06CC\u062F\u0627 \u0646\u0634\u062F.");
  return { section, pkg };
}
async function sectionForUser(d, user, sectionId) {
  const { section, pkg } = await sectionIndex(d, sectionId);
  const view = await packageForUser(d, user, pkg.id);
  const sv = view.sections.find((s) => s.id === sectionId);
  if (!sv) throw new ApiError("NOT_FOUND", "\u0627\u06CC\u0646 \u0642\u0633\u0645\u062A \u067E\u06CC\u062F\u0627 \u0646\u0634\u062F.");
  return { section, pkg, view, sv };
}
async function mySection(d, user, sectionId) {
  const { section, view, sv } = await sectionForUser(d, user, sectionId);
  const active = view.sections.filter((s) => !s.archived);
  const idx = active.findIndex((s) => s.id === sectionId);
  const policy = await getPolicy(d);
  return {
    section: {
      ...sv,
      description: section.description,
      mediaSource: section.mediaSource,
      youtubeId: section.mediaSource === "youtube" ? section.youtubeId : null
    },
    package: {
      id: view.id,
      title: view.title,
      deadlineAt: view.deadlineAt,
      brand: view.brand,
      product: view.product
    },
    position: { index: idx + 1, total: active.length },
    nextSectionId: active[idx + 1]?.id ?? null,
    completionThreshold: policy.completionThreshold
  };
}
async function sectionMedia(d, user, sectionId) {
  const { section, sv } = await sectionForUser(d, user, sectionId);
  if (sv.state === "locked") throw new ApiError("FORBIDDEN", LOCKED);
  if (section.mediaSource === "youtube")
    return {
      source: "youtube",
      youtubeId: section.youtubeId,
      url: null,
      mime: null,
      expiresAt: null
    };
  if (!section.mediaPath) throw new ApiError("NOT_FOUND", "\u0641\u0627\u06CC\u0644 \u0627\u06CC\u0646 \u0642\u0633\u0645\u062A \u0647\u0646\u0648\u0632 \u0622\u0645\u0627\u062F\u0647 \u0646\u06CC\u0633\u062A.");
  const ttl = 4 * 3600;
  const url = await d.blob.signedReadUrl(section.mediaPath, ttl);
  return {
    source: "file",
    youtubeId: null,
    url,
    mime: section.mediaMime,
    expiresAt: new Date(d.clock().getTime() + ttl * 1e3).toISOString()
  };
}
var heartbeatSchema = z12.object({
  positionSec: z12.number({ invalid_type_error: "\u0645\u0648\u0642\u0639\u06CC\u062A \u067E\u062E\u0634 \u0645\u0639\u062A\u0628\u0631 \u0646\u06CC\u0633\u062A." }).min(0).max(24 * 3600),
  playedDeltaSec: z12.number().min(0, "\u0645\u0642\u062F\u0627\u0631 \u067E\u062E\u0634 \u0645\u0639\u062A\u0628\u0631 \u0646\u06CC\u0633\u062A.").max(70, "\u0645\u0642\u062F\u0627\u0631 \u067E\u062E\u0634 \u0628\u06CC\u0634 \u0627\u0632 \u062D\u062F \u0645\u062C\u0627\u0632 \u0627\u0633\u062A."),
  ts: z12.string().max(40).optional(),
  deviceId: z12.string().max(80).optional(),
  event: z12.enum(["heartbeat", "pause", "ended", "hidden", "start"]).optional()
});
var MAX_DELTA = 70;
var OVERPLAY_FACTOR = 1.2;
var MAX_PLAYBACK_RATE = 1.5;
var BUDGET_CAP_SEC = 1800;
function spendBudget(prev, nowMs, requestedSec) {
  const elapsed = prev ? Math.max(0, (nowMs - prev.updatedAtMs) / 1e3) : 0;
  const bank = prev ? Math.min(BUDGET_CAP_SEC, prev.bankSec + elapsed * MAX_PLAYBACK_RATE) : MAX_DELTA;
  const acceptedSec = Math.max(0, Math.min(requestedSec, bank));
  return {
    acceptedSec: Math.round(acceptedSec * 10) / 10,
    next: { bankSec: Math.round((bank - acceptedSec) * 10) / 10, updatedAtMs: nowMs }
  };
}
function applyHeartbeat(prev, input, durationSec, threshold) {
  if (input.positionSec > durationSec + 2)
    throw new ApiError("VALIDATION", "\u0645\u0648\u0642\u0639\u06CC\u062A \u067E\u062E\u0634 \u0627\u0632 \u0637\u0648\u0644 \u0642\u0633\u0645\u062A \u0628\u06CC\u0634\u062A\u0631 \u0627\u0633\u062A.");
  const delta = Math.min(MAX_DELTA, Math.max(0, input.playedDeltaSec));
  const cap = durationSec * OVERPLAY_FACTOR;
  const playedSeconds = Math.min(cap, (prev?.playedSeconds ?? 0) + delta);
  const percent = durationSec > 0 ? Math.min(100, Math.floor(playedSeconds / durationSec * 100)) : 0;
  const completed = !!prev?.completed || percent >= threshold;
  return {
    playedSeconds: Math.round(playedSeconds * 10) / 10,
    percent,
    completed,
    justCompleted: completed && !prev?.completed,
    lastPositionSec: Math.min(durationSec, Math.max(0, input.positionSec))
  };
}
async function getProgress(d, user, sectionId) {
  const { sv } = await sectionForUser(d, user, sectionId);
  return {
    percent: sv.percent,
    lastPositionSec: sv.lastPositionSec,
    completed: sv.mediaCompleted,
    quizPassed: sv.quizPassed,
    state: sv.state
  };
}
async function recordProgress(d, user, sectionId, input, idempotencyKey, opts = {}) {
  const { section, pkg, sv } = await sectionForUser(d, user, sectionId);
  if (sv.state === "locked") throw new ApiError("FORBIDDEN", LOCKED);
  const policy = await getPolicy(d);
  const now = d.clock().toISOString();
  const path3 = `section_progress/${ids.progress(user.id, sectionId)}`;
  const key = idempotencyKey?.slice(0, 80);
  const result = await d.store.runTransaction(async (tx) => {
    const prev = await tx.get(path3);
    if (key && prev?.recentKeys?.includes(key)) return { duplicate: true, prev, next: null };
    let playedDeltaSec = input.playedDeltaSec;
    if (!opts.skipBudget) {
      const budgetPath = `playback_budgets/${user.id}`;
      const spent = spendBudget(
        await tx.get(budgetPath),
        d.clock().getTime(),
        Math.min(MAX_DELTA, playedDeltaSec)
      );
      playedDeltaSec = spent.acceptedSec;
      tx.set(budgetPath, spent.next);
    }
    const next = applyHeartbeat(
      prev,
      { ...input, playedDeltaSec },
      section.durationSec,
      policy.completionThreshold
    );
    const recentKeys = key ? [...prev?.recentKeys ?? [], key].slice(-30) : prev?.recentKeys ?? [];
    const doc = {
      userId: user.id,
      sectionId,
      packageId: pkg.id,
      playedSeconds: next.playedSeconds,
      percent: next.percent,
      completed: next.completed,
      completedAt: prev?.completedAt ?? (next.justCompleted ? now : null),
      lastPositionSec: next.lastPositionSec,
      quizPassed: prev?.quizPassed ?? false,
      quizPassedAt: prev?.quizPassedAt ?? null,
      recentKeys,
      startedAt: prev?.startedAt ?? now,
      updatedAt: now
    };
    tx.set(path3, doc);
    return { duplicate: false, prev, next: doc, justCompleted: next.justCompleted };
  });
  if (result.duplicate || !result.next) {
    const p = result.prev;
    return {
      percent: p?.percent ?? 0,
      completed: !!p?.completed,
      lastPositionSec: p?.lastPositionSec ?? 0,
      playedSeconds: p?.playedSeconds ?? 0,
      duplicate: true
    };
  }
  const nowD = d.clock();
  await d.store.set(`playback_events/${d.store.newId()}`, {
    userId: user.id,
    sectionId,
    positionSec: input.positionSec,
    playedDeltaSec: input.playedDeltaSec,
    acceptedDeltaSec: Math.round((result.next.playedSeconds - (result.prev?.playedSeconds ?? 0)) * 10) / 10,
    clientTs: input.ts ?? null,
    ts: now,
    deviceId: input.deviceId ?? null,
    expireAt: new Date(nowD.getTime() + 90 * DAY)
  });
  await d.store.update(`users/${user.id}`, { lastActiveAt: now });
  if (!result.prev) {
    await track(d, "section_played", user.id, { sectionId, mediaType: section.mediaType });
    const minutes = Math.max(1, Math.round(section.durationSec / 60));
    await createNudge(
      d,
      user.id,
      "R5",
      `\u0627\u06CC\u0646 \u0642\u0633\u0645\u062A \u062D\u062F\u0648\u062F ${minutes} \u062F\u0642\u06CC\u0642\u0647 \u0627\u0633\u062A \u2014 \u0645\u06CC\u200C\u062A\u0648\u0627\u0646\u06CC \u062F\u0631 \u0645\u0633\u06CC\u0631 \u06AF\u0648\u0634 \u0628\u062F\u0647\u06CC.`,
      `/sections/${sectionId}`,
      sectionId
    );
    await maybeReengaged(d, user.id);
  }
  await track(d, "playback_heartbeat", user.id, { sectionId, deltaSec: input.playedDeltaSec });
  if ("justCompleted" in result && result.justCompleted) {
    await track(d, "section_completed", user.id, {
      sectionId,
      elapsedSec: result.next.playedSeconds
    });
  }
  return {
    percent: result.next.percent,
    completed: result.next.completed,
    lastPositionSec: result.next.lastPositionSec,
    playedSeconds: result.next.playedSeconds,
    duplicate: false
  };
}
async function maybeReengaged(d, userId) {
  const since = new Date(d.clock().getTime() - 48 * HOUR).toISOString();
  const recent = await d.store.query({
    collection: "notifications",
    where: [
      ["userId", "==", userId],
      ["createdAt", ">=", since]
    ],
    limit: 20
  });
  const nudge = recent.find(
    (n) => ["reminder", "deadline_warning", "deadline_passed", "mentor_nudge"].includes(n.type)
  );
  if (nudge) await track(d, "reengaged_after_nudge", userId, { nudgeType: nudge.type });
}
async function quizContext(d, user, quizId) {
  const quiz = await d.store.get(`quizzes/${quizId}`);
  if (!quiz) throw new ApiError("NOT_FOUND", "\u0622\u0632\u0645\u0648\u0646 \u067E\u06CC\u062F\u0627 \u0646\u0634\u062F.");
  const ctx = await sectionForUser(d, user, quiz.sectionId);
  return { quiz, ...ctx };
}
async function attemptAllowance(d, userId, quiz) {
  const policy = await getPolicy(d);
  const [attempts, approved, pending] = await Promise.all([
    d.store.query({
      collection: "attempts",
      where: [
        ["userId", "==", userId],
        ["quizId", "==", quiz.id]
      ]
    }),
    d.store.query({
      collection: "retake_requests",
      where: [
        ["userId", "==", userId],
        ["quizId", "==", quiz.id],
        ["status", "==", "approved"]
      ]
    }),
    d.store.query({
      collection: "retake_requests",
      where: [
        ["userId", "==", userId],
        ["quizId", "==", quiz.id],
        ["status", "==", "pending"]
      ]
    })
  ]);
  const base = quiz.maxAttempts ?? policy.maxAttempts;
  const granted = approved.reduce((a, r) => a + (r.grantedAttempts || 1), 0);
  attempts.sort((a, b) => a.attemptNumber - b.attemptNumber);
  return {
    attempts,
    max: base + granted,
    passScore: quiz.passScore ?? policy.passScore,
    pending: pending[0] ?? null,
    approvedCount: approved.length
  };
}
async function activeQuestions(d, quizId) {
  const qs = await d.store.query({
    collection: `quizzes/${quizId}/questions`,
    where: [["archived", "==", false]]
  });
  return qs.sort((a, b) => a.order - b.order);
}
async function getQuizForUser(d, user, quizId) {
  const { quiz, sv, view, section } = await quizContext(d, user, quizId);
  if (sv.state === "locked") throw new ApiError("FORBIDDEN", LOCKED);
  const allowance = await attemptAllowance(d, user.id, quiz);
  const submitted = allowance.attempts.filter((a) => a.status === "submitted");
  const inProgress = allowance.attempts.find((a) => a.status === "in_progress") ?? null;
  const passed = submitted.some((a) => a.passed);
  const questions = await activeQuestions(d, quizId);
  let shown = questions;
  if (inProgress) {
    const snapIds = inProgress.snapshot.map((s) => s.questionId);
    const all = await d.store.getMany(
      snapIds.map((id2) => `quizzes/${quizId}/questions/${id2}`)
    );
    shown = all.filter((q) => !!q);
  }
  const last = submitted[submitted.length - 1] ?? null;
  return {
    quiz: {
      id: quiz.id,
      sectionId: quiz.sectionId,
      sectionTitle: section.title,
      packageId: view.id,
      packageTitle: view.title,
      passScore: allowance.passScore,
      questionCount: shown.length
    },
    // answerKey/explanation are never sent before submission (spec §24).
    questions: shown.map((q) => ({ id: q.id, order: q.order, stem: q.stem, options: q.options })),
    attemptInfo: {
      used: submitted.length,
      max: allowance.max,
      remaining: Math.max(0, allowance.max - submitted.length - (inProgress ? 1 : 0)),
      passed,
      mediaCompleted: sv.mediaCompleted,
      canAttempt: sv.mediaCompleted && !passed && (inProgress !== null || submitted.length < allowance.max) && questions.length > 0,
      inProgressAttemptId: inProgress?.id ?? null,
      inProgressAnswers: inProgress?.answers ?? {},
      pendingRetake: allowance.pending ? { id: allowance.pending.id, createdAt: allowance.pending.createdAt } : null,
      lastAttempt: last ? {
        attemptNumber: last.attemptNumber,
        score: last.score,
        passed: last.passed,
        submittedAt: last.submittedAt
      } : null
    }
  };
}
async function startAttempt(d, user, quizId) {
  const { quiz, sv, view } = await quizContext(d, user, quizId);
  if (sv.state === "locked") throw new ApiError("FORBIDDEN", LOCKED);
  if (!sv.mediaCompleted)
    throw new ApiError("CONFLICT", "\u0627\u0648\u0644 \u0642\u0633\u0645\u062A \u0631\u0627 \u06A9\u0627\u0645\u0644 \u0628\u0628\u06CC\u0646\u06CC\u062F \u06CC\u0627 \u06AF\u0648\u0634 \u06A9\u0646\u06CC\u062F\u060C \u0628\u0639\u062F \u0622\u0632\u0645\u0648\u0646 \u0641\u0639\u0627\u0644 \u0645\u06CC\u200C\u0634\u0648\u062F.");
  const questions = await activeQuestions(d, quizId);
  if (questions.length === 0)
    throw new ApiError("CONFLICT", "\u0622\u0632\u0645\u0648\u0646\u06CC \u0628\u0631\u0627\u06CC \u0627\u06CC\u0646 \u0642\u0633\u0645\u062A \u062A\u0639\u0631\u06CC\u0641 \u0646\u0634\u062F\u0647 \u0627\u0633\u062A. \u0628\u0647 \u0645\u062F\u06CC\u0631 \u0627\u0637\u0644\u0627\u0639 \u062F\u0627\u062F\u0647 \u0634\u062F.");
  const policy = await getPolicy(d);
  const res = await d.store.runTransaction(async (tx) => {
    const attempts = await tx.query({
      collection: "attempts",
      where: [
        ["userId", "==", user.id],
        ["quizId", "==", quizId]
      ]
    });
    const approved = await tx.query({
      collection: "retake_requests",
      where: [
        ["userId", "==", user.id],
        ["quizId", "==", quizId],
        ["status", "==", "approved"]
      ]
    });
    const inProgress = attempts.find((a) => a.status === "in_progress");
    if (inProgress)
      return { attemptId: inProgress.id, attemptNumber: inProgress.attemptNumber, resumed: true };
    if (attempts.some((a) => a.passed))
      throw new ApiError("CONFLICT", "\u0634\u0645\u0627 \u0642\u0628\u0644\u0627\u064B \u062F\u0631 \u0627\u06CC\u0646 \u0622\u0632\u0645\u0648\u0646 \u0642\u0628\u0648\u0644 \u0634\u062F\u0647\u200C\u0627\u06CC\u062F.");
    const max = (quiz.maxAttempts ?? policy.maxAttempts) + approved.reduce((a, r) => a + (r.grantedAttempts || 1), 0);
    if (attempts.length >= max)
      throw new ApiError(
        "CONFLICT",
        "\u062A\u0644\u0627\u0634\u200C\u0647\u0627\u06CC \u0634\u0645\u0627 \u062A\u0645\u0627\u0645 \u0634\u062F\u0647 \u0627\u0633\u062A. \u0645\u06CC\u200C\u062A\u0648\u0627\u0646\u06CC\u062F \u062F\u0631\u062E\u0648\u0627\u0633\u062A \u062A\u0644\u0627\u0634 \u0645\u062C\u062F\u062F \u0628\u062F\u0647\u06CC\u062F.",
        { reason: "attempts_exhausted" }
      );
    const n = attempts.length + 1;
    const snapshot = questions.map((q) => ({
      questionId: q.id,
      answerKey: q.answerKey,
      optionKeys: q.options.map((o) => o.key),
      version: q.version
    }));
    const attempt = {
      quizId,
      userId: user.id,
      sectionId: quiz.sectionId,
      packageId: view.id,
      attemptNumber: n,
      status: "in_progress",
      answers: {},
      score: null,
      passed: null,
      passScore: quiz.passScore ?? policy.passScore,
      // policy snapshot (edge case 27.2)
      quizVersion: quiz.version,
      snapshot,
      startedAt: d.clock().toISOString(),
      submittedAt: null
    };
    const id2 = ids.attempt(user.id, quizId, n);
    tx.create(`attempts/${id2}`, attempt);
    return { attemptId: id2, attemptNumber: n, resumed: false };
  });
  if (!res.resumed)
    await track(d, "quiz_started", user.id, { quizId, attemptNumber: res.attemptNumber });
  return res;
}
var submitSchema = z12.object({
  answers: z12.record(z12.string().max(80), z12.string().max(8)).refine((a) => Object.keys(a).length <= 50, "\u062A\u0639\u062F\u0627\u062F \u067E\u0627\u0633\u062E\u200C\u0647\u0627 \u0645\u0639\u062A\u0628\u0631 \u0646\u06CC\u0633\u062A.")
});
function grade(snapshot, answers, passScore) {
  const perQuestion = snapshot.map((s) => ({
    questionId: s.questionId,
    correct: answers[s.questionId] === s.answerKey
  }));
  const correct = perQuestion.filter((p) => p.correct).length;
  const score = snapshot.length ? Math.round(correct / snapshot.length * 100) : 0;
  return { score, passed: score >= passScore, correct, total: snapshot.length, perQuestion };
}
async function submitAttempt(d, user, attemptId, input) {
  const path3 = `attempts/${attemptId}`;
  const now = d.clock().toISOString();
  const outcome = await d.store.runTransaction(async (tx) => {
    const a2 = await tx.get(path3);
    if (!a2 || a2.userId !== user.id) throw new ApiError("NOT_FOUND", "\u0627\u06CC\u0646 \u062A\u0644\u0627\u0634 \u067E\u06CC\u062F\u0627 \u0646\u0634\u062F.");
    if (a2.status === "submitted")
      return { a: a2, fresh: false, g: grade(a2.snapshot, a2.answers, a2.passScore) };
    const missing = a2.snapshot.filter((s) => !input.answers[s.questionId]);
    if (missing.length)
      throw new ApiError(
        "VALIDATION",
        `\u0628\u0647 \u0647\u0645\u0647 \u0633\u0624\u0627\u0644\u200C\u0647\u0627 \u067E\u0627\u0633\u062E \u062F\u0647\u06CC\u062F (${missing.length} \u0633\u0624\u0627\u0644 \u0628\u06CC\u200C\u067E\u0627\u0633\u062E).`,
        { missing: missing.map((m) => m.questionId) }
      );
    for (const s of a2.snapshot) {
      const ans = input.answers[s.questionId];
      if (ans && !s.optionKeys.includes(ans))
        throw new ApiError("VALIDATION", "\u06CC\u06A9\u06CC \u0627\u0632 \u067E\u0627\u0633\u062E\u200C\u0647\u0627 \u0645\u0639\u062A\u0628\u0631 \u0646\u06CC\u0633\u062A.");
    }
    const answers = Object.fromEntries(
      a2.snapshot.map((s) => [s.questionId, input.answers[s.questionId] ?? ""])
    );
    const g2 = grade(a2.snapshot, answers, a2.passScore);
    tx.update(path3, {
      status: "submitted",
      answers,
      score: g2.score,
      passed: g2.passed,
      submittedAt: now
    });
    if (g2.passed) {
      const pPath = `section_progress/${ids.progress(user.id, a2.sectionId)}`;
      tx.set(pPath, { quizPassed: true, quizPassedAt: now, updatedAt: now }, { merge: true });
    }
    return {
      a: {
        ...a2,
        answers,
        status: "submitted",
        score: g2.score,
        passed: g2.passed,
        submittedAt: now
      },
      fresh: true,
      g: g2
    };
  });
  const { a, g } = outcome;
  const quiz = await d.store.get(`quizzes/${a.quizId}`);
  const allowance = quiz ? await attemptAllowance(d, user.id, quiz) : null;
  const submittedCount = allowance?.attempts.filter((x) => x.status === "submitted").length ?? a.attemptNumber;
  const remaining = allowance ? Math.max(0, allowance.max - submittedCount) : 0;
  let nextAction = "retry";
  let packageCompleted = false;
  let pointsEarned = 0;
  const { section, pkg } = await sectionIndex(d, a.sectionId);
  if (g.passed) {
    const view = await packageForUser(d, user, pkg.id);
    packageCompleted = view.status === "completed";
    nextAction = packageCompleted ? "package_complete" : "next_section";
    if (outcome.fresh) {
      await notifyTemplate(
        d,
        [user.id],
        "quiz_passed",
        { title: section.title, score: Math.round(g.score) },
        { actionRef: `/packages/${pkg.id}` }
      );
      await track(d, "quiz_passed", user.id, {
        quizId: a.quizId,
        score: g.score,
        attemptNumber: a.attemptNumber
      });
      const policy = await getPolicy(d);
      if (a.attemptNumber === 1 && await awardPoints(
        d,
        user.id,
        "first_pass_quiz",
        a.quizId,
        policy.pointsTable.first_pass_quiz
      ))
        pointsEarned += policy.pointsTable.first_pass_quiz;
      if (packageCompleted) pointsEarned += await onPackageCompleted(d, user, pkg);
      else {
        const remainingSections = view.sections.filter(
          (s) => !s.archived && s.state !== "completed"
        ).length;
        if (remainingSections === 1)
          await createNudge(
            d,
            user.id,
            "R6",
            `\u0641\u0642\u0637 \u06CC\u06A9 \u0642\u0633\u0645\u062A \u062A\u0627 \u067E\u0627\u06CC\u0627\u0646 \xAB${pkg.title}\xBB \u0645\u0627\u0646\u062F\u0647 \u2014 \u062A\u0627 \u0627\u0645\u062A\u06CC\u0627\u0632 \u0648 \u0646\u0634\u0627\u0646 \u0631\u0627\u0647\u06CC \u0646\u06CC\u0633\u062A!`,
            `/packages/${pkg.id}`,
            pkg.id
          );
      }
    }
  } else {
    nextAction = remaining > 0 ? "retry" : allowance?.pending ? "retake_pending" : "request_retake";
    if (outcome.fresh) {
      await track(d, "quiz_failed", user.id, {
        quizId: a.quizId,
        score: g.score,
        attemptNumber: a.attemptNumber
      });
      await createNudge(
        d,
        user.id,
        "R2",
        `\u0627\u0634\u06A9\u0627\u0644\u06CC \u0646\u062F\u0627\u0631\u062F \u2014 \u0642\u0633\u0645\u062A \xAB${section.title}\xBB \u0631\u0627 \u0645\u0631\u0648\u0631 \u06A9\u0646 \u0648 \u062F\u0648\u0628\u0627\u0631\u0647 \u062A\u0644\u0627\u0634 \u06A9\u0646.`,
        `/sections/${a.sectionId}`,
        a.quizId
      );
      await notifyTemplate(
        d,
        [user.id],
        "quiz_failed",
        { title: section.title },
        { actionRef: `/sections/${a.sectionId}` }
      );
    }
  }
  if (outcome.fresh)
    await track(d, "quiz_submitted", user.id, { quizId: a.quizId, attemptNumber: a.attemptNumber });
  const questions = await d.store.getMany(
    a.snapshot.map((s) => `quizzes/${a.quizId}/questions/${s.questionId}`)
  );
  return {
    attemptId,
    attemptNumber: a.attemptNumber,
    score: g.score,
    passed: g.passed,
    passScore: a.passScore,
    correctCount: g.correct,
    total: g.total,
    remainingAttempts: remaining,
    nextAction,
    packageCompleted,
    pointsEarned,
    review: g.perQuestion.map((p, i) => ({
      questionId: p.questionId,
      correct: p.correct,
      explanation: g.passed ? questions[i]?.explanation ?? "" : ""
    }))
  };
}
async function onPackageCompleted(d, user, pkg) {
  const now = d.clock();
  const onTime = !pkg.deadlineAt || now.toISOString() <= pkg.deadlineAt;
  const delayHours = pkg.deadlineAt && !onTime ? Math.round((now.getTime() - Date.parse(pkg.deadlineAt)) / HOUR) : 0;
  const completion = {
    userId: user.id,
    packageId: pkg.id,
    teamId: user.teamId,
    completedAt: now.toISOString(),
    onTime,
    delayHours
  };
  try {
    await d.store.create(
      `package_completions/${user.id}_${pkg.id}`,
      completion
    );
  } catch {
    return 0;
  }
  const policy = await getPolicy(d);
  let pts = 0;
  if (await awardPoints(
    d,
    user.id,
    "package_completion",
    pkg.id,
    policy.pointsTable.package_completion
  ))
    pts += policy.pointsTable.package_completion;
  if (onTime && await awardPoints(
    d,
    user.id,
    "on_time_completion",
    pkg.id,
    policy.pointsTable.on_time_completion
  ))
    pts += policy.pointsTable.on_time_completion;
  if (!onTime && policy.penaltyEnabled && policy.latePenalty > 0)
    await awardPoints(d, user.id, "policy_penalty", pkg.id, -Math.abs(policy.latePenalty));
  await track(d, "package_completed", user.id, { packageId: pkg.id, onTime });
  if (!onTime)
    await track(d, "completed_after_deadline", user.id, { packageId: pkg.id, delayHours });
  if (onTime)
    await createNudge(
      d,
      user.id,
      "R3",
      `\u0622\u0641\u0631\u06CC\u0646! \xAB${pkg.title}\xBB \u0631\u0627 \u0628\u0647\u200C\u0645\u0648\u0642\u0639 \u062A\u0645\u0627\u0645 \u06A9\u0631\u062F\u06CC \u0648 \u0627\u0645\u062A\u06CC\u0627\u0632 \u06AF\u0631\u0641\u062A\u06CC.`,
      "/cards",
      pkg.id
    );
  await evaluateBadges(d, user.id);
  return pts;
}
async function requestRetake(d, user, quizId) {
  const { quiz, view } = await quizContext(d, user, quizId);
  const allowance = await attemptAllowance(d, user.id, quiz);
  const submitted = allowance.attempts.filter((a) => a.status === "submitted");
  if (submitted.some((a) => a.passed))
    throw new ApiError("CONFLICT", "\u0634\u0645\u0627 \u062F\u0631 \u0627\u06CC\u0646 \u0622\u0632\u0645\u0648\u0646 \u0642\u0628\u0648\u0644 \u0634\u062F\u0647\u200C\u0627\u06CC\u062F.");
  if (submitted.length < allowance.max)
    throw new ApiError("CONFLICT", "\u0647\u0646\u0648\u0632 \u062A\u0644\u0627\u0634 \u0628\u0627\u0642\u06CC\u200C\u0645\u0627\u0646\u062F\u0647 \u062F\u0627\u0631\u06CC\u062F.");
  if (allowance.pending)
    return { id: allowance.pending.id, status: "pending", existing: true };
  const last = submitted[submitted.length - 1];
  const id2 = d.store.newId();
  const escalated = allowance.approvedCount >= 2;
  const req = {
    userId: user.id,
    teamId: user.teamId,
    quizId,
    sectionId: quiz.sectionId,
    packageId: view.id,
    lastAttemptId: last?.id ?? "",
    status: "pending",
    grantedAttempts: 1,
    reviewedBy: null,
    reviewNote: null,
    escalated,
    createdAt: d.clock().toISOString(),
    reviewedAt: null
  };
  await d.store.set(`retake_requests/${id2}`, req);
  await track(d, "retake_requested", user.id, { quizId });
  const section = view.sections.find((s) => s.id === quiz.sectionId);
  const title = section?.title ?? view.title;
  const managers = user.teamId ? await d.store.query({
    collection: "users",
    where: [
      ["teamId", "==", user.teamId],
      ["role", "==", "manager"],
      ["status", "==", "active"]
    ]
  }) : [];
  let reviewers = managers.map((m) => m.id);
  if (escalated || reviewers.length === 0) {
    const admins = await d.store.query({
      collection: "users",
      where: [
        ["role", "in", ["admin", "superadmin"]],
        ["status", "==", "active"]
      ]
    });
    reviewers = [...reviewers, ...admins.map((a) => a.id)];
    if (escalated) {
      await d.store.set(
        `escalation_events/${ids.escalation(user.id, view.id, `retake_${quizId}`)}`,
        {
          userId: user.id,
          teamId: user.teamId,
          packageId: view.id,
          type: "retake_exhausted",
          createdAt: req.createdAt
        }
      );
    }
  }
  await notifyTemplate(
    d,
    reviewers,
    "retake_request",
    { name: user.name, title },
    { actionRef: "/manager/retakes", priority: "high" }
  );
  return { id: id2, status: "pending", existing: false };
}

// ../../functions/src/routes/me.ts
init_notify();
var CLIENT_EVENTS = [
  "app_opened",
  "signup_started",
  "next_item_cta_clicked",
  "notification_cta_clicked",
  "mentor_chat_opened",
  "playback_error",
  "manager_digest_opened",
  "report_filtered",
  "youtube_blocked_reported",
  "client_error"
];
function meRouter(d, limiter) {
  const r = Router6();
  const uid = (req) => me(req).id;
  r.get(
    "/me",
    h(async (req) => publicUser(me(req)))
  );
  r.patch(
    "/me",
    h(async (req) => updateMe(d, me(req), parse(patchMeSchema, req.body)))
  );
  r.post(
    "/me/password",
    rateLimit(limiter, "pwchange", 5, 6e4, uid),
    h(
      async (req) => changePassword(d, me(req), parse(changePasswordSchema, req.body)),
      204
    )
  );
  r.post(
    "/me/onboarding",
    h(async (req) => completeOnboarding(d, me(req)))
  );
  r.post(
    "/me/events",
    h(async (req) => {
      const e = parse(
        z13.object({
          name: z13.enum(CLIENT_EVENTS),
          props: z13.record(z13.union([z13.string().max(100), z13.number(), z13.boolean()])).optional()
        }),
        req.body
      );
      await track(d, e.name, me(req).id, e.props ?? {});
    }, 204)
  );
  r.get(
    "/me/home",
    h(async (req) => home(d, me(req)))
  );
  r.get(
    "/me/packages",
    h(
      async (req) => listMyPackages(
        d,
        me(req),
        parse(
          z13.object({ status: z13.enum(["new", "in_progress", "completed"]).optional() }),
          req.query
        ).status
      )
    )
  );
  r.get(
    "/me/packages/:id",
    h(async (req) => myPackage(d, me(req), String(req.params.id)))
  );
  r.get(
    "/me/sections/:id",
    h(async (req) => mySection(d, me(req), String(req.params.id)))
  );
  r.get(
    "/me/sections/:id/media",
    h(async (req) => sectionMedia(d, me(req), String(req.params.id)))
  );
  r.get(
    "/me/sections/:id/progress",
    h(async (req) => getProgress(d, me(req), String(req.params.id)))
  );
  r.post(
    "/me/sections/:id/progress",
    rateLimit(limiter, "heartbeat", 20, 6e4, uid),
    h(
      async (req) => recordProgress(
        d,
        me(req),
        String(req.params.id),
        parse(heartbeatSchema, req.body),
        req.get("Idempotency-Key") ?? void 0,
        { skipBudget: !d.config.playbackBudget }
      )
    )
  );
  r.get(
    "/me/quizzes/:id",
    h(async (req) => getQuizForUser(d, me(req), String(req.params.id)))
  );
  r.post(
    "/me/quizzes/:id/attempts",
    rateLimit(limiter, "attempt", 10, 6e4, uid),
    h(async (req) => startAttempt(d, me(req), String(req.params.id)), 201)
  );
  r.post(
    "/me/attempts/:id/submit",
    rateLimit(limiter, "submit", 10, 6e4, uid),
    h(
      async (req) => submitAttempt(
        d,
        me(req),
        String(req.params.id),
        parse(submitSchema, req.body)
      )
    )
  );
  r.post(
    "/me/quizzes/:id/retake-requests",
    h(async (req) => requestRetake(d, me(req), String(req.params.id)), 201)
  );
  r.get(
    "/me/points",
    h(async (req) => myPoints(d, me(req).id))
  );
  r.get(
    "/me/badges",
    h(async (req) => myBadges(d, me(req).id))
  );
  r.get(
    "/me/notifications",
    h(async (req) => myNotifications(d, me(req).id))
  );
  r.post(
    "/me/notifications/read-all",
    h(async (req) => markAllRead(d, me(req).id))
  );
  r.post(
    "/me/notifications/:id/read",
    h(async (req) => markNotificationRead(d, me(req).id, String(req.params.id)))
  );
  r.get(
    "/me/messages",
    h(async (req) => myMessages(d, me(req).id))
  );
  r.post(
    "/me/messages/:id/read",
    h(async (req) => markMessageRead(d, me(req).id, String(req.params.id)))
  );
  r.post(
    "/me/devices",
    h(async (req) => registerDevice(d, me(req).id, parse(deviceSchema, req.body)))
  );
  r.delete(
    "/me/devices",
    h(
      async (req) => unregisterDevice(
        d,
        me(req).id,
        parse(z13.object({ token: z13.string().min(10).max(4096) }), req.body).token
      ),
      204
    )
  );
  r.get(
    "/me/mentor/nudges",
    h(async (req) => myNudges(d, me(req).id))
  );
  r.get(
    "/me/mentor/history",
    h(
      async (req) => chatHistory(
        d,
        me(req).id,
        typeof req.query.packageId === "string" ? req.query.packageId : null
      )
    )
  );
  r.post(
    "/me/mentor/chat",
    rateLimit(limiter, "mentor", 10, 6e4, uid, "\u06A9\u0645\u06CC \u0622\u0647\u0633\u062A\u0647\u200C\u062A\u0631! \u0686\u0646\u062F \u062B\u0627\u0646\u06CC\u0647 \u0635\u0628\u0631 \u06A9\u0646 \u0648 \u062F\u0648\u0628\u0627\u0631\u0647 \u0628\u067E\u0631\u0633."),
    h(async (req) => chat(d, me(req), parse(chatSchema, req.body)))
  );
  r.post(
    "/me/mentor/feedback",
    h(async (req) => feedback(d, me(req), parse(feedbackSchema, req.body)))
  );
  return r;
}

// ../../functions/src/app.ts
function createApp(deps, handles = {}) {
  const config2 = deps.config;
  const limiter = handles.limiter ?? new RateLimiter(() => deps.clock().getTime(), deps.config.rateLimitScale);
  const app = express();
  app.disable("x-powered-by");
  app.set("trust proxy", deps.config.trustProxyHops);
  app.use(
    helmet({
      contentSecurityPolicy: { directives: { defaultSrc: ["'none'"], frameAncestors: ["'none'"] } },
      referrerPolicy: { policy: "strict-origin-when-cross-origin" },
      hsts: { maxAge: 31536e3, includeSubDomains: true },
      frameguard: { action: "deny" },
      crossOriginResourcePolicy: { policy: "cross-origin" }
    })
  );
  app.use(
    cors({
      origin(origin2, cb) {
        if (!origin2 || config2.allowedOrigins.includes(origin2)) cb(null, true);
        else cb(null, false);
      },
      allowedHeaders: ["Authorization", "X-Access-Token", "Content-Type", "Idempotency-Key"],
      methods: ["GET", "POST", "PUT", "PATCH", "DELETE"],
      maxAge: 600
    })
  );
  const v1 = express.Router();
  if (deps.blob instanceof LocalBlobStore) v1.use(localFilesRouter(deps.blob));
  else if (handles.filesRouter) v1.use(handles.filesRouter);
  v1.use(express.json({ limit: "1mb" }));
  v1.use(healthRouter(config2));
  v1.use(authRouter(deps, limiter));
  v1.use(
    ["/me", "/manager", "/admin"],
    authenticate(deps),
    rateLimit(limiter, "general", 60, 6e4, (req) => req.user?.id ?? req.ip ?? "anon")
  );
  v1.use(meRouter(deps, limiter));
  v1.use(managerRouter(deps, limiter));
  v1.use(adminRouter(deps, limiter));
  app.use("/v1", v1);
  app.use(notFoundHandler);
  app.use(errorHandler);
  return app;
}

// ../../functions/src/auth/memory.ts
import { createHash as createHash2, createHmac as createHmac2, randomBytes, scryptSync, timingSafeEqual as timingSafeEqual2 } from "node:crypto";
var REFRESH_GRACE_MS = 3e4;
var TOKEN_TTL = 3600;
function hashPassword(password) {
  const salt = randomBytes(16);
  const key = scryptSync(password, salt, 32);
  return `scrypt$${salt.toString("base64")}$${key.toString("base64")}`;
}
function verifyPassword(password, stored) {
  const [, saltB64, keyB64] = stored.split("$");
  if (!saltB64 || !keyB64) return false;
  const key = scryptSync(password, Buffer.from(saltB64, "base64"), 32);
  const expected = Buffer.from(keyB64, "base64");
  return key.length === expected.length && timingSafeEqual2(key, expected);
}
var b64 = (o) => Buffer.from(JSON.stringify(o)).toString("base64url");
var sha = (s) => createHash2("sha256").update(s).digest("hex");
var MemoryAuthProvider = class {
  constructor(store, secret, now = () => Date.now()) {
    this.store = store;
    this.secret = secret;
    this.now = now;
  }
  store;
  secret;
  now;
  sign(uid, iat, gen) {
    const head = b64({ alg: "HS256", typ: "JWT" });
    const body = b64({ sub: uid, iat, exp: iat + TOKEN_TTL, gen });
    const sig = createHmac2("sha256", this.secret).update(`${head}.${body}`).digest("base64url");
    return `${head}.${body}.${sig}`;
  }
  async issue(uid) {
    const iat = Math.floor(this.now() / 1e3);
    const acc = await this.store.get(`_auth/${uid}`);
    const refreshToken = randomBytes(32).toString("base64url");
    await this.store.set(`_auth_refresh/${sha(refreshToken)}`, {
      uid,
      createdAt: new Date(this.now()).toISOString()
    });
    return {
      idToken: this.sign(uid, iat, acc?.validAfter ?? 0),
      refreshToken,
      expiresIn: TOKEN_TTL
    };
  }
  async createUser(p) {
    const email = p.email.toLowerCase();
    const uid = this.store.newId();
    await this.store.create(`_auth_email/${sha(email)}`, { uid });
    await this.store.create(`_auth/${uid}`, {
      email,
      passwordHash: hashPassword(p.password),
      displayName: p.displayName,
      disabled: false,
      claims: {},
      validAfter: 0
    });
    return uid;
  }
  async deleteUser(uid) {
    const acc = await this.store.get(`_auth/${uid}`);
    if (!acc) return;
    await this.store.delete(`_auth_email/${sha(acc.email)}`);
    await this.store.delete(`_auth/${uid}`);
  }
  async signIn(email, password) {
    const link = await this.store.get(`_auth_email/${sha(email.toLowerCase())}`);
    const acc = link ? await this.store.get(`_auth/${link.uid}`) : null;
    if (!link || !acc || !verifyPassword(password, acc.passwordHash))
      return { ok: false, reason: "invalid" };
    if (acc.disabled) return { ok: false, reason: "disabled" };
    return { ok: true, uid: link.uid, tokens: await this.issue(link.uid) };
  }
  async refresh(refreshToken) {
    const key = `_auth_refresh/${sha(refreshToken)}`;
    const rec = await this.store.get(key);
    if (!rec) return null;
    if (rec.rotatedAt !== void 0 && this.now() - rec.rotatedAt > REFRESH_GRACE_MS) {
      await this.store.delete(key);
      return null;
    }
    const acc = await this.store.get(`_auth/${rec.uid}`);
    if (!acc || acc.disabled) return null;
    if (rec.rotatedAt === void 0) await this.store.update(key, { rotatedAt: this.now() });
    return { uid: rec.uid, tokens: await this.issue(rec.uid) };
  }
  async verify(idToken) {
    const parts = idToken.split(".");
    if (parts.length !== 3) return null;
    const [head, body, sig] = parts;
    const expected = createHmac2("sha256", this.secret).update(`${head}.${body}`).digest("base64url");
    const a = Buffer.from(sig);
    const b = Buffer.from(expected);
    if (a.length !== b.length || !timingSafeEqual2(a, b)) return null;
    let payload;
    try {
      payload = JSON.parse(Buffer.from(body, "base64url").toString("utf8"));
    } catch {
      return null;
    }
    if (!payload.sub || !payload.exp || !payload.iat || payload.exp < this.now() / 1e3)
      return null;
    const acc = await this.store.get(`_auth/${payload.sub}`);
    if (!acc || acc.disabled || (payload.gen ?? 0) !== acc.validAfter) return null;
    return { uid: payload.sub };
  }
  async revoke(uid) {
    const acc = await this.store.get(`_auth/${uid}`);
    await this.store.update(`_auth/${uid}`, { validAfter: (acc?.validAfter ?? 0) + 1 });
    const tokens = await this.store.query({
      collection: "_auth_refresh",
      where: [["uid", "==", uid]]
    });
    for (const t of tokens) await this.store.delete(`_auth_refresh/${t.id}`);
  }
  async setDisabled(uid, disabled) {
    await this.store.update(`_auth/${uid}`, { disabled });
  }
  async setPassword(uid, password) {
    await this.store.update(`_auth/${uid}`, { passwordHash: hashPassword(password) });
  }
  async setClaims(uid, claims) {
    await this.store.update(`_auth/${uid}`, { claims });
  }
  async sendPasswordResetEmail(email) {
    console.info(`[auth:memory] password reset requested for ${email.replace(/(.).+@/, "$1***@")}`);
  }
};

// ../../functions/src/config.ts
function loadConfig(env = process.env) {
  const rawEnv = env.APP_ENV ?? (env.NODE_ENV === "test" ? "test" : "dev");
  const appEnv = rawEnv === "prod" || rawEnv === "test" ? rawEnv : "dev";
  const allowedOrigins = (env.ALLOWED_ORIGINS ?? "").split(",").map((o) => o.trim()).filter((o) => o.length > 0);
  const backend = env.DATA_BACKEND === "memory" ? "memory" : "firestore";
  return {
    env: appEnv,
    version: env.APP_VERSION ?? "0.2.0",
    allowedOrigins,
    backend,
    localSecret: env.LOCAL_AUTH_SECRET ?? "local-dev-secret-change-me",
    firebaseWebApiKey: env.FIREBASE_WEB_API_KEY ?? "",
    storageBucket: env.STORAGE_BUCKET ?? "",
    geminiApiKey: env.GEMINI_API_KEY ?? "",
    geminiModel: env.GEMINI_MODEL ?? "gemini-2.5-flash-lite",
    dataDir: env.LOCAL_DATA_DIR ?? ".local-data",
    playbackBudget: !(backend === "memory" && env.PLAYBACK_BUDGET === "off"),
    trustProxyHops: Math.max(0, Math.min(5, Number.parseInt(env.TRUST_PROXY_HOPS ?? "1", 10) || 0)),
    rateLimitScale: backend === "memory" ? Math.max(1, Number.parseInt(env.RATE_LIMIT_SCALE ?? "1", 10) || 1) : 1,
    smtpUrl: env.SMTP_URL ?? "",
    appUrl: (env.APP_URL ?? "").replace(/\/$/, ""),
    mailFrom: env.MAIL_FROM ?? "\u0633\u06CC\u0644\u0627\u0646\u0647\u200C\u0633\u0628\u0632 \u0644\u0631\u0646\u06CC\u0646\u06AF <no-reply@seylane-sabz.local>"
  };
}

// ../../functions/src/llm/gemini.ts
var GeminiClient = class {
  constructor(apiKey, model, timeoutMs = 12e3) {
    this.apiKey = apiKey;
    this.model = model;
    this.timeoutMs = timeoutMs;
  }
  apiKey;
  model;
  timeoutMs;
  name = "gemini";
  async generate(p) {
    const ctrl = new AbortController();
    const timer = setTimeout(() => ctrl.abort(), this.timeoutMs);
    try {
      const res = await fetch(
        `https://generativelanguage.googleapis.com/v1beta/models/${this.model}:generateContent`,
        {
          method: "POST",
          signal: ctrl.signal,
          headers: { "Content-Type": "application/json", "x-goog-api-key": this.apiKey },
          body: JSON.stringify({
            systemInstruction: { parts: [{ text: p.system }] },
            contents: [{ role: "user", parts: [{ text: p.prompt }] }],
            generationConfig: { temperature: 0.2, maxOutputTokens: p.maxTokens },
            safetySettings: [
              { category: "HARM_CATEGORY_HARASSMENT", threshold: "BLOCK_MEDIUM_AND_ABOVE" },
              { category: "HARM_CATEGORY_HATE_SPEECH", threshold: "BLOCK_MEDIUM_AND_ABOVE" },
              { category: "HARM_CATEGORY_SEXUALLY_EXPLICIT", threshold: "BLOCK_MEDIUM_AND_ABOVE" },
              { category: "HARM_CATEGORY_DANGEROUS_CONTENT", threshold: "BLOCK_MEDIUM_AND_ABOVE" }
            ]
          })
        }
      );
      if (!res.ok) throw new Error(`Gemini HTTP ${res.status}`);
      const body = await res.json();
      const text2 = body.candidates?.[0]?.content?.parts?.map((x) => x.text ?? "").join("") ?? "";
      if (!text2.trim()) throw new Error("Gemini empty response");
      return text2.trim();
    } finally {
      clearTimeout(timer);
    }
  }
};

// ../../functions/src/mail/types.ts
var DisabledMailer = class {
  enabled = false;
  async send() {
  }
};

// netlify/functions/api.mts
init_time();

// netlify/api/blob-store.ts
init_errors();
import { createHmac as createHmac3, timingSafeEqual as timingSafeEqual3 } from "node:crypto";
import { getStore } from "@netlify/blobs";
import express2, { Router as Router7 } from "express";
var NetlifyBlobStore = class {
  constructor(secret) {
    this.secret = secret;
  }
  secret;
  get store() {
    return getStore({ name: "media", consistency: "strong" });
  }
  signTicket(t) {
    const body = Buffer.from(JSON.stringify(t)).toString("base64url");
    const sig = createHmac3("sha256", this.secret).update(body).digest("base64url");
    return `${body}.${sig}`;
  }
  verifyTicket(token, op) {
    const [body, sig] = token.split(".");
    if (!body || !sig) return null;
    const expected = createHmac3("sha256", this.secret).update(body).digest("base64url");
    const a = Buffer.from(sig);
    const b = Buffer.from(expected);
    if (a.length !== b.length || !timingSafeEqual3(a, b)) return null;
    try {
      const t = JSON.parse(Buffer.from(body, "base64url").toString("utf8"));
      if (t.op !== op || t.exp < Date.now()) return null;
      return t;
    } catch {
      return null;
    }
  }
  async put(p, data, contentType) {
    const bytes = data.buffer.slice(data.byteOffset, data.byteOffset + data.byteLength);
    await this.store.set(p, bytes, {
      metadata: { contentType, size: data.length }
    });
  }
  async createUploadUrl(p, contentType, maxBytes) {
    const exp = Date.now() + 15 * 6e4;
    const token = this.signTicket({ p, ct: contentType, max: maxBytes, exp, op: "put" });
    return {
      url: `/v1/uploads/${token}`,
      method: "PUT",
      headers: { "Content-Type": contentType },
      expiresAt: new Date(exp).toISOString()
    };
  }
  async stat(p) {
    const res = await this.store.getMetadata(p);
    if (!res) return null;
    const meta = res.metadata;
    return {
      size: Number(meta.size ?? 0),
      contentType: meta.contentType ?? "application/octet-stream"
    };
  }
  async read(p) {
    const res = await this.store.getWithMetadata(p, { type: "arrayBuffer" });
    if (!res) return null;
    const data = Buffer.from(res.data);
    const meta = res.metadata;
    return {
      data,
      meta: { contentType: meta.contentType ?? "application/octet-stream", size: data.length }
    };
  }
  async readRange(p, start, end) {
    const file = await this.read(p);
    if (!file) throw new Error(`Blob not found: ${p}`);
    return file.data.subarray(start, end + 1);
  }
  async signedReadUrl(p, ttlSec) {
    const token = this.signTicket({ p, ct: "", max: 0, exp: Date.now() + ttlSec * 1e3, op: "get" });
    return `/v1/files/signed/${token}`;
  }
  async publicUrl(p) {
    return `/v1/files/public/${p.split("/").map(encodeURIComponent).join("/")}`;
  }
  async delete(p) {
    await this.store.delete(p);
  }
};
function netlifyFilesRouter(blob) {
  const r = Router7();
  r.put("/uploads/:token", express2.raw({ type: () => true, limit: "6mb" }), async (req, res, next) => {
    try {
      const t = blob.verifyTicket(String(req.params.token), "put");
      if (!t) throw new ApiError("FORBIDDEN", "\u0644\u06CC\u0646\u06A9 \u0622\u067E\u0644\u0648\u062F \u0645\u0646\u0642\u0636\u06CC \u06CC\u0627 \u0646\u0627\u0645\u0639\u062A\u0628\u0631 \u0627\u0633\u062A.");
      const body = Buffer.isBuffer(req.body) ? req.body : Buffer.alloc(0);
      if (body.length > t.max) throw new ApiError("VALIDATION", "\u062D\u062C\u0645 \u0641\u0627\u06CC\u0644 \u0628\u06CC\u0634 \u0627\u0632 \u062D\u062F \u0645\u062C\u0627\u0632 \u0627\u0633\u062A.");
      await blob.put(t.p, body, t.ct);
      res.status(200).json({ data: { ok: true, size: body.length } });
    } catch (e) {
      next(
        e instanceof ApiError ? e : new ApiError("VALIDATION", "\u0622\u067E\u0644\u0648\u062F \u0646\u0627\u0645\u0648\u0641\u0642 \u0628\u0648\u062F. \u062F\u0648\u0628\u0627\u0631\u0647 \u062A\u0644\u0627\u0634 \u06A9\u0646\u06CC\u062F.")
      );
    }
  });
  const send = async (res, range, p) => {
    const file = await blob.read(p);
    if (!file) throw new ApiError("NOT_FOUND");
    res.setHeader("X-Content-Type-Options", "nosniff");
    res.setHeader("Cross-Origin-Resource-Policy", "cross-origin");
    res.setHeader("Content-Type", file.meta.contentType);
    res.setHeader("Cache-Control", "private, max-age=3600");
    res.setHeader("Accept-Ranges", "bytes");
    const size = file.data.length;
    const m = range ? /^bytes=(\d*)-(\d*)$/.exec(range) : null;
    if (m && size > 0) {
      let start = m[1] ? Number(m[1]) : size - Number(m[2]);
      let end = m[1] && m[2] ? Number(m[2]) : size - 1;
      start = Math.max(0, start);
      end = Math.min(size - 1, end);
      if (start > end) {
        res.status(416).setHeader("Content-Range", `bytes */${size}`).end();
        return;
      }
      res.status(206).setHeader("Content-Range", `bytes ${start}-${end}/${size}`);
      res.end(file.data.subarray(start, end + 1));
      return;
    }
    res.status(200).end(file.data);
  };
  r.get("/files/signed/:token", async (req, res, next) => {
    try {
      const t = blob.verifyTicket(String(req.params.token), "get");
      if (!t) throw new ApiError("FORBIDDEN", "\u0644\u06CC\u0646\u06A9 \u0641\u0627\u06CC\u0644 \u0645\u0646\u0642\u0636\u06CC \u0634\u062F\u0647 \u0627\u0633\u062A. \u0635\u0641\u062D\u0647 \u0631\u0627 \u062F\u0648\u0628\u0627\u0631\u0647 \u0628\u0627\u0632 \u06A9\u0646\u06CC\u062F.");
      await send(res, req.headers.range, t.p);
    } catch (e) {
      next(e);
    }
  });
  r.get(/^\/files\/public\/((?:brands|products|branding)\/.+)$/, async (req, res, next) => {
    try {
      const p = decodeURIComponent(req.params[0] ?? "");
      if (p.includes("..")) throw new ApiError("NOT_FOUND");
      await send(res, req.headers.range, p);
    } catch (e) {
      next(e);
    }
  });
  return r;
}

// netlify/api/pg-store.ts
import { randomBytes as randomBytes2 } from "node:crypto";
import { getDatabase } from "@netlify/database";

// ../../functions/src/store/memory.ts
function clone(v) {
  return structuredClone(v);
}
function getField(obj, field) {
  let cur = obj;
  for (const part of field.split(".")) {
    if (cur === null || typeof cur !== "object") return void 0;
    cur = cur[part];
  }
  return cur;
}
function cmp(a, b) {
  if (a instanceof Date) a = a.toISOString();
  if (b instanceof Date) b = b.toISOString();
  if (a === b) return 0;
  if (a === void 0 || a === null) return -1;
  if (b === void 0 || b === null) return 1;
  return a < b ? -1 : 1;
}
function matches(row, [field, op, value]) {
  const v = field === "__id__" ? row.id : getField(row, field);
  switch (op) {
    case "==":
      return v === value || v === void 0 && value === null;
    case "!=":
      return v !== value && v !== void 0;
    case "<":
      return v !== void 0 && v !== null && cmp(v, value) < 0;
    case "<=":
      return v !== void 0 && v !== null && cmp(v, value) <= 0;
    case ">":
      return v !== void 0 && v !== null && cmp(v, value) > 0;
    case ">=":
      return v !== void 0 && v !== null && cmp(v, value) >= 0;
    case "in":
      return Array.isArray(value) && value.includes(v);
    case "array-contains":
      return Array.isArray(v) && v.includes(value);
  }
}
function deepMerge(target, src) {
  const out = { ...target };
  for (const [k, v] of Object.entries(src)) {
    const t = out[k];
    if (v && typeof v === "object" && !Array.isArray(v) && !(v instanceof Date) && t && typeof t === "object" && !Array.isArray(t) && !(t instanceof Date)) {
      out[k] = deepMerge(t, v);
    } else out[k] = v;
  }
  return out;
}
function applyUpdate(target, patch) {
  const out = clone(target);
  for (const [k, v] of Object.entries(patch)) {
    const parts = k.split(".");
    let cur = out;
    for (let i = 0; i < parts.length - 1; i++) {
      const p = parts[i];
      if (!cur[p] || typeof cur[p] !== "object") cur[p] = {};
      cur = cur[p];
    }
    cur[parts[parts.length - 1]] = v;
  }
  return out;
}
function splitPath(p) {
  const idx = p.lastIndexOf("/");
  if (idx <= 0) throw new Error(`Invalid document path: ${p}`);
  return { col: p.slice(0, idx), id: p.slice(idx + 1) };
}

// netlify/api/pg-store.ts
var LOCK_KEY = 7302114;
var toJson = (v) => JSON.parse(JSON.stringify(v));
var PgStore = class {
  get pool() {
    return getDatabase().pool;
  }
  async read(db, p) {
    const { col, id: id2 } = splitPath(p);
    const { rows } = await db.query("SELECT data FROM docs WHERE col = $1 AND id = $2", [col, id2]);
    const row = rows[0];
    return row ? { ...row.data, id: id2 } : null;
  }
  async write(db, p, data, mode) {
    const { col, id: id2 } = splitPath(p);
    const clean = toJson(data);
    delete clean.id;
    let next = clean;
    if (mode === "create") {
      const res = await db.query(
        "INSERT INTO docs (col, id, grp, data) VALUES ($1, $2, $3, $4) ON CONFLICT DO NOTHING",
        [col, id2, col.split("/").pop(), clean]
      );
      if (!res.rowCount) throw new StoreConflictError(p);
      return;
    }
    if (mode === "merge" || mode === "update") {
      const existing = await this.read(db, p);
      if (existing) delete existing.id;
      if (mode === "update") {
        if (!existing) throw new StoreNotFoundError(p);
        next = toJson(applyUpdate(existing, clean));
      } else if (existing) next = deepMerge(existing, clean);
    }
    await db.query(
      `INSERT INTO docs (col, id, grp, data) VALUES ($1, $2, $3, $4)
       ON CONFLICT (col, id) DO UPDATE SET data = EXCLUDED.data, updated_at = now()`,
      [col, id2, col.split("/").pop(), next]
    );
  }
  async runQuery(db, q) {
    const params = [q.collection];
    let sql = q.group ? "SELECT id, data FROM docs WHERE grp = $1 AND col LIKE '%/%'" : "SELECT id, data FROM docs WHERE col = $1";
    const eq = {};
    for (const [field, op, value] of q.where ?? []) {
      if (op === "==" && field !== "__id__" && !field.includes(".") && ["string", "number", "boolean"].includes(typeof value))
        eq[field] = value;
    }
    if (Object.keys(eq).length) {
      params.push(eq);
      sql += " AND data @> $2";
    }
    const { rows } = await db.query(sql, params);
    let docs = rows.map((r) => ({ ...r.data, id: r.id }));
    for (const w of q.where ?? []) docs = docs.filter((r) => matches(r, w));
    const order = q.orderBy ?? [];
    if (order.length) {
      docs.sort((a, b) => {
        for (const [f, dir] of order) {
          const c = cmp(getField(a, f), getField(b, f));
          if (c !== 0) return dir === "asc" ? c : -c;
        }
        return a.id < b.id ? -1 : 1;
      });
    }
    if (q.limit !== void 0) docs = docs.slice(0, q.limit);
    return docs;
  }
  /** Runs `fn` in a transaction holding the global writer lock. */
  async locked(fn) {
    const client = await this.pool.connect();
    try {
      await client.query("BEGIN");
      await client.query("SELECT pg_advisory_xact_lock($1)", [LOCK_KEY]);
      const result = await fn(client);
      await client.query("COMMIT");
      return result;
    } catch (e) {
      await client.query("ROLLBACK").catch(() => void 0);
      throw e;
    } finally {
      client.release();
    }
  }
  async get(p) {
    return this.read(this.pool, p);
  }
  async getMany(paths) {
    return Promise.all(paths.map((p) => this.read(this.pool, p)));
  }
  async query(q) {
    return this.runQuery(this.pool, q);
  }
  async set(p, data, opts) {
    if (opts?.merge) await this.locked((db) => this.write(db, p, data, "merge"));
    else await this.write(this.pool, p, data, "set");
  }
  async create(p, data) {
    await this.write(this.pool, p, data, "create");
  }
  async update(p, data) {
    await this.locked((db) => this.write(db, p, data, "update"));
  }
  async delete(p) {
    const { col, id: id2 } = splitPath(p);
    await this.pool.query("DELETE FROM docs WHERE col = $1 AND id = $2", [col, id2]);
  }
  async increment(p, field, by) {
    await this.locked(async (db) => {
      const cur = await this.read(db, p);
      const prev = cur ? Number(getField(cur, field) ?? 0) : 0;
      await this.write(db, p, { [field]: prev + by }, cur ? "update" : "merge");
    });
  }
  newId() {
    return randomBytes2(10).toString("base64url").replace(/[-_]/g, "x").slice(0, 20);
  }
  async batchSet(items) {
    await this.locked(async (db) => {
      for (const it of items) await this.write(db, it.path, it.data, it.merge ? "merge" : "set");
    });
  }
  runTransaction(fn) {
    return this.locked(async (db) => {
      const writes = [];
      const tx = {
        get: (p) => this.read(db, p),
        query: (q) => this.runQuery(db, q),
        set: (p, d, o) => writes.push(() => this.write(db, p, d, o?.merge ? "merge" : "set")),
        create: (p, d) => writes.push(() => this.write(db, p, d, "create")),
        update: (p, d) => writes.push(() => this.write(db, p, d, "update"))
      };
      const result = await fn(tx);
      for (const w of writes) await w();
      return result;
    });
  }
};

// netlify/functions/api.mts
var noPush = { send: async () => ({ sent: 0, invalidTokens: [] }) };
async function signingSecret(store) {
  if (process.env.LOCAL_AUTH_SECRET) return process.env.LOCAL_AUTH_SECRET;
  const path3 = "_system/auth_secret";
  const existing = await store.get(path3);
  if (existing) return existing.value;
  try {
    await store.create(path3, { value: randomBytes3(48).toString("base64url") });
  } catch {
  }
  return (await store.get(path3)).value;
}
async function buildDeps() {
  const config2 = loadConfig({ ...process.env, APP_ENV: process.env.APP_ENV ?? "prod" });
  const store = new PgStore();
  const secret = await signingSecret(store);
  let mail = new DisabledMailer();
  if (config2.smtpUrl) {
    const { SmtpMailer: SmtpMailer2 } = await Promise.resolve().then(() => (init_smtp(), smtp_exports));
    mail = new SmtpMailer2(config2.smtpUrl, config2.mailFrom);
  }
  return {
    config: { ...config2, localSecret: secret },
    store,
    auth: new MemoryAuthProvider(store, secret),
    blob: new NetlifyBlobStore(secret),
    push: noPush,
    mail,
    llm: config2.geminiApiKey ? new GeminiClient(config2.geminiApiKey, config2.geminiModel) : null,
    clock: systemClock
  };
}
var origin = null;
function server() {
  origin ??= (async () => {
    const deps = await buildDeps();
    const app = createApp(deps, { filesRouter: netlifyFilesRouter(deps.blob) });
    const srv = http.createServer(app);
    await new Promise((resolve) => srv.listen(0, "127.0.0.1", resolve));
    return `http://127.0.0.1:${srv.address().port}`;
  })().catch((e) => {
    origin = null;
    throw e;
  });
  return origin;
}
var HOP_BY_HOP = ["host", "connection", "content-length", "transfer-encoding", "x-forwarded-for"];
var api_default = async (req, context) => {
  let base;
  try {
    base = await server();
  } catch (e) {
    console.error("[api] startup failed", e);
    return Response.json(
      { error: { code: "INTERNAL", message: "\u0633\u0631\u0648\u0631 \u0645\u0648\u0642\u062A\u0627\u064B \u062F\u0631 \u062F\u0633\u062A\u0631\u0633 \u0646\u06CC\u0633\u062A. \u06A9\u0645\u06CC \u0628\u0639\u062F \u062F\u0648\u0628\u0627\u0631\u0647 \u062A\u0644\u0627\u0634 \u06A9\u0646\u06CC\u062F." } },
      { status: 503 }
    );
  }
  const url = new URL(req.url);
  const headers = new Headers(req.headers);
  for (const h2 of HOP_BY_HOP) headers.delete(h2);
  headers.set("x-forwarded-for", context.ip);
  const hasBody = req.method !== "GET" && req.method !== "HEAD";
  const res = await fetch(`${base}${url.pathname}${url.search}`, {
    method: req.method,
    headers,
    body: hasBody ? await req.arrayBuffer() : void 0,
    redirect: "manual"
  });
  const out = new Headers(res.headers);
  out.delete("content-length");
  out.delete("content-encoding");
  out.delete("transfer-encoding");
  out.delete("connection");
  return new Response(res.body, { status: res.status, headers: out });
};
var config = {
  path: "/v1/*"
};
export {
  config,
  api_default as default
};
